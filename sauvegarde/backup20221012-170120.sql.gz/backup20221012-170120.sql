--
-- backup20221012-170120.sql.gz


DROP TABLE IF EXISTS `approvisionnement`;
CREATE TABLE `approvisionnement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_commande` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `categorie` varchar(100) NOT NULL DEFAULT 'non défini',
  `pu_vente` int(11) NOT NULL,
  `pu_achat` int(11) NOT NULL,
  `conditionnement` text NOT NULL,
  `stock_commande` int(11) NOT NULL,
  `min_rec` int(11) NOT NULL,
  `date_peremption` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4;

INSERT INTO `approvisionnement` VALUES ('36','05aa850000','AMAK','eferalgan','comprimé efervescent','100','50','plaquette de 10','800','130','02-23');
INSERT INTO `approvisionnement` VALUES ('37','05aa850000','MKAS','panadol','comprimé','450','150','plaquette de 10','500','50','07-24');
INSERT INTO `approvisionnement` VALUES ('38','05aa850000','MASL','metronidazol',' ','150','100',' ','350','150','08-25');
INSERT INTO `approvisionnement` VALUES ('39','05aa850000','KAAA','paracétamol','comprimé','100','45','plaquette de 10','1000','50','10-25');
INSERT INTO `approvisionnement` VALUES ('40','05aa850000','KASL','amoxiline','comprimé','100','50','plaquette 20','750','100','12-24');
INSERT INTO `approvisionnement` VALUES ('41','05aa850000','MAAS','minoxidil 300ml','','7500','5000','paquet de 10 tubes','400','80','02-23');
INSERT INTO `approvisionnement` VALUES ('42','05aa850000','ZMOS','arthemeter','comprimé','1700','900','plaquette de 6','560','80','02-22');
INSERT INTO `approvisionnement` VALUES ('43','061a452611','ZMOS','arthemeter','comprimé','1700','900','plaquette de 6','500','80','05-22');
INSERT INTO `approvisionnement` VALUES ('44','0cdd25000','MASL','ibuprofene',' cp','150','100',' ','400','150','03-24');
INSERT INTO `approvisionnement` VALUES ('45','fff350000','ZMOS','arthemeter','comprimé','1700','900','plaquette de 6','700','80','02-25');
INSERT INTO `approvisionnement` VALUES ('46','fff350000','MASL','metronidazol',' ','200','100',' ','250','150','08-25');
INSERT INTO `approvisionnement` VALUES ('47','c1aa50000','MASL','ibuprofene',' cp','150','100',' ','250','150','03-24');
INSERT INTO `approvisionnement` VALUES ('48','c1aa50000','HUIH','metronidazol',' ','200','120',' ','450','150','08-25');
INSERT INTO `approvisionnement` VALUES ('49','7f7250000','KASL','amoxiline','comprimé','200','50','plaquette 20','450','100','12-24');
INSERT INTO `approvisionnement` VALUES ('50','7f7250000','MASL','metronidazol',' ','200','100',' ','450','150','08-25');
INSERT INTO `approvisionnement` VALUES ('51','5657500','','perfuseur','','250','0','B/1','100','0','');
INSERT INTO `approvisionnement` VALUES ('52','5657500','','sayana press','','500','0','B/1','450','0','');
INSERT INTO `approvisionnement` VALUES ('53','5657500','','transfuseur','','500','0','B/1','500','0','');
INSERT INTO `approvisionnement` VALUES ('54','977f5000','','perfuseur','','250','0','B/1','100','0','');
INSERT INTO `approvisionnement` VALUES ('55','977f5000','','transfuseur','','500','0','B/1','100','0','');
INSERT INTO `approvisionnement` VALUES ('56','447e5000','','perfuseur','','250','0','B/1','100','0','');
INSERT INTO `approvisionnement` VALUES ('57','447e5000','','transfuseur','','500','0','B/1','50','0','');
INSERT INTO `approvisionnement` VALUES ('58','acbb50000','','transfuseur','','500','0','B/1','150','0','');
INSERT INTO `approvisionnement` VALUES ('59','acbb50000','','perfuseur','','250','0','B/1','100','0','');
INSERT INTO `approvisionnement` VALUES ('60','acbb50000','','sayana press','','500','0','B/1','50','0','');
INSERT INTO `approvisionnement` VALUES ('61','59aa50000','','sayana press','','500','0','B/1','150','0','');
INSERT INTO `approvisionnement` VALUES ('62','59aa50000','','transfuseur','','500','0','B/1','50','0','');
INSERT INTO `approvisionnement` VALUES ('63','eda050000','','transfuseur','','500','0','B/1','50','0','');
INSERT INTO `approvisionnement` VALUES ('64','eda050000','','sayana press','','500','0','B/1','75','0','');
INSERT INTO `approvisionnement` VALUES ('65','eda050000','','perfuseur','','250','0','B/1','50','0','');
INSERT INTO `approvisionnement` VALUES ('66','c41c1000','KASL','amoxiciline','cp','250','50','B/10','100','100','12-24/02-25');
INSERT INTO `approvisionnement` VALUES ('67','12d8100','KASL','amoxi','comprimé','200','50','B/20','100','50','12-24/05-25');
INSERT INTO `approvisionnement` VALUES ('68','a8b4110','','ccc','cp','100','0','','10','0','');
INSERT INTO `approvisionnement` VALUES ('69','6e36110','','ccc','c','100','0','','15','0','');
INSERT INTO `approvisionnement` VALUES ('70','cce65422','','ccc','c','100','0','','25','10','');
INSERT INTO `approvisionnement` VALUES ('71','58254500','MASL','ibuprofene',' cp','150','100',' ','3','150','03-24');
INSERT INTO `approvisionnement` VALUES ('72','3d1f1','','artefan','','1700','0','b/6','10','10','');
INSERT INTO `approvisionnement` VALUES ('73','3d1f1','','cofantrine','cp','1500','0','b/6','10','0','');
INSERT INTO `approvisionnement` VALUES ('74','3d1f1','','litacol','cp','250','0','B/4','10','100','');
INSERT INTO `approvisionnement` VALUES ('75','1059123','','malacur','','1000','0','','25','10','');
INSERT INTO `approvisionnement` VALUES ('76','6953123','','malacur','cp','1000','0','p/6','25','10','');
INSERT INTO `approvisionnement` VALUES ('77','5d1a23ed','KASL','amoxiciline','comprimé','250','50','B/10','12','100','12-24/02-25');


DROP TABLE IF EXISTS `assurances`;
CREATE TABLE `assurances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `assurances` VALUES ('1','AssureTous');
INSERT INTO `assurances` VALUES ('2','Ascoma');


DROP TABLE IF EXISTS `data_assurance`;
CREATE TABLE `data_assurance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_facture` varchar(255) NOT NULL,
  `patient` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `qte` int(11) NOT NULL,
  `prix` int(11) NOT NULL,
  `categorie` varchar(200) NOT NULL,
  `date_heure` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4;

INSERT INTO `data_assurance` VALUES ('1','d2b4','Richard Kenfack','CHR K1','1','1000','service','2021-10-25 17:28:37');
INSERT INTO `data_assurance` VALUES ('2','714d','ali mohammed','CHR Circoncision','1','5000','service','2021-10-25 17:29:38');
INSERT INTO `data_assurance` VALUES ('3','b58d','Alan Kamga','paracétamol','0','200','pharmacie','2021-10-26 17:26:00');
INSERT INTO `data_assurance` VALUES ('4','b58d','Alan Kamga','arthemeter','0','1800','pharmacie','2021-10-26 17:26:00');
INSERT INTO `data_assurance` VALUES ('5','4eef','Alan Kamga','arthemeter','1','1800','pharmacie','2021-10-26 17:36:42');
INSERT INTO `data_assurance` VALUES ('6','4e0f','Alan Kamga','metronidazol','3','600','pharmacie','2021-10-27 10:07:26');
INSERT INTO `data_assurance` VALUES ('7','bf3e','Alan Kamga','CHR Incision','1','2000','service','2021-10-27 10:45:12');
INSERT INTO `data_assurance` VALUES ('8','a96a','Alan Kamga','LAB Widal et Felix','1','3600','service','2021-10-27 16:28:31');
INSERT INTO `data_assurance` VALUES ('9','3cb9','Alan Kamga','LAB Widal et Felix','1','3600','service','2021-10-27 18:40:00');
INSERT INTO `data_assurance` VALUES ('10','3cb9','Alan Kamga','LAB Triglycérides','1','3600','service','2021-10-27 18:40:00');
INSERT INTO `data_assurance` VALUES ('11','59e1','Alan Kamga','LAB ASLO','1','4000','service','2021-10-27 18:45:13');
INSERT INTO `data_assurance` VALUES ('12','c2c4','Alan Kamga','paracétamol','2','200','pharmacie','2021-10-27 18:50:02');
INSERT INTO `data_assurance` VALUES ('13','c2c4','Alan Kamga','arthemeter','1','1800','pharmacie','2021-10-27 18:50:02');
INSERT INTO `data_assurance` VALUES ('14','76ab','Alan Kamga','amoxiline','2','500','pharmacie','2021-10-27 18:50:31');
INSERT INTO `data_assurance` VALUES ('15','bf01','Alan Kamga','metronidazol','1','200','pharmacie','2021-10-27 18:51:19');
INSERT INTO `data_assurance` VALUES ('16','bf01','Alan Kamga','paracétamol','2','200','pharmacie','2021-10-27 18:51:19');
INSERT INTO `data_assurance` VALUES ('17','bf01','Alan Kamga','ibuprofene','5','750','pharmacie','2021-10-27 18:51:19');
INSERT INTO `data_assurance` VALUES ('18','c2c1','Alan Kamga','LAB Acide urique','1','2700','service','2021-10-27 19:04:49');
INSERT INTO `data_assurance` VALUES ('19','1c53','Alan Kamga','LAB Dosage HCV','1','18000','service','2021-10-27 21:04:46');
INSERT INTO `data_assurance` VALUES ('20','c804','Alan Kamga','RX Rachis cervical (F/P + %)','1','20000','service','2021-10-27 21:05:21');
INSERT INTO `data_assurance` VALUES ('21','c804','Alan Kamga','LAB ACHVC','1','4500','service','2021-10-27 21:05:21');
INSERT INTO `data_assurance` VALUES ('22','3db2','Alan Kamga','arthemeter','1','1800','pharmacie','2021-10-27 21:06:55');
INSERT INTO `data_assurance` VALUES ('23','3db2','Alan Kamga','paracétamol','2','200','pharmacie','2021-10-27 21:06:55');
INSERT INTO `data_assurance` VALUES ('24','3db2','Alan Kamga','ibuprofene','1','150','pharmacie','2021-10-27 21:06:55');
INSERT INTO `data_assurance` VALUES ('25','4c4b','Alan Kamga','amoxiline','4','1000','pharmacie','2021-10-27 21:07:27');
INSERT INTO `data_assurance` VALUES ('26','4c4b','Alan Kamga','metronidazol','1','200','pharmacie','2021-10-27 21:07:27');
INSERT INTO `data_assurance` VALUES ('27','c0db','Alan Kamga','eferalgan','2','200','pharmacie','2021-10-28 15:28:44');
INSERT INTO `data_assurance` VALUES ('28','c0db','Alan Kamga','arthemeter','1','1800','pharmacie','2021-10-28 15:28:44');
INSERT INTO `data_assurance` VALUES ('29','20c7','Alan Kamga','paracétamol','2','200','pharmacie','2021-10-28 15:29:43');
INSERT INTO `data_assurance` VALUES ('30','20c7','Alan Kamga','eferalgan','4','400','pharmacie','2021-10-28 15:29:43');
INSERT INTO `data_assurance` VALUES ('31','20c7','Alan Kamga','ibuprofene','2','300','pharmacie','2021-10-28 15:29:43');
INSERT INTO `data_assurance` VALUES ('32','e2c0','Alan Kamga','ibuprofene','5','750','pharmacie','2021-10-28 15:30:09');
INSERT INTO `data_assurance` VALUES ('33','1468','abel','amoxiline','4','1000','pharmacie','2021-10-28 15:31:10');
INSERT INTO `data_assurance` VALUES ('34','1468','abel','ibuprofene','1','150','pharmacie','2021-10-28 15:31:10');
INSERT INTO `data_assurance` VALUES ('35','c4ff','ekedi','metronidazol','2','400','pharmacie','2021-10-28 15:31:50');
INSERT INTO `data_assurance` VALUES ('36','c4ff','ekedi','amoxiline','1','250','pharmacie','2021-10-28 15:31:50');
INSERT INTO `data_assurance` VALUES ('37','f6d6','Alan Kamga','LAB Widal et Felix','1','3600','service','2021-10-28 15:34:22');
INSERT INTO `data_assurance` VALUES ('38','f6d6','Alan Kamga','LAB Glycémie à jeun','1','1000','service','2021-10-28 15:34:22');
INSERT INTO `data_assurance` VALUES ('39','0de6','Alan Kamga','LAB Chlamydia','1','8000','service','2021-10-28 15:35:01');
INSERT INTO `data_assurance` VALUES ('40','0de6','Alan Kamga','LAB Créatine','1','2700','service','2021-10-28 15:35:01');
INSERT INTO `data_assurance` VALUES ('41','0de6','Alan Kamga','LAB Calcium','1','3600','service','2021-10-28 15:35:01');
INSERT INTO `data_assurance` VALUES ('42','1841','abel','LAB D.dimeres','1','20000','service','2021-10-28 15:35:35');
INSERT INTO `data_assurance` VALUES ('43','1841','abel','LAB CRP','1','3600','service','2021-10-28 15:35:35');
INSERT INTO `data_assurance` VALUES ('44','d9e3','ekedi','LAB GE','1','1000','service','2021-10-28 15:36:08');
INSERT INTO `data_assurance` VALUES ('45','d9e3','ekedi','LAB Fer serique','1','5400','service','2021-10-28 15:36:08');
INSERT INTO `data_assurance` VALUES ('46','a35c','rogers','arthemeter','1','1800','pharmacie','2021-11-12 15:25:45');
INSERT INTO `data_assurance` VALUES ('47','150f200','rogers','paracétamol','2','200','pharmacie','2021-11-14 19:05:28');
INSERT INTO `data_assurance` VALUES ('48','58ba2100','rogers','ibuprofene','2','300','pharmacie','2021-11-14 19:06:12');
INSERT INTO `data_assurance` VALUES ('49','58ba2100','rogers','arthemeter','1','1800','pharmacie','2021-11-14 19:06:12');
INSERT INTO `data_assurance` VALUES ('50','9f8d20000','rogers','LAB ACE','1','20000','service','2021-11-14 19:15:02');
INSERT INTO `data_assurance` VALUES ('51','e70d17100','rogers','LAB ACHVC','1','4500','service','2021-11-14 19:15:39');
INSERT INTO `data_assurance` VALUES ('52','e70d17100','rogers','LAB Dosage Toxo','1','12600','service','2021-11-14 19:15:39');
INSERT INTO `data_assurance` VALUES ('53','716d2000','rogers','CHR Incision','1','2000','service','2021-11-14 19:24:56');
INSERT INTO `data_assurance` VALUES ('54','6d0d200','rogers','metronidazol','1','200','pharmacie','2021-11-14 19:29:34');
INSERT INTO `data_assurance` VALUES ('55','b823500','rogers','paracétamol','5','500','pharmacie','2021-11-14 19:30:11');
INSERT INTO `data_assurance` VALUES ('56','8b90200','rogers','paracétamol','2','200','pharmacie','2021-11-14 19:39:48');
INSERT INTO `data_assurance` VALUES ('57','015e49500','rogers','LAB AMH','1','48000','service','2021-11-15 10:36:48');
INSERT INTO `data_assurance` VALUES ('58','015e49500','rogers','LAB BU','1','1000','service','2021-11-15 10:36:48');
INSERT INTO `data_assurance` VALUES ('59','015e49500','rogers','CHR Pansement simple','1','500','service','2021-11-15 10:36:49');
INSERT INTO `data_assurance` VALUES ('60','4fe125100','rogers','LAB Cholestérol total','1','3600','service','2021-11-15 10:44:54');
INSERT INTO `data_assurance` VALUES ('61','4fe125100','rogers','CHR Pansement simple','1','500','service','2021-11-15 10:44:54');
INSERT INTO `data_assurance` VALUES ('62','4fe125100','rogers','Echo Dopper Testiculaire','1','20000','service','2021-11-15 10:44:55');
INSERT INTO `data_assurance` VALUES ('63','4fe125100','rogers','LAB BU','1','1000','service','2021-11-15 10:44:54');
INSERT INTO `data_assurance` VALUES ('64','458e1400','rogers','metronidazol','2','400','pharmacie','2021-11-19 19:03:26');
INSERT INTO `data_assurance` VALUES ('65','458e1400','rogers','sayana press','2','1000','pharmacie','2021-11-19 19:03:26');
INSERT INTO `data_assurance` VALUES ('66','beb41100','rogers','metronidazol','3','600','pharmacie','2021-11-20 04:45:05');
INSERT INTO `data_assurance` VALUES ('67','beb41100','rogers','transfuseur','1','500','pharmacie','2021-11-20 04:45:05');
INSERT INTO `data_assurance` VALUES ('68','f3e41800','rogers','amoxi','9','1800','pharmacie','2021-11-25 20:44:59');
INSERT INTO `data_assurance` VALUES ('69','bf931500','baba','MED Hospitalisation simple','1','1500','service','2021-12-09 15:02:27');
INSERT INTO `data_assurance` VALUES ('70','852e10800','baba','LAB Hémoglobine glycossylée (HBA1C)','1','10800','service','2021-12-09 15:03:05');
INSERT INTO `data_assurance` VALUES ('71','0cab750','baba','amoxiciline','1','250','pharmacie','2021-12-20 07:47:37');
INSERT INTO `data_assurance` VALUES ('72','0cab750','baba','paracétamol','5','500','pharmacie','2021-12-20 07:47:37');
INSERT INTO `data_assurance` VALUES ('73','f64221500','presnel','LAB BU','1','1000','service','2022-01-26 03:40:08');
INSERT INTO `data_assurance` VALUES ('74','f64221500','presnel','LAB ACE','1','20000','service','2022-01-26 03:40:08');
INSERT INTO `data_assurance` VALUES ('75','b3911600','presnel','amoxi','7','1400','pharmacie','2022-01-26 03:41:46');
INSERT INTO `data_assurance` VALUES ('76','b3911600','presnel','ccc','2','200','pharmacie','2022-01-26 03:41:46');
INSERT INTO `data_assurance` VALUES ('77','b3911600','presnel','amoxi','7','1400','pharmacie','2022-01-26 04:03:54');
INSERT INTO `data_assurance` VALUES ('78','b3911600','presnel','ccc','2','200','pharmacie','2022-01-26 04:03:54');
INSERT INTO `data_assurance` VALUES ('79','0f693400','erwin','sayana press','4','2000','pharmacie','2022-01-26 04:15:48');
INSERT INTO `data_assurance` VALUES ('80','0f693400','erwin','amoxi','7','1400','pharmacie','2022-01-26 04:15:48');
INSERT INTO `data_assurance` VALUES ('83','bc0715500','erwin','MED Soins infirmiers','1','1000','service','2022-01-26 04:22:04');
INSERT INTO `data_assurance` VALUES ('84','bc0715500','erwin','LAB Selle + ATB','1','14000','service','2022-01-26 04:22:04');
INSERT INTO `data_assurance` VALUES ('85','d768200','erwin','amoxi','1','200','pharmacie','2022-01-26 04:29:48');
INSERT INTO `data_assurance` VALUES ('86','e01722500','erwin','MED Soins infirmiers','1','1000','service','2022-01-26 05:51:14');
INSERT INTO `data_assurance` VALUES ('87','e01722500','erwin','LAB GE','1','1000','service','2022-01-26 05:51:14');
INSERT INTO `data_assurance` VALUES ('88','e01722500','erwin','LAB ACE','1','20000','service','2022-01-26 05:51:14');
INSERT INTO `data_assurance` VALUES ('89','c2471000','erwin','amoxi','4','800','pharmacie','2022-01-26 05:51:29');
INSERT INTO `data_assurance` VALUES ('90','c2471000','erwin','ccc','2','200','pharmacie','2022-01-26 05:51:29');
INSERT INTO `data_assurance` VALUES ('91','4adf25000','erwin','LAB TPHA/VDRL','1','4500','Laboratoire','2022-01-27 21:06:59');
INSERT INTO `data_assurance` VALUES ('92','4adf25000','erwin','LAB ACE','1','20000','Laboratoire','2022-01-27 21:06:59');
INSERT INTO `data_assurance` VALUES ('93','e07c450','erwin','ccc','2','200','pharmacie','2022-01-28 12:39:39');
INSERT INTO `data_assurance` VALUES ('94','e07c450','erwin','metronidazol','1','250','pharmacie','2022-01-28 12:39:39');
INSERT INTO `data_assurance` VALUES ('95','6b0123500','erwin','MED Hospitalisation payant','1','3000','Medecine','2022-01-28 14:40:25');
INSERT INTO `data_assurance` VALUES ('96','6b0123500','erwin','LAB ACE','1','20000','Laboratoire','2022-01-28 14:40:25');
INSERT INTO `data_assurance` VALUES ('97','6e21100','erwin','ccc','1','100','pharmacie','2022-01-28 15:35:28');
INSERT INTO `data_assurance` VALUES ('98','43e71100','erwin','metronidazol','4','1000','pharmacie','2022-01-28 17:29:59');
INSERT INTO `data_assurance` VALUES ('99','43e71100','erwin','ccc','1','100','pharmacie','2022-01-28 17:29:59');
INSERT INTO `data_assurance` VALUES ('100','207923600','baba','LAB D.dimeres','1','20000','Laboratoire','2022-01-29 14:55:32');
INSERT INTO `data_assurance` VALUES ('101','207923600','baba','LAB Magnésium','1','3600','Laboratoire','2022-01-29 14:55:32');
INSERT INTO `data_assurance` VALUES ('102','72637700','baba','minoxidil 300ml','1','7500','pharmacie','2022-01-29 14:56:15');
INSERT INTO `data_assurance` VALUES ('103','72637700','baba','amoxi','1','200','pharmacie','2022-01-29 14:56:15');
INSERT INTO `data_assurance` VALUES ('104','b195650','baba','amoxi','2','400','pharmacie','2022-01-29 14:57:08');
INSERT INTO `data_assurance` VALUES ('105','b195650','baba','perfuseur','1','250','pharmacie','2022-01-29 14:57:08');
INSERT INTO `data_assurance` VALUES ('106','159d750','presnel','sayana press','1','500','pharmacie','2022-01-29 14:57:50');
INSERT INTO `data_assurance` VALUES ('107','159d750','presnel','metronidazol','1','250','pharmacie','2022-01-29 14:57:50');
INSERT INTO `data_assurance` VALUES ('108','35de1250','presnel','metronidazol','5','1250','pharmacie','2022-01-29 14:58:03');
INSERT INTO `data_assurance` VALUES ('109','995c250','baba','perfuseur','1','250','pharmacie','2022-01-29 15:08:06');
INSERT INTO `data_assurance` VALUES ('110','9lv58pi14000','erwin','LAB ECBU + ATB','1','12000','Laboratoire','2022-01-31 19:27:50');
INSERT INTO `data_assurance` VALUES ('111','9lv58pi14000','erwin','LAB PCV','1','2000','Laboratoire','2022-01-31 19:27:50');
INSERT INTO `data_assurance` VALUES ('112','4mh9e0a12000','rogers','LAB ALAT ASAT','1','8000','Laboratoire','2022-02-10 10:24:01');
INSERT INTO `data_assurance` VALUES ('113','4mh9e0a12000','rogers','LAB ASLO','1','4000','Laboratoire','2022-02-10 10:24:02');
INSERT INTO `data_assurance` VALUES ('114','4ffe459650700','baba','sayana press','1','500','pharmacie','2022-02-17 16:17:39');
INSERT INTO `data_assurance` VALUES ('115','4ffe459650700','baba','paracétamol','2','200','pharmacie','2022-02-17 16:17:39');
INSERT INTO `data_assurance` VALUES ('116','4ffe459650700','baba','sayana press','1','500','pharmacie','2022-02-17 16:17:39');
INSERT INTO `data_assurance` VALUES ('117','4ffe459650700','baba','paracétamol','2','200','pharmacie','2022-02-17 16:17:39');
INSERT INTO `data_assurance` VALUES ('118','dto2l5s14000','erwin','LAB AC anti Hbs','1','13500','Laboratoire','2022-02-21 18:57:53');
INSERT INTO `data_assurance` VALUES ('119','vs8gtqv14500','rogers','LAB Spermogramme','1','14000','Laboratoire','2022-02-28 18:03:06');
INSERT INTO `data_assurance` VALUES ('120','6ptbgn78000','baba','LAB Chlamydia','1','8000','Laboratoire','2022-02-28 18:06:32');
INSERT INTO `data_assurance` VALUES ('121','bf9n0e91000','baba','CA Carnet pédiatrie','1','1000','Carnet','2022-02-28 18:07:17');
INSERT INTO `data_assurance` VALUES ('122','3tbqf6b10000','baba','CHR K10','1','10000','Chirurgie','2022-02-28 20:43:24');
INSERT INTO `data_assurance` VALUES ('123','4c678c42e1500','baba','metronidazol','2','500','pharmacie','2022-02-28 21:07:44');
INSERT INTO `data_assurance` VALUES ('128','c18f6c108f400','rogers','amoxi','2','400','pharmacie','2022-03-01 12:53:39');
INSERT INTO `data_assurance` VALUES ('129','c18f6c108f400','rogers','amoxi','2','400','pharmacie','2022-03-01 12:53:39');
INSERT INTO `data_assurance` VALUES ('130','c18f6c108f400','rogers','amoxi','2','400','pharmacie','2022-03-01 12:53:39');
INSERT INTO `data_assurance` VALUES ('131','c7fbfc2cc6400','baba','amoxi','2','400','pharmacie','2022-03-01 12:59:33');
INSERT INTO `data_assurance` VALUES ('132','3a228478ac400','erwin','amoxi','2','400','pharmacie','2022-03-01 13:03:27');
INSERT INTO `data_assurance` VALUES ('133','b57e08914e400','baba','amoxi','2','400','pharmacie','2022-03-01 13:04:32');
INSERT INTO `data_assurance` VALUES ('134','bfe4a83d02250','baba','amoxiciline','1','250','pharmacie','2022-03-02 12:51:26');
INSERT INTO `data_assurance` VALUES ('135','do9la8t2500','erwin','LAB Groupe sanguin (GS RH)','1','2000','Laboratoire','2022-03-02 15:52:33');
INSERT INTO `data_assurance` VALUES ('136','8258djn40500','erwin','Echographie parties molles','1','10000','Imagerie','2022-03-20 20:30:25');
INSERT INTO `data_assurance` VALUES ('137','8258djn40500','erwin','Echo Mammographie','1','30000','Imagerie','2022-03-20 20:30:25');
INSERT INTO `data_assurance` VALUES ('138','hhsnle45000','erwin','CHR Circoncision','1','5000','Chirurgie','2022-03-25 05:08:23');
INSERT INTO `data_assurance` VALUES ('139','ni5h2of18000','erwin','LAB LH','1','18000','Laboratoire','2022-03-25 05:10:45');
INSERT INTO `data_assurance` VALUES ('140','k6ifm8l2500','erwin','LAB PU','1','2000','Laboratoire','2022-03-25 05:11:19');
INSERT INTO `data_assurance` VALUES ('141','a67671eec34000','erwin','paracétamol','4','400','pharmacie','2022-03-25 05:22:42');
INSERT INTO `data_assurance` VALUES ('142','a67671eec34000','erwin','arthemeter','2','3600','pharmacie','2022-03-25 05:22:42');
INSERT INTO `data_assurance` VALUES ('143','0657d847e31800','erwin','arthemeter','1','1800','pharmacie','2022-03-25 05:26:30');
INSERT INTO `data_assurance` VALUES ('144','jpdhi1n5000','rogers','CHR Circoncision','1','5000','Chirurgie','2022-03-25 05:37:00');
INSERT INTO `data_assurance` VALUES ('145','fvlh9015000','erwin','CHR Circoncision','1','5000','Chirurgie','2022-03-25 05:37:38');
INSERT INTO `data_assurance` VALUES ('146','dajtm5h1500','erwin','CHR K1','1','1000','chirurgie','2022-03-25 05:38:03');
INSERT INTO `data_assurance` VALUES ('147','926v1hl2000','erwin','CHR Incision','1','2000','Chirurgie','2022-03-27 12:00:16');
INSERT INTO `data_assurance` VALUES ('148','17ae1e720e100','erwin','paracétamol','1','100','pharmacie','2022-05-06 21:06:28');
INSERT INTO `data_assurance` VALUES ('149','lg10hgt6400','erwin','CHR Circoncision','1','5000','Chirurgie','2022-07-12 19:08:40');
INSERT INTO `data_assurance` VALUES ('150','lg10hgt6400','erwin','CA Consultation simple','1','900','Carnet','2022-07-12 19:08:40');
INSERT INTO `data_assurance` VALUES ('151','5053ee34de700','baba','ccc','1','100','pharmacie','2022-07-18 12:18:48');
INSERT INTO `data_assurance` VALUES ('152','5053ee34de700','baba','sayana press','1','500','pharmacie','2022-07-18 12:18:48');
INSERT INTO `data_assurance` VALUES ('153','5053ee34de700','baba','paracétamol','1','100','pharmacie','2022-07-18 12:18:48');
INSERT INTO `data_assurance` VALUES ('154','f52974eee22000','baba','sayana press','3','1500','pharmacie','2022-07-18 12:30:59');
INSERT INTO `data_assurance` VALUES ('155','f52974eee22000','baba','metronidazol','2','500','pharmacie','2022-07-18 12:30:59');
INSERT INTO `data_assurance` VALUES ('158','a354f9be882150','baba','malacur','2','2000','pharmacie','2022-10-12 15:55:32');
INSERT INTO `data_assurance` VALUES ('159','a354f9be882150','baba','ibuprofene','1','150','pharmacie','2022-10-12 15:55:32');
INSERT INTO `data_assurance` VALUES ('160','d60995bdd01500','baba','arthemeter','1','1500','pharmacie','2022-10-12 16:00:28');


DROP TABLE IF EXISTS `details_recette`;
CREATE TABLE `details_recette` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_recette` varchar(255) NOT NULL,
  `categorie` varchar(255) NOT NULL,
  `recette` int(11) NOT NULL,
  `pourcentage` int(11) NOT NULL,
  `recette_restante` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4;

INSERT INTO `details_recette` VALUES ('1','867638900','Pharmacie','2800','0','2800');
INSERT INTO `details_recette` VALUES ('2','867638900','Maternité','7600','0','7600');
INSERT INTO `details_recette` VALUES ('3','867638900','Laboratoire','0','0','0');
INSERT INTO `details_recette` VALUES ('4','867638900','Radiologie','20000','45','11000');
INSERT INTO `details_recette` VALUES ('5','867638900','Petite chirurgie','2000','0','2000');
INSERT INTO `details_recette` VALUES ('6','867638900','Médécine','1500','0','1500');
INSERT INTO `details_recette` VALUES ('7','867638900','Echographie','0','0','0');
INSERT INTO `details_recette` VALUES ('8','867638900','Consultation','5000','0','5000');
INSERT INTO `details_recette` VALUES ('9','867638900','Upec','0','0','0');
INSERT INTO `details_recette` VALUES ('28','5b5645000','Pharmacie','0','0','0');
INSERT INTO `details_recette` VALUES ('29','5b5645000','Radiologie','0','0','0');
INSERT INTO `details_recette` VALUES ('30','5b5645000','Laboratoire','35000','45','19250');
INSERT INTO `details_recette` VALUES ('31','5b5645000','Maternité','0','0','0');
INSERT INTO `details_recette` VALUES ('32','5b5645000','Echographie','0','0','0');
INSERT INTO `details_recette` VALUES ('33','5b5645000','Médécine','0','0','0');
INSERT INTO `details_recette` VALUES ('34','5b5645000','Petite chirurgie','10000','0','10000');
INSERT INTO `details_recette` VALUES ('35','5b5645000','Consultation','0','0','0');
INSERT INTO `details_recette` VALUES ('36','5b5645000','Upec','0','0','0');
INSERT INTO `details_recette` VALUES ('37','d7de33000','Pharmacie','0','0','0');
INSERT INTO `details_recette` VALUES ('38','d7de33000','Radiologie','15000','0','15000');
INSERT INTO `details_recette` VALUES ('39','d7de33000','Echographie','0','0','0');
INSERT INTO `details_recette` VALUES ('40','d7de33000','Maternité','5000','45','2750');
INSERT INTO `details_recette` VALUES ('41','d7de33000','Médécine','0','0','0');
INSERT INTO `details_recette` VALUES ('42','d7de33000','Petite chirurgie','12000','0','12000');
INSERT INTO `details_recette` VALUES ('43','d7de33000','Laboratoire','0','0','0');
INSERT INTO `details_recette` VALUES ('44','d7de33000','Upec','0','0','0');
INSERT INTO `details_recette` VALUES ('45','d7de33000','Consultation','1000','0','1000');
INSERT INTO `details_recette` VALUES ('46','1b40144000','Pharmacie','0','0','0');
INSERT INTO `details_recette` VALUES ('47','1b40144000','Maternité','0','0','0');
INSERT INTO `details_recette` VALUES ('48','1b40144000','Médécine','4000','50','500');
INSERT INTO `details_recette` VALUES ('49','1b40144000','Laboratoire','70000','45','38500');
INSERT INTO `details_recette` VALUES ('50','1b40144000','Echographie','12000','0','12000');
INSERT INTO `details_recette` VALUES ('51','1b40144000','Petite chirurgie','26000','0','26000');
INSERT INTO `details_recette` VALUES ('52','1b40144000','Radiologie','32000','45','11000');
INSERT INTO `details_recette` VALUES ('53','1b40144000','Upec','0','0','0');
INSERT INTO `details_recette` VALUES ('54','1b40144000','Consultation','0','0','0');
INSERT INTO `details_recette` VALUES ('55','5402128000','Pharmacie','0','0','0');
INSERT INTO `details_recette` VALUES ('56','5402128000','Radiologie','20000','0','0');
INSERT INTO `details_recette` VALUES ('57','5402128000','Maternité','0','0','0');
INSERT INTO `details_recette` VALUES ('58','5402128000','Médécine','9000','0','4500');
INSERT INTO `details_recette` VALUES ('59','5402128000','Laboratoire','48000','45','26400');
INSERT INTO `details_recette` VALUES ('60','5402128000','Echographie','48000','0','48000');
INSERT INTO `details_recette` VALUES ('61','5402128000','Petite chirurgie','3000','0','3000');
INSERT INTO `details_recette` VALUES ('62','5402128000','Upec','0','0','0');
INSERT INTO `details_recette` VALUES ('63','5402128000','Consultation','0','0','0');


DROP TABLE IF EXISTS `facture_assurance`;
CREATE TABLE `facture_assurance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_facture` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `assurance` varchar(200) NOT NULL,
  `assurance_type` int(11) NOT NULL,
  `periode` text NOT NULL,
  `total` int(11) NOT NULL,
  `reste` int(11) NOT NULL,
  `date_heure` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;

INSERT INTO `facture_assurance` VALUES ('1','fkf','Alan Kamga','assuretous','80','du 2021-10-27 au 2021-10-27','14850','11880','2021-10-27 18:53:50');
INSERT INTO `facture_assurance` VALUES ('16','f6s','Alan Kamga','assuretous','80','du 2021-10-27 au 2021-10-27','2700','2160','2021-10-27 19:10:05');
INSERT INTO `facture_assurance` VALUES ('17','mep','Bob Manga','ascoma','90','du 2021-10-25 au 2021-10-27','1000','900','2021-10-27 19:14:11');
INSERT INTO `facture_assurance` VALUES ('18','ps1','Richard Kenfack','ascoma','80','du 2021-10-25 au 2021-10-27','1000','800','2021-10-27 19:19:12');
INSERT INTO `facture_assurance` VALUES ('19','9ne','Alan Kamga','assuretous','80','du 2021-10-27 au 2021-10-27','45850','36680','2021-10-27 21:10:18');
INSERT INTO `facture_assurance` VALUES ('20','gqods2v','Alan Kamga','assuretous','80','du 2021-10-28 au 2021-10-28','22550','18040','2021-10-28 15:49:48');
INSERT INTO `facture_assurance` VALUES ('21','ohe5voi','abel','assuretous','80','du 2021-10-28 au 2021-10-28','24750','19800','2021-10-28 15:50:42');
INSERT INTO `facture_assurance` VALUES ('22','r77ka32','ekedi','ascoma','100','du 2021-10-25 au 2021-11-02','7050','7050','2021-11-02 11:17:09');
INSERT INTO `facture_assurance` VALUES ('23','lgma68k','baba','assuretous','100','du 2021-12-13 au 2022-01-12','750','750','2022-01-13 14:21:49');
INSERT INTO `facture_assurance` VALUES ('24','j19nplq','erwin','Ascoma','80','du 2022-01-26 au 2022-01-26','19100','15280','2022-01-26 05:42:01');
INSERT INTO `facture_assurance` VALUES ('25','kdiacdv','presnel','AssureTous','90','du 2022-01-26 au 2022-01-26','23100','20790','2022-01-26 05:49:16');
INSERT INTO `facture_assurance` VALUES ('26','htafe9u','presnel','assuretous','90','du 2022-01-29 14:49:12 au 2022-01-29 15:07:53','2000','1800','2022-01-29 15:17:56');
INSERT INTO `facture_assurance` VALUES ('27','qb800en','baba','AssureTous','100','du 2022-01-29 14:49:12 au 2022-01-29 15:07:53','32200','32200','2022-01-29 15:20:06');
INSERT INTO `facture_assurance` VALUES ('28','v9be8se','erwin','Ascoma','80','du 26 janvier 2022 au 28 janvier 2022','73650','58920','2022-01-31 19:25:12');
INSERT INTO `facture_assurance` VALUES ('29','vdhsaki','rogers','assuretous','80','du 28 fevrier 2022 au 28 fevrier 2022','14500','11600','2022-02-28 20:45:00');
INSERT INTO `facture_assurance` VALUES ('30','7sl2fgh','erwin','Ascoma','80','du 25 mars 2022 au 25 mars 2022','37800','30240','2022-03-25 05:50:21');
INSERT INTO `facture_assurance` VALUES ('31','af8d42a','baba','assuretous','100','du 18 juillet 2022 au 18 juillet 2022','2700','2700','2022-07-18 12:33:13');


DROP TABLE IF EXISTS `facture_caisse`;
CREATE TABLE `facture_caisse` (
  `id_fac` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `caissier` varchar(255) NOT NULL,
  `patient` varchar(255) NOT NULL,
  `prix_total` int(11) NOT NULL,
  `frais` int(11) NOT NULL,
  `reduction` int(11) NOT NULL,
  `a_payer` int(11) NOT NULL,
  `montant_verse` int(11) NOT NULL,
  `relicat` int(11) NOT NULL,
  `reste_a_payer` int(11) NOT NULL,
  `date_heure` datetime NOT NULL,
  `assurance` varchar(255) NOT NULL,
  `type_assurance` int(11) NOT NULL,
  `statu` varchar(50) NOT NULL,
  PRIMARY KEY (`id_fac`)
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=utf8mb4;

INSERT INTO `facture_caisse` VALUES ('27','18820210119979272348512067101124','Kamdem','Bob Manga','3000','0','0','3000','5000','2000','0','2021-09-18 11:24:10','','0','');
INSERT INTO `facture_caisse` VALUES ('28','188202101224209999835409441129','Kamdem','Bob Manga','1000','0','0','1000','1000','0','0','2021-09-18 11:29:44','','0','');
INSERT INTO `facture_caisse` VALUES ('29','18820210104110086000194069151132','Kamdem','Richard Kenfack','1000','0','0','1000','1000','0','0','2021-09-18 11:32:15','','0','');
INSERT INTO `facture_caisse` VALUES ('30','1882021016216561415268023231211','Kamdem','Alan Kamga','10000','0','0','10000','10000','0','0','2021-09-18 12:11:23','','0','');
INSERT INTO `facture_caisse` VALUES ('31','228202101337958321233437481523','Kamdem','ali mohammed','37000','0','0','37000','40000','3000','0','2021-09-22 15:23:08','','0','');
INSERT INTO `facture_caisse` VALUES ('32','2282021015789711085626144291528','Dr Obam','Richard Kenfack','100000','0','50','50000','50000','0','0','2021-09-22 15:28:29','','0','');
INSERT INTO `facture_caisse` VALUES ('33','22820210131175246131643286302252','Kamdem','Bob Manga','1000','0','0','1000','2000','1000','0','2021-09-22 22:52:30','','0','');
INSERT INTO `facture_caisse` VALUES ('34','2282021017403196316881238542252','Kamdem','Richard Kenfack','5000','0','0','5000','5000','0','0','2021-09-22 22:52:54','','0','');
INSERT INTO `facture_caisse` VALUES ('35','238202101198704787165056241954','Kamdem','Richard Kenfack','20000','0','0','20000','20000','0','0','2021-09-23 09:54:01','','0','');
INSERT INTO `facture_caisse` VALUES ('36','238202101177063916033074486957','Kamdem','Nolla','6000','0','50','3000','10000','7000','0','2021-09-23 09:57:06','','0','');
INSERT INTO `facture_caisse` VALUES ('37','19202101623393367672800716055','Kamdem','Richard Kenfack','2000','0','0','2000','2000','0','0','2021-10-01 00:55:17','','0','');
INSERT INTO `facture_caisse` VALUES ('38','19202101950887884150173116114','Kamdem','Alan Kamga','10000','0','0','10000','10000','0','0','2021-10-01 01:14:16','','0','');
INSERT INTO `facture_caisse` VALUES ('39','192021010638884030351858424119','Kamdem','Bob Manga','10000','0','0','10000','10000','0','0','2021-10-01 01:19:24','','0','');
INSERT INTO `facture_caisse` VALUES ('40','192021011134685269710935512142','Kamdem','Richard Kenfack','2000','0','0','2000','2000','0','0','2021-10-01 01:42:12','','0','');
INSERT INTO `facture_caisse` VALUES ('41','19202101226977731707909580144','Kamdem','ali mohammed','1000','0','0','1000','1000','0','0','2021-10-01 01:44:00','','0','');
INSERT INTO `facture_caisse` VALUES ('42','1920210166302306143280356146','Kamdem','Bob Manga','14000','0','0','14000','14000','0','0','2021-10-01 01:46:56','','0','');
INSERT INTO `facture_caisse` VALUES ('43','19202101140995588024167343629','Kamdem','Bob Manga','10000','0','0','10000','10000','0','0','2021-10-01 02:09:36','','0','');
INSERT INTO `facture_caisse` VALUES ('44','19202101386926404517832950210','Kamdem','ali mohammed','1000','0','0','1000','1000','0','0','2021-10-01 02:10:50','','0','');
INSERT INTO `facture_caisse` VALUES ('45','19202101857582479818230838256','Kamdem','Richard Kenfack','500','0','0','500','500','0','0','2021-10-01 02:56:38','','0','');
INSERT INTO `facture_caisse` VALUES ('46','192021010473955552067641955730','Kamdem','Nolla','500','0','0','500','500','0','0','2021-10-01 03:00:57','','0','');
INSERT INTO `facture_caisse` VALUES ('47','392021019275605961920956481922','Kamdem','Nolla','112500','0','0','112500','115000','2500','0','2021-10-03 19:22:48','','0','');
INSERT INTO `facture_caisse` VALUES ('48','392021016269490718940572343','Kamdem','Richard Kenfack','28500','0','0','28500','28500','0','0','2021-10-03 23:43:07','','0','');
INSERT INTO `facture_caisse` VALUES ('49','49202101030359975529935083207','Kamdem','Nolla','3000','0','0','3000','3000','0','0','2021-10-04 00:07:32','','0','');
INSERT INTO `facture_caisse` VALUES ('50','59202101663952295399742150197','Kamdem','Bob Manga','55000','0','0','55000','60000','5000','0','2021-10-05 19:07:50','','0','');
INSERT INTO `facture_caisse` VALUES ('51','69202101665831606096897625836','Kamdem','Alan Kamga','13500','0','0','13500','15000','1500','0','2021-10-06 08:36:25','','0','');
INSERT INTO `facture_caisse` VALUES ('52','69202101858513092452877931838','Kamdem','ali mohammed','4500','0','0','4500','5000','500','0','2021-10-06 08:38:31','','0','');
INSERT INTO `facture_caisse` VALUES ('53','692021019303816969979544291234','Kamdem','Bob Manga','1000','0','0','1000','1000','0','0','2021-10-06 12:34:29','','0','');
INSERT INTO `facture_caisse` VALUES ('54','692021010732292521303827830131','Kamdem','abel','10000','0','0','10000','10000','0','0','2021-10-06 13:01:30','','0','');
INSERT INTO `facture_caisse` VALUES ('55','692021012325474606859818728135','Kamdem','masse','50300','0','0','50300','50300','0','0','2021-10-06 13:05:28','','0','');
INSERT INTO `facture_caisse` VALUES ('56','692021018870879161099268351310','Kamdem','ekedi','3500','0','0','3500','4000','500','0','2021-10-06 13:10:35','','0','');
INSERT INTO `facture_caisse` VALUES ('57','69202101371016474820312491341','Kamdem','ali mohammed','1000','0','0','1000','1000','0','0','2021-10-06 13:41:09','','0','');
INSERT INTO `facture_caisse` VALUES ('58','692021014140097386492354421342','Kamdem','mbezele','1000','0','0','1000','1000','0','0','2021-10-06 13:42:42','','0','');
INSERT INTO `facture_caisse` VALUES ('59','69202101765434379205538501348','Kamdem','kengne marie','33100','0','0','33100','35000','1900','0','2021-10-06 13:48:00','','0','');
INSERT INTO `facture_caisse` VALUES ('60','69202101568828491293746461349','Kamdem','Nolla','15000','0','0','15000','20000','5000','0','2021-10-06 13:49:46','','0','');
INSERT INTO `facture_caisse` VALUES ('61','692021018745001022219552561353','Kamdem','BABILLON Christian','5500','0','0','5500','6000','500','0','2021-10-06 13:53:56','','0','');
INSERT INTO `facture_caisse` VALUES ('62','692021012137960758899633571355','Kamdem','NOLLA Jules Roland','15400','0','0','15400','15500','100','0','2021-10-06 13:55:57','','0','');
INSERT INTO `facture_caisse` VALUES ('63','69202101015887847848990555131357','Kamdem','BABILLON Christian','1000','0','0','1000','1000','0','0','2021-10-06 13:57:13','','0','');
INSERT INTO `facture_caisse` VALUES ('64','11920210132491774748837292294','Kamdem','ekedi','7500','0','0','7500','10000','2500','0','2021-10-11 09:04:22','','0','');
INSERT INTO `facture_caisse` VALUES ('66','1492021010389943647516624171441','Kamdem','kengne marie','79400','0','0','79400','80000','600','0','2021-10-14 14:41:18','','0','');
INSERT INTO `facture_caisse` VALUES ('68','149202101639862157864042181522','Kamdem','masse','2000','0','0','2000','2000','0','0','2021-10-14 15:22:18','','0','');
INSERT INTO `facture_caisse` VALUES ('69','1492021015812375733171891511523','Kamdem','ali mohammed','29100','0','0','29100','30000','900','0','2021-10-14 15:23:51','','0','');
INSERT INTO `facture_caisse` VALUES ('70','a5cc','Kamdem','abel','2000','0','0','2000','2000','0','0','2021-10-15 11:23:58','','0','');
INSERT INTO `facture_caisse` VALUES ('71','997c','Kamdem','Omah ley','5000','0','0','5000','5000','0','0','2021-10-17 14:54:25','','0','');
INSERT INTO `facture_caisse` VALUES ('72','37b4','Kamdem','Bob Manga','62500','0','0','62500','62500','0','0','2021-10-18 14:10:42','','0','');
INSERT INTO `facture_caisse` VALUES ('73','cc3a','Kamdem','mbezele','35000','0','0','35000','35000','0','0','2021-10-18 20:43:18','','0','');
INSERT INTO `facture_caisse` VALUES ('74','956f','Kamdem','Bob Manga','12000','0','0','2400','2500','100','0','2021-10-18 22:17:58','','0','');
INSERT INTO `facture_caisse` VALUES ('75','ffa3','Kamdem','masse','11000','0','0','11000','11000','0','0','2021-10-18 22:22:58','','0','');
INSERT INTO `facture_caisse` VALUES ('76','419d','Kamdem','bernard nanga','2000','0','0','2000','2000','0','0','2021-10-19 10:37:37','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('77','401c','Kamdem','masse','4100','0','0','820','1000','180','0','2021-10-19 10:39:30','assure tous','80','pending');
INSERT INTO `facture_caisse` VALUES ('78','620a','Kamdem','Bob Manga','1000','0','0','1000','1000','0','0','2021-10-20 10:35:20','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('79','56a7','Kamdem','Bob Manga','1000','0','0','1000','1000','0','0','2021-10-20 12:03:05','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('80','60c7','Kamdem','Richard Kenfack','2000','0','0','2000','2000','0','0','2021-10-20 12:04:10','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('82','8493','Kamdem','abel','7800','0','30','5460','5460','0','0','2021-10-23 10:47:45','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('83','3afa','Kamdem','Nolla','1000','0','50','500','500','0','0','2021-10-23 10:52:09','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('84','e868','Kamdem','Bob Manga','1000','0','30','700','700','0','0','2021-10-23 10:55:31','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('85','c390','Kamdem','abel','1000','0','0','1000','1000','0','0','2021-10-25 16:42:45','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('86','10cb','Kamdem','Nolla','3000','0','0','3000','3000','0','0','2021-10-25 16:44:36','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('87','be7a','Kamdem','ali mohammed','3000','0','0','3000','3000','0','0','2021-10-25 16:49:09','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('88','e334','Kamdem','Nolla','3000','0','30','2100','2100','0','0','2021-10-25 16:50:53','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('89','2cc0','Kamdem','ariane','1000','0','0','1000','1000','0','0','2021-10-25 16:58:47','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('92','ccee','Kamdem','Bob Manga','1000','0','0','100','100','0','0','2021-10-25 17:20:09','ascoma','90','done');
INSERT INTO `facture_caisse` VALUES ('93','4696','Kamdem','Richard Kenfack','2000','0','0','400','400','0','0','2021-10-25 17:20:51','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('94','d2b4','Kamdem','Richard Kenfack','1000','0','0','200','200','0','0','2021-10-25 17:28:37','ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('95','714d','Kamdem','ali mohammed','5000','0','0','500','500','0','0','2021-10-25 17:29:39','assuretous','90','done');
INSERT INTO `facture_caisse` VALUES ('96','bf3e','Kamdem','Alan Kamga','2000','0','0','400','400','0','0','2021-10-27 10:45:12','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('97','a96a','Kamdem','Alan Kamga','3600','0','0','720','720','0','0','2021-10-27 16:28:31','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('98','3cb9','Kamdem','Alan Kamga','7200','0','0','1440','1440','0','0','2021-10-27 18:40:00','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('99','59e1','Kamdem','Alan Kamga','4000','0','0','800','800','0','0','2021-10-27 18:45:13','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('100','c2c1','Kamdem','Alan Kamga','2700','0','0','540','540','0','0','2021-10-27 19:04:49','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('101','1c53','Kamdem','Alan Kamga','18000','0','0','3600','3600','0','0','2021-10-27 21:04:46','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('102','c804','Kamdem','Alan Kamga','24500','0','0','4900','4900','0','0','2021-10-27 21:05:21','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('103','f6d6','Kamdem','Alan Kamga','4600','0','0','920','920','0','0','2021-10-28 15:34:22','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('104','0de6','Kamdem','Alan Kamga','14300','0','0','2860','2860','0','0','2021-10-28 15:35:01','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('105','1841','Kamdem','abel','23600','0','0','4720','4720','0','0','2021-10-28 15:35:35','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('106','d9e3','Kamdem','ekedi','6400','0','0','0','0','0','0','2021-10-28 15:36:08','ascoma','100','done');
INSERT INTO `facture_caisse` VALUES ('107','649e','Kamdem','Nolla','12500','0','0','12500','12500','0','0','2021-11-12 09:16:20','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('108','9776','Kamdem','Alan Kamga','4600','0','0','4600','4600','0','0','2021-11-13 03:36:45','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('109','2518','Kamdem','BABILLON Christian','22000','0','0','22000','0','0','22000','2021-11-14 18:21:02','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('110','ec9f400','Kamdem','Richard Kenfack','400','0','0','400','400','0','0','2021-11-14 19:00:36','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('111','9f8d20000','Kamdem','rogers','20000','0','0','4000','0','0','4000','2021-11-14 19:15:03','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('112','e70d17100','Kamdem','rogers','17100','0','0','3420','6840','0','0','2021-11-14 19:15:39','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('113','716d2000','Kamdem','rogers','2000','0','0','400','400','0','0','2021-11-14 19:24:56','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('114','a12611000','Kamdem','ross','11000','0','50','5500','5500','0','0','2021-11-14 20:14:33','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('115','cc9213600','Kamdem','Nolla','13600','0','30','9520','9520','0','0','2021-11-14 20:16:03','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('116','015e49500','Kamdem','rogers','49500','0','0','9900','9900','0','0','2021-11-15 10:36:49','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('117','4fe125100','Kamdem','rogers','25100','0','0','5020','5020','0','0','2021-11-15 10:44:55','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('118','7c0363200','Kamdem','alea','63200','0','0','63200','63200','0','0','2021-11-16 10:54:49','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('119','4877400','Kamdem','baba','400','0','0','400','400','0','0','2021-12-04 15:41:16','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('120','b9a5900','Kamdem','baba','900','0','0','900','900','0','0','2021-12-04 15:43:39','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('121','7df71000','Kamdem','boba','1000','0','0','1000','1000','0','0','2021-12-04 15:49:09','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('122','902820000','Kamdem','rod','20000','0','50','10000','10000','0','0','2021-12-07 10:29:32','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('123','faac2000','Kamdem','Nolla','2000','0','0','2000','2000','0','0','2021-12-09 15:01:58','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('124','bf931500','Kamdem','baba','1500','0','0','150','150','0','0','2021-12-09 15:02:27','assuretous','90','pending');
INSERT INTO `facture_caisse` VALUES ('125','852e10800','Kamdem','baba','10800','0','0','1080','1100','20','0','2021-12-09 15:03:05','assuretous','90','pending');
INSERT INTO `facture_caisse` VALUES ('126','eef823200','Kamdem','masse','23200','0','50','11600','0','0','11600','2021-12-12 19:06:09','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('127','90c22000','Kamdem','ali mohammed','2000','0','0','2000','2000','0','0','2022-01-04 02:16:55','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('128','e9145000','Kamdem','Bob Manga','5000','0','0','5000','5000','0','0','2022-01-17 11:41:50','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('129','7cf534000','Kamdem','Alan Kamga','34000','0','50','17000','0','0','17000','2022-01-17 11:43:03','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('130','3f2f35500','Kamdem','ali mohammed','35500','0','30','24850','25000','150','0','2022-01-17 11:46:03','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('131','9fec15500','Kamdem','Nolla','15500','0','0','15500','15500','0','0','2022-01-17 11:46:51','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('132','8bc937300','Kamdem','Nolla','37300','0','0','37300','40000','2700','0','2022-01-18 13:17:14','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('133','673e31000','Kamdem','abel','31000','0','0','31000','35000','4000','0','2022-01-18 13:17:47','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('134','e1e518500','Kamdem','masse','18500','0','0','18500','19000','500','0','2022-01-18 13:18:17','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('135','81e427200','Kamdem','ali mohammed','27200','0','0','27200','30000','2800','0','2022-01-18 13:21:05','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('136','fd0292000','Kamdem','Bob Manga','92000','0','0','92000','100000','8000','0','2022-01-18 13:29:07','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('137','a4fe1000','Kamdem','ali mohammed','1000','0','0','1000','1000','0','0','2022-01-24 10:38:24','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('138','afd610600','Kamdem','abel','10600','0','0','10600','10600','0','0','2022-01-24 10:42:00','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('139','2c171000','Kamdem','Nolla','1000','0','0','1000','1000','0','0','2022-01-24 10:44:31','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('140','d0d128000','Kamdem','Alan Kamga','28000','0','0','28000','30000','2000','0','2022-01-24 10:45:04','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('141','e86216500','Kamdem','Omah ley','16500','0','0','16500','20000','3500','0','2022-01-26 03:34:19','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('142','f64221500','Kamdem','presnel','21500','0','0','2150','2150','0','0','2022-01-26 03:40:08','assuretous','90','done');
INSERT INTO `facture_caisse` VALUES ('144','bc0715500','Kamdem','erwin','15500','0','0','3100','3100','0','0','2022-01-26 04:22:04','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('145','e01722500','Kamdem','erwin','22500','0','0','4500','0','0','4500','2022-01-26 05:51:15','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('146','b73224000','Kamdem','BABILLON Christian','24000','0','0','24000','24000','0','0','2022-01-27 20:08:19','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('147','759822500','Kamdem','albar','22500','500','0','22500','22500','0','0','2022-01-27 20:17:27','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('148','c32232000','Kamdem','Alan Kamga','32000','0','0','32000','32000','0','0','2022-01-27 20:18:26','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('149','fe6930000','Kamdem','abel','30000','0','0','30000','30000','0','0','2022-01-27 20:20:51','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('150','9e2a34000','Kamdem','ali mohammed','34000','500','50','17000','20000','3000','0','2022-01-27 20:22:40','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('151','58b63000','Kamdem','Bob Manga','3000','0','50','1500','3000','1500','0','2022-01-27 20:24:09','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('152','4adf25000','Kamdem','erwin','25000','500','0','5000','5000','0','0','2022-01-27 21:07:00','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('153','6b0123500','Kamdem','erwin','23500','500','0','4700','4700','0','0','2022-01-28 14:40:25','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('154','7dr400','Kamdem','abel','400','0','0','400','400','0','0','2022-01-29 01:28:10','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('155','207923600','Kamdem','baba','23600','0','0','0','0','0','0','2022-01-29 14:55:32','assuretous','100','done');
INSERT INTO `facture_caisse` VALUES ('156','8ea53400','Kamdem','bernard nanga','3400','0','0','3400','5000','1600','0','2022-01-29 15:03:32','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('157','347b12000','Kamdem','ekedi','12000','0','30','8400','8500','100','0','2022-01-29 15:04:24','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('158','tiilech1000','Kamdem','Bob Manga','1000','0','0','1000','1000','0','0','2022-01-29 15:15:53','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('159','9lv58pi14000','Kamdem','erwin','14000','0','0','2800','2800','0','0','2022-01-31 19:27:51','Ascoma','80','pending');
INSERT INTO `facture_caisse` VALUES ('160','cmlpvue20000','Kamdem','albar','20000','0','0','20000','20000','0','0','2022-02-04 19:08:36','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('161','46d4ko320000','Kamdem','Alan Kamga','20000','0','0','20000','20000','0','0','2022-02-04 19:08:59','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('162','2vs499s25000','Kamdem','albar','25000','0','0','25000','20000','0','5000','2022-02-04 19:11:09','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('163','mi4v900','Kamdem','Alan Kamga','900','0','0','900','1000','100','0','2022-02-04 19:17:22','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('164','t1hkl4g21000','Kamdem','mbezele','21000','0','0','21000','22000','1000','0','2022-02-05 14:17:29','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('165','gc5jdf43400','Kamdem','albar','3400','500','50','1700','2000','300','0','2022-02-07 20:41:22','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('166','ol68gpp5000','Kamdem','Alan Kamga','5000','0','0','5000','5000','0','0','2022-02-10 10:20:22','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('167','c11nmta2000','Kamdem','ali mohammed','2000','0','0','2000','2000','0','0','2022-02-10 10:22:27','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('168','4mh9e0a12000','Kamdem','rogers','12000','0','0','2400','2500','100','0','2022-02-10 10:24:02','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('169','lp3glah2000','Kamdem','albar','2000','0','0','2000','2000','0','0','2022-02-10 10:49:01','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('170','2igu99r26200','Kamdem','ariane','26200','500','0','26200','27000','800','0','2022-02-10 10:57:38','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('171','otcd0c51900','Kamdem','bernard nanga','1900','0','0','1900','2000','100','0','2022-02-16 02:00:42','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('172','jlf43ld1000','Kamdem','Alan Kamga','1000','0','0','1000','1000','0','0','2022-02-21 16:00:52','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('173','kir1fcf1000','Kamdem','Bob Manga','1000','0','0','1000','1000','0','0','2022-02-21 16:01:17','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('174','49a9cs24600','er','boba','4600','0','0','4600','5100','500','0','2022-02-21 16:01:58','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('175','i8cquql5000','Kamdem','BABILLON Christian','5000','500','0','5000','5000','0','0','2022-02-21 18:19:08','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('176','dto2l5s14000','Kamdem','erwin','14000','500','0','2800','3000','200','0','2022-02-21 18:57:53','Ascoma','80','pending');
INSERT INTO `facture_caisse` VALUES ('177','timag8s10000','Kamdem','albar','10000','0','50','5000','5000','0','0','2022-02-21 19:01:09','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('178','130iu5h10000','Kamdem','Alan Kamga','10000','0','0','10000','10000','0','0','2022-02-21 19:16:47','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('179','268bvqv8500','er','bernard nanga','8500','500','0','8500','8500','0','0','2022-02-21 19:30:24','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('180','o32030h900','Kamdem','ali mohammed','900','0','0','900','0','0','900','2022-02-21 19:46:16','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('181','2jlhjcf1000','Kamdem','abel','1000','0','0','1000','1000','0','0','2022-02-21 19:47:12','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('182','vs8gtqv14500','Kamdem','rogers','14500','500','0','2900','2900','0','0','2022-02-28 18:03:06','assuretous','80','done');
INSERT INTO `facture_caisse` VALUES ('183','d4qse8030000','Kamdem','ali mohammed','30000','0','0','30000','0','0','30000','2022-02-28 18:03:27','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('184','e4os7jh48000','Kamdem','alea','48000','0','0','48000','0','0','48000','2022-02-28 18:04:05','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('186','bf9n0e91000','Kamdem','baba','1000','0','0','0','0','0','0','2022-02-28 18:07:17','assuretous','100','pending');
INSERT INTO `facture_caisse` VALUES ('187','ja033ri5000','Kamdem','ariane','5000','500','0','5000','0','0','5000','2022-02-28 18:07:45','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('188','rjb8ceo900','Kamdem','ariane','900','0','0','900','1000','100','0','2022-02-28 18:12:27','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('189','3tbqf6b10000','Kamdem','baba','10000','0','0','0','0','0','0','2022-02-28 20:43:24','assuretous','100','pending');
INSERT INTO `facture_caisse` VALUES ('190','u77v11c1000','Kamdem','ndo jamal','1000','0','0','1000','1000','0','0','2022-03-02 11:16:06','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('191','sahanqn1000','Kamdem','alfred','1000','0','0','1000','1000','0','0','2022-03-02 11:17:08','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('192','jq71o2h2000','Kamdem','ali mohammed','2000','0','0','2000','2000','0','0','2022-03-02 15:40:39','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('193','vvrrioj8000','Kamdem','ross','8000','0','0','8000','8000','0','0','2022-03-02 15:45:00','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('194','00st1gk5500','Kamdem','alfred','5500','500','0','5500','5500','0','0','2022-03-02 15:47:46','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('195','do9la8t2500','Kamdem','erwin','2500','500','0','500','500','0','0','2022-03-02 15:52:33','Ascoma','80','pending');
INSERT INTO `facture_caisse` VALUES ('196','j7kfbrs1500','Kamdem','alea','1500','500','0','1500','0','0','1500','2022-03-02 16:03:15','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('197','skv4jhs3000','Kamdem','ariane','3000','0','0','3000','5000','2000','0','2022-03-02 21:53:24','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('198','dicls4d400','Kamdem','alea','400','0','0','400','0','0','400','2022-03-02 21:55:51','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('199','f7dntcq45000','Kamdem','Alan Kamga','45000','0','0','45000','0','0','45000','2022-03-20 20:28:16','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('200','n6b5vrm42000','Kamdem','alea','42000','0','0','42000','0','0','42000','2022-03-20 20:28:32','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('201','jph3hf240500','Kamdem','ali mohammed','40500','500','0','40500','0','0','40500','2022-03-20 20:29:28','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('202','8258djn40500','Kamdem','erwin','40500','500','0','8100','0','0','8100','2022-03-20 20:30:26','Ascoma','80','pending');
INSERT INTO `facture_caisse` VALUES ('203','a0tfc352000','Kamdem','abel','2000','0','0','2000','2000','0','0','2022-03-25 04:52:56','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('204','g00rh0e4500','Kamdem','ali mohammed','4500','500','0','4500','5000','500','0','2022-03-25 04:53:48','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('205','hhsnle45000','Kamdem','erwin','5000','0','0','1000','0','0','1000','2022-03-25 05:08:23','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('206','ni5h2of18000','Kamdem','erwin','18000','0','0','3600','0','0','3600','2022-03-25 05:10:45','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('207','k6ifm8l2500','Kamdem','erwin','2500','500','0','500','0','0','500','2022-03-25 05:11:19','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('208','jpdhi1n5000','Kamdem','rogers','5000','0','0','1000','0','0','1000','2022-03-25 05:37:00','assuretous','80','pending');
INSERT INTO `facture_caisse` VALUES ('209','fvlh9015000','Kamdem','erwin','5000','0','0','1000','0','0','1000','2022-03-25 05:37:38','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('210','dajtm5h1500','Kamdem','erwin','1500','500','0','300','0','0','300','2022-03-25 05:38:03','Ascoma','80','done');
INSERT INTO `facture_caisse` VALUES ('211','926v1hl2000','Kamdem','erwin','2000','0','0','400','0','0','400','2022-03-27 12:00:16','Ascoma','80','pending');
INSERT INTO `facture_caisse` VALUES ('212','20dv1vs25000','Kamdem','abel','25000','0','0','25000','0','0','25000','2022-03-27 12:00:29','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('213','2f1emn12000','Kamdem','Omah ley','2000','0','0','2000','2000','0','0','2022-05-06 18:46:29','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('214','tebmduj7800','Kamdem','albar','7800','500','0','7800','7800','0','0','2022-05-06 18:47:30','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('215','5v3ndvp1000','Kamdem','Alan Kamga','1000','0','50','500','500','0','0','2022-05-21 14:14:48','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('216','cqlf1ed2000','Kamdem','albar','2000','0','0','2000','0','0','2000','2022-05-21 14:15:00','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('217','71tn7sr3500','Kamdem','Alan Kamga','3500','500','30','2450','2500','50','0','2022-07-12 19:05:26','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('218','lg10hgt6400','Kamdem','erwin','6400','500','0','1280','1300','20','0','2022-07-12 19:08:40','Ascoma','80','pending');
INSERT INTO `facture_caisse` VALUES ('219','qdu7c312000','Kamdem','Alan Kamga','2000','0','0','2000','2000','0','0','2022-07-12 19:16:03','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('220','8v5iuen400','Kamdem','albar','400','0','0','400','500','100','0','2022-07-19 13:08:11','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('221','lbj2au61000','Kamdem','alfred','1000','0','0','1000','1000','0','0','2022-07-19 13:34:19','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('224','uus92ld1500','Kamdem','albar','1500','500','0','1500','1500','0','0','2022-08-06 12:40:01','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('225','g9tk1hi900','Kamdem','alea','900','500','0','900','1000','100','0','2022-08-06 12:42:55','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('226','jfrqk2j5500','Kamdem','ali mohammed','5500','500','0','5500','5500','0','0','2022-08-06 12:47:57','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('227','2ihqg6i1500','Kamdem','Alan Kamga','1500','500','0','1500','1500','0','0','2022-08-06 12:50:23','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('228','8q5234t11500','Kamdem','ariane','11500','500','0','11500','12000','500','0','2022-08-06 12:50:53','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('229','i9per0518000','Kamdem','albar','18000','0','0','18000','20000','2000','0','2022-08-06 12:51:27','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('230','n1thjdu2000','Kamdem','albar','2000','0','0','2000','2000','0','0','2022-09-18 22:29:42','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('231','pl2tkv52000','Kamdem','ali mohammed','2000','0','0','2000','2000','0','0','2022-09-18 22:34:26','aucune','0','done');
INSERT INTO `facture_caisse` VALUES ('232','h7606qu1000','Kamdem','alfred','1000','0','0','1000','1000','0','0','2022-09-18 22:36:17','aucune','0','done');


DROP TABLE IF EXISTS `facture_pharmacie`;
CREATE TABLE `facture_pharmacie` (
  `id_fac` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `vendeur` varchar(255) NOT NULL,
  `caissier` varchar(255) NOT NULL,
  `patient` varchar(255) NOT NULL,
  `prix_total` int(11) NOT NULL,
  `a_payer` int(11) NOT NULL,
  `montant_verse` int(11) NOT NULL,
  `relicat` int(11) NOT NULL,
  `reste_a_payer` int(11) NOT NULL,
  `date_heure` datetime NOT NULL,
  `assurance` varchar(255) NOT NULL,
  `type_assurance` int(11) NOT NULL,
  `statu` varchar(50) NOT NULL,
  PRIMARY KEY (`id_fac`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8mb4;

INSERT INTO `facture_pharmacie` VALUES ('31','792021014866090084821688351552','','Kamdem','ross','200','200','500','300','0','2021-10-07 15:52:35','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('32','792021018228985629146843411556','','Kamdem','ariane','1700','1700','2000','300','0','2021-10-07 15:56:41','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('33','79202101600974228178926145162','','Kamdem','ekedi','200','200','500','300','0','2021-10-07 16:02:45','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('34','7920210128566028470537774461649','','Kamdem','ali mohammed','100','100','600','400','0','2021-10-07 16:49:46','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('36','1092021019236225698463736321847','','Dr Obam','Nolla','400','400','500','100','0','2021-10-10 18:47:32','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('38','119202101440571230639903246839','','Kamdem','NOLLA Jules Roland','1700','1700','2000','300','0','2021-10-11 08:39:47','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('39','119202101614247173344512356848','','Kamdem','kengne marie','150','150','150','0','0','2021-10-11 08:48:57','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('41','11920210111497887400363949291244','','Kamdem','Alan Kamga','400','400','500','100','0','2021-10-11 12:44:29','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('42','7b61','','Kamdem','ross','200','200','200','0','0','2021-10-18 19:30:09','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('44','2433','','Kamdem','Nolla','200','200','200','0','0','2021-10-26 17:33:32','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('45','4eef','','Kamdem','Alan Kamga','1800','360','1800','1440','0','2021-11-20 04:35:57','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('46','4e0f','','Kamdem','Alan Kamga','600','120','0','0','600','2021-10-27 10:07:26','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('47','c2c4','','Kamdem','Alan Kamga','2000','400','2000','1600','0','2021-11-20 04:19:53','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('48','76ab','','Kamdem','Alan Kamga','500','100','100','0','0','2021-10-27 18:50:31','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('49','bf01','','Kamdem','Alan Kamga','1150','230','0','0','1150','2021-10-27 18:51:20','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('50','3db2','','Kamdem','Alan Kamga','2150','430','500','70','0','2021-10-27 21:06:56','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('51','4c4b','','Kamdem','Alan Kamga','1200','240','1200','960','0','2021-10-27 21:07:28','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('52','c0db','','Kamdem','Alan Kamga','2000','400','2000','1600','0','2021-11-20 04:22:41','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('53','20c7','','Kamdem','Alan Kamga','900','180','200','20','0','2021-10-28 15:29:43','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('54','e2c0','','Kamdem','Alan Kamga','750','150','150','0','0','2021-10-28 15:30:09','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('55','1468','','Kamdem','abel','1150','230','250','20','0','2021-10-28 15:31:10','assuretous','80','done');
INSERT INTO `facture_pharmacie` VALUES ('56','c4ff','','Kamdem','ekedi','650','0','0','0','0','2021-10-28 15:31:50','ascoma','100','done');
INSERT INTO `facture_pharmacie` VALUES ('59','a35c','','Kamdem','rogers','1800','360','500','140','0','2021-11-12 15:25:45','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('60','9c22','','Kamdem','Bob Manga','850','850','850','0','0','2021-11-14 18:30:13','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('62','58ba2100','','Kamdem','rogers','2100','420','2100','1680','0','2021-11-14 19:06:12','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('63','6d0d200','','Kamdem','rogers','200','40','40','0','0','2021-11-14 19:29:34','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('64','b823500','','Kamdem','rogers','500','100','200','0','0','2021-11-14 19:30:11','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('66','8c24500','','Kamdem','ariane','500','500','500','0','0','2021-11-19 18:36:40','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('67','2ab52500','','Kamdem','alea','2500','2500','2500','0','0','2021-11-19 18:36:56','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('68','f6921300','','Kamdem','Omah ley','1300','1300','1300','0','0','2021-11-19 18:37:48','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('69','458e1400','','Kamdem','rogers','1400','280','280','0','0','2021-11-19 19:03:26','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('70','9a9e1500','','Kamdem','abel','1500','1500','1500','0','0','2021-11-19 19:03:49','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('71','b06c200','','Kamdem','Nolla','200','200','200','0','0','2021-11-20 04:44:41','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('72','beb41100','','Kamdem','rogers','1100','220','220','0','0','2021-11-20 04:45:05','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('73','c30d500','','Kamdem','mbezele','500','500','1000','500','0','2021-11-20 04:45:22','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('74','3d61100','','ABC','ali mohammed','100','100','0','0','100','2021-11-21 04:10:31','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('75','63ac700','','Kamdem','hhb hk','700','700','1000','300','0','2021-11-24 20:22:57','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('76','2b861800','','ABC','Bob Manga','1800','1800','0','0','1800','2021-11-25 20:14:27','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('77','ee781800','','ABC','abel','1800','1800','0','0','1800','2021-11-25 20:20:34','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('78','74391800','','ABC','masse','1800','1800','0','0','1800','2021-11-25 20:23:23','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('79','34f31800','','ABC','ekedi','1800','1800','0','0','1800','2021-11-25 20:24:12','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('80','ea0e1800','','ABC','kengne marie','1800','1800','0','0','1800','2021-11-25 20:25:49','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('81','a74a10800','','ABC','NOLLA Jules Roland','10800','10800','0','0','10800','2021-11-25 20:26:20','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('82','6a4c1800','','ABC','Richard Kenfack','1800','1800','0','0','1800','2021-11-25 20:31:51','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('83','a0df400','','Kamdem','BABILLON Christian','400','400','500','100','0','2021-11-25 20:40:27','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('84','f3e41800','','ABC','rogers','1800','360','0','0','360','2021-11-25 20:44:59','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('85','656d1800','','Kamdem','alea','1800','1800','2000','200','0','2021-12-04 16:05:28','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('86','f7fa1800','','ABC','kengne marie','1800','1800','0','0','1800','2021-11-25 20:47:22','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('87','66e71800','','Kamdem','ekedi','1800','1800','2000','200','0','2021-11-25 20:48:21','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('88','ac4b1800','','Kamdem','masse','1800','1800','2000','200','0','2021-11-25 20:50:09','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('89','42e15250','','ABC','Nolla','5250','5250','0','0','5250','2021-11-25 20:50:51','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('90','a2bc600','','Kamdem','kengne marie','600','600','600','0','0','2021-11-25 20:51:33','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('91','9fbc100','','Kamdem','albar','100','100','100','0','0','2021-12-07 10:31:11','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('92','603b3600','','Kamdem','ali mohammed','3600','3600','0','0','3600','2021-12-09 14:47:45','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('93','6860500','','Kamdem','Alan Kamga','500','500','500','0','0','2021-12-09 14:48:01','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('94','0a71500','','Kamdem','masse','500','500','500','0','0','2021-12-09 14:48:28','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('95','a9611800','','Kamdem','abel','1800','1800','0','0','1800','2021-12-10 11:39:07','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('96','efc5500','','Kamdem','BABILLON Christian','500','500','500','0','0','2021-12-10 11:44:48','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('97','561d900','','Kamdem','ali mohammed','900','900','1000','100','0','2021-12-10 11:49:51','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('98','4a6a500','','Kamdem','masse','500','500','0','0','500','2021-12-12 19:34:29','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('99','d9e5450','','Kamdem','Richard Kenfack','450','450','500','50','0','2021-12-20 07:44:28','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('100','ebaa500','','Kamdem','Bob Manga','500','500','0','0','500','2021-12-20 07:45:20','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('101','faed300','','ABC','mbezele','300','300','0','0','300','2021-12-20 07:45:51','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('102','0cab750','','Kamdem','baba','750','0','0','0','0','2021-12-20 07:47:37','assuretous','100','done');
INSERT INTO `facture_pharmacie` VALUES ('103','134b200','','Kamdem','ali mohammed','200','200','200','0','0','2022-01-17 09:21:46','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('104','aa79400','','Kamdem','Bob Manga','400','400','0','0','400','2022-01-21 10:11:10','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('105','09f6100','','Kamdem','abel','100','100','0','0','100','2022-01-21 10:11:58','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('106','c577100','','Kamdem','masse','100','100','100','0','0','2022-01-21 10:12:38','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('107','5646100','','Kamdem','ekedi','100','100','0','0','100','2022-01-21 10:19:11','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('108','068a100','','Kamdem','ekedi','100','100','100','0','0','2022-01-21 10:19:44','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('109','3415200','','Kamdem','abel','200','200','200','0','0','2022-01-21 10:20:17','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('110','9b04200','','Kamdem','masse','200','200','200','0','0','2022-01-21 10:32:57','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('111','7c49100','','Kamdem','abel','100','100','100','0','0','2022-01-21 10:34:24','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('112','608d200','','Kamdem','ali mohammed','200','200','200','0','0','2022-01-21 10:36:01','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('113','c168300','','Kamdem','Nolla','300','300','500','200','0','2022-01-21 10:37:41','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('114','65b8200','','Kamdem','Nolla','200','200','200','0','0','2022-01-21 10:40:31','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('115','b3911600','','Kamdem','presnel','1600','160','200','40','0','2022-01-26 03:41:47','assuretous','90','done');
INSERT INTO `facture_pharmacie` VALUES ('116','a400100','','Kamdem','bernard nanga','100','100','100','0','0','2022-01-26 04:05:20','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('117','8b41100','','Kamdem','ali mohammed','100','100','100','0','0','2022-01-26 04:09:01','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('118','0f693400','','Kamdem','erwin','3400','680','700','20','0','2022-01-26 04:14:58','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('119','d768200','','Kamdem','erwin','200','40','40','0','0','2022-01-26 04:29:24','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('120','c2471000','','Kamdem','erwin','1000','200','200','0','0','2022-01-26 05:50:07','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('121','e07c450','','Kamdem','erwin','450','90','100','10','0','2022-01-28 12:37:31','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('122','6e21100','','Kamdem','erwin','100','20','50','30','0','2022-01-28 15:35:08','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('123','43e71100','','Kamdem','erwin','1100','220','250','30','0','2022-01-28 17:29:42','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('124','mhe250','','Kamdem','BABILLON Christian','250','250','250','0','0','2022-01-29 01:27:10','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('125','b195650','','Kamdem','baba','650','0','0','0','0','2022-01-29 14:49:12','assuretous','100','done');
INSERT INTO `facture_pharmacie` VALUES ('126','72637700','','Kamdem','baba','7700','0','0','0','0','2022-01-29 14:50:08','assuretous','100','done');
INSERT INTO `facture_pharmacie` VALUES ('127','35de1250','','Kamdem','presnel','1250','125','200','75','0','2022-01-29 14:50:41','assuretous','90','done');
INSERT INTO `facture_pharmacie` VALUES ('128','159d750','','Kamdem','presnel','750','75','75','0','0','2022-01-29 14:51:27','assuretous','90','done');
INSERT INTO `facture_pharmacie` VALUES ('129','995c250','','Kamdem','baba','250','0','0','0','0','2022-01-29 15:07:53','assuretous','100','done');
INSERT INTO `facture_pharmacie` VALUES ('130','c55642932f250','','Kamdem','abel','250','250','250','0','0','2022-01-29 15:14:50','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('131','d9d1bdf1c8600','','Kamdem','Alan Kamga','600','600','600','0','0','2022-02-05 14:44:17','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('132','3d2f964701100','','Kamdem','abel','100','100','100','0','0','2022-02-05 14:45:45','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('133','f78da026e71800','','Kamdem','alea','1800','1800','1800','0','0','2022-02-05 15:03:13','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('134','39736e781d4250','','Kamdem','alea','4250','4250','5000','750','0','2022-02-16 01:29:58','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('135','b87faa51912750','','Kamdem','Bob Manga','2750','2750','3000','250','0','2022-02-16 01:32:05','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('137','22252d2b4f1000','','Kamdem','ariane','1000','1000','1000','0','0','2022-02-16 02:09:04','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('138','ad1009d2ed400','','Kamdem','abel','400','400','400','0','0','2022-02-17 16:15:33','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('139','29c66ea2771800','','Kamdem','ariane','1800','1800','1800','0','0','2022-02-17 16:16:15','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('140','4ffe459650700','','Kamdem','baba','700','0','0','0','0','2022-02-17 16:17:28','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('141','e7938b0357500','','Kamdem','BABILLON Christian','500','500','500','0','0','2022-02-17 16:18:04','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('142','cf13becefc500','','Kamdem','ali mohammed','500','500','500','0','0','2022-02-17 16:29:26','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('143','62930e9426500','','abc','bernard nanga','500','500','500','0','0','2022-02-17 16:57:45','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('144','4c678c42e1500','','Kamdem','baba','500','0','0','0','0','2022-02-28 21:06:53','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('145','d563423deb100','','Kamdem','alea','100','100','100','0','0','2022-02-28 21:47:27','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('146','c18f6c108f400','','Kamdem','rogers','400','80','80','0','0','2022-03-01 12:53:12','assuretous','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('147','c7fbfc2cc6400','','Kamdem','baba','400','0','0','0','0','2022-03-01 12:58:51','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('148','3a228478ac400','','Kamdem','erwin','400','80','100','20','0','2022-03-01 13:03:13','Ascoma','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('149','b57e08914e400','','Kamdem','baba','400','0','0','0','0','2022-03-01 13:04:23','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('150','5c1a49a68d200','','Kamdem','Alan Kamga','200','200','200','0','0','2022-03-01 13:09:40','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('151','5d63cb5d17250','','Kamdem','alfred','250','250','250','0','0','2022-03-02 12:16:36','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('153','bfe4a83d02250','','Kamdem','baba','250','0','0','0','0','2022-03-02 12:47:16','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('154','72e6032c21600','','Kamdem','alea','600','600','600','0','0','2022-03-25 04:47:49','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('155','5740488a20750','','ABC','ariane','750','750','0','0','750','2022-03-25 04:48:51','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('156','0657d847e31800','','Kamdem','erwin','1800','360','500','140','0','2022-03-25 05:21:37','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('157','a67671eec34000','','Kamdem','erwin','4000','800','1000','200','0','2022-03-25 05:21:55','Ascoma','80','done');
INSERT INTO `facture_pharmacie` VALUES ('158','d40d87da541250','','Kamdem','Alan Kamga','1250','1250','1500','250','0','2022-05-06 21:05:46','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('159','faa4e6f280500','','Kamdem','ariane','500','500','500','0','0','2022-05-06 21:06:06','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('160','17ae1e720e100','','Kamdem','erwin','100','20','50','30','0','2022-05-06 21:06:18','Ascoma','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('161','03a903dd47500','','Kamdem','ali mohammed','500','500','500','0','0','2022-05-06 21:08:19','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('162','d437614dfb200','','Kamdem','albar','200','200','200','0','0','2022-05-08 09:59:26','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('163','332da40f202500','','ABC','alea','2500','2500','0','0','2500','2022-07-12 19:28:50','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('164','860256bc53200','','Kamdem','albar','200','200','200','0','0','2022-07-18 12:07:43','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('165','98375968907500','','Kamdem','ariane','7500','7500','7500','0','0','2022-07-18 12:12:38','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('166','d20bd1987d1450','','Kamdem','abel','1450','1450','1500','50','0','2022-07-18 12:13:33','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('167','5053ee34de700','','Kamdem','baba','700','0','0','0','0','2022-07-18 12:16:17','assuretous','100','done');
INSERT INTO `facture_pharmacie` VALUES ('168','f52974eee22000','','Kamdem','baba','2000','0','0','0','0','2022-07-18 12:30:45','assuretous','100','done');
INSERT INTO `facture_pharmacie` VALUES ('169','12d4792bb8100','','Kamdem','alea','100','100','100','0','0','2022-07-18 13:03:13','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('170','9dc6acd3a01000','','Kamdem','alfred','1000','1000','2000','1000','0','2022-07-18 15:59:23','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('171','335487e1dd100','','ABC','erwin','100','20','0','0','20','2022-07-18 16:00:44','Ascoma','80','pending');
INSERT INTO `facture_pharmacie` VALUES ('172','5a1f1a3c0d500','','ABC','ali mohammed','500','500','0','0','500','2022-07-18 16:27:34','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('173','35c300e8552250','','Kamdem','alfred','2250','2250','2500','250','0','2022-07-19 11:28:07','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('174','26feb5004b1500','','Kamdem','alea','1500','1500','0','0','1500','2022-07-20 16:00:39','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('175','ee9c7ceae21250','','er','alea','1250','1250','1500','250','0','2022-07-28 11:40:00','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('176','e85697cac7500','','er','albar','500','500','500','0','0','2022-07-28 11:40:12','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('177','2ba2be5ad01500','','er','BABILLON Christian','1500','1500','1500','0','0','2022-07-28 11:40:27','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('178','217b01de521000','','Kamdem','alea','1000','1000','0','0','1000','2022-08-18 15:03:39','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('179','b640abc9123600','','Kamdem','albar','3600','3600','0','0','3600','2022-08-18 15:07:55','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('180','6fe44aa6c540700','','ABC','emilie','40700','40700','0','0','40700','2022-10-09 13:16:22','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('181','4c9c3a337c53900','','ABC','rodin','53900','53900','0','0','53900','2022-10-09 13:19:35','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('182','e328718eee7900','','ABC','ariane','7900','7900','0','0','7900','2022-10-09 13:21:46','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('183','77ee73b0b4400','','ABC','alea','400','400','0','0','400','2022-10-09 13:22:29','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('184','7af913dc7e37900','','ABC','bernard nanga','37900','37900','0','0','37900','2022-10-09 13:24:48','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('185','4d55ce80856150','','ABC','alea','6150','6150','0','0','6150','2022-10-09 13:26:49','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('186','eeaa2bf7b4750','','ABC','ali mohammed','750','750','0','0','750','2022-10-09 13:30:50','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('187','1bdb235aa9750','','ABC','alfred','750','750','0','0','750','2022-10-09 13:31:05','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('188','a70f6ea4fc1100','','ABC','Bob Manga','1100','1100','0','0','1100','2022-10-09 13:31:47','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('189','e75eb4b7151500','','ABC','alfred','1500','1500','0','0','1500','2022-10-09 13:33:07','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('190','8ca85799f31750','','ABC','BABILLON Christian','1750','1750','0','0','1750','2022-10-09 13:34:03','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('191','f5086b3dfd850','','ABC','ali mohammed','850','850','0','0','850','2022-10-09 13:35:34','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('192','ef6f4f2d9e700','','ABC','ariane','700','700','0','0','700','2022-10-09 13:36:36','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('193','36fbb45939450','','ABC','boba','450','450','0','0','450','2022-10-09 13:38:27','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('194','f79f1bf8f63550','','ABC','ali mohammed','3550','3550','0','0','3550','2022-10-09 13:42:24','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('195','ae31ecc962800','','ABC','bernard nanga','800','800','0','0','800','2022-10-09 13:43:11','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('196','d571ad19be4650','','ABC','bernard nanga','4650','4650','0','0','4650','2022-10-09 13:44:09','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('197','973c23d8f86200','','ABC','ekedi','6200','6200','0','0','6200','2022-10-09 13:46:19','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('198','71fcf267624800','','ABC','albar','4800','4800','0','0','4800','2022-10-09 13:47:10','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('199','cbdace5a343300','','ABC','ariane','3300','3300','0','0','3300','2022-10-09 13:48:30','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('200','dd988ecf7d6100','','ABC','ariane','6100','6100','0','0','6100','2022-10-09 13:51:10','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('201','7517107822800','','ABC','abel','800','800','0','0','800','2022-10-09 14:11:53','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('202','c30f9a4a1a800','','ABC','albar','800','800','0','0','800','2022-10-09 14:13:49','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('203','6d94a3a56c3650','','ABC','ali mohammed','3650','3650','0','0','3650','2022-10-09 14:14:29','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('204','b1fbf43ec18900','','ABC','bernard nanga','8900','8900','0','0','8900','2022-10-09 14:15:10','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('205','dfcbce074915800','','ABC','baba','15800','0','0','0','0','2022-10-09 14:20:33','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('206','ed5965f5291850','','ABC','ali mohammed','1850','1850','0','0','1850','2022-10-09 14:50:11','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('207','5ff1644df73000','','ABC','ariane','3000','3000','0','0','3000','2022-10-09 14:58:50','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('208','e4255faa663250','','ABC','ariane','3250','3250','0','0','3250','2022-10-09 17:15:08','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('209','183777e9782500','ABC','','alea','2500','2500','0','0','2500','2022-10-12 08:44:58','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('210','a354f9be882150','ABC','Kamdem','baba','2150','0','0','0','0','2022-10-12 15:53:23','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('211','d60995bdd01500','ABC','Kamdem','baba','1500','0','0','0','0','2022-10-12 16:00:11','assuretous','100','pending');
INSERT INTO `facture_pharmacie` VALUES ('212','9aa6fddff73000','ABC','','albar','3000','3000','0','0','3000','2022-10-12 16:00:59','aucune','0','done');
INSERT INTO `facture_pharmacie` VALUES ('213','769ae2746b750','ABC','','erwin','750','150','0','0','150','2022-10-12 16:01:19','Ascoma','80','pending');


DROP TABLE IF EXISTS `fiche_stock`;
CREATE TABLE `fiche_stock` (
  `id_table` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) NOT NULL,
  `designation` text NOT NULL,
  `pu_vente` int(11) NOT NULL,
  `par` varchar(255) NOT NULL,
  `qte_entre` int(11) NOT NULL,
  `qte_sortie` int(11) NOT NULL,
  `qte_dispo` int(11) NOT NULL,
  `date_heure` datetime NOT NULL,
  `remarque` varchar(255) NOT NULL,
  PRIMARY KEY (`id_table`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4;

INSERT INTO `fiche_stock` VALUES ('4','676','sayana press','500','ABC','150','0','650','2021-11-19 17:39:26','livraison');
INSERT INTO `fiche_stock` VALUES ('5','678','transfuseur','500','ABC','50','0','850','2021-11-19 17:39:26','livraison');
INSERT INTO `fiche_stock` VALUES ('6','678','transfuseur','500','ABC','50','0','900','2021-11-19 17:41:15','livraison');
INSERT INTO `fiche_stock` VALUES ('7','677','perfuseur','250','ABC','50','0','450','2021-11-19 17:41:15','livraison');
INSERT INTO `fiche_stock` VALUES ('8','676','sayana press','500','ABC','75','0','725','2021-11-19 17:41:15','livraison');
INSERT INTO `fiche_stock` VALUES ('9','678','transfuseur','500','ABC','0','1','899','2021-11-19 18:59:08','sortie');
INSERT INTO `fiche_stock` VALUES ('10','344','metronidazol','200','ABC','0','4','772','2021-11-19 18:59:08','sortie');
INSERT INTO `fiche_stock` VALUES ('11','344','metronidazol','200','ABC','0','2','770','2021-11-19 19:13:26','sortie');
INSERT INTO `fiche_stock` VALUES ('12','676','sayana press','500','ABC','0','2','723','2021-11-19 19:13:26','sortie');
INSERT INTO `fiche_stock` VALUES ('13','678','transfuseur','500','ABC','0','3','896','2021-11-19 19:14:19','sortie');
INSERT INTO `fiche_stock` VALUES ('14','678','transfuseur','500','Dr Obam','0','0','885','2021-11-20 02:07:25','inventaire');
INSERT INTO `fiche_stock` VALUES ('15','676','sayana press','500','Dr Obam','0','0','730','2021-11-20 02:08:59','inventaire');
INSERT INTO `fiche_stock` VALUES ('16','347','arthemeter','1800','Kamdem','0','1','777','2021-11-20 04:19:53','sortie');
INSERT INTO `fiche_stock` VALUES ('17','349','paracétamol','100','Kamdem','0','2','771','2021-11-20 04:19:53','sortie');
INSERT INTO `fiche_stock` VALUES ('18','346','eferalgan','100','Kamdem','0','2','70','2021-11-20 04:22:41','sortie');
INSERT INTO `fiche_stock` VALUES ('19','415','arthemeter','1800','Kamdem','0','1','699','2021-11-20 04:22:41','sortie');
INSERT INTO `fiche_stock` VALUES ('20','420','amoxiline','250','Kamdem','0','1','449','2021-11-20 04:22:41','sortie');
INSERT INTO `fiche_stock` VALUES ('21','419','metronidazol','200','Kamdem','0','2','448','2021-11-20 04:22:41','sortie');
INSERT INTO `fiche_stock` VALUES ('22','347','arthemeter','1800','Kamdem','0','1','776','2021-11-20 04:35:58','sortie');
INSERT INTO `fiche_stock` VALUES ('23','678','transfuseur','500','ABC','0','1','884','2021-11-20 04:47:23','sortie');
INSERT INTO `fiche_stock` VALUES ('24','419','metronidazol','200','ABC','0','3','445','2021-11-20 04:47:23','sortie');
INSERT INTO `fiche_stock` VALUES ('25','676','sayana press','500','ABC','0','1','729','2021-11-20 04:49:00','sortie');
INSERT INTO `fiche_stock` VALUES ('26','349','paracétamol','100','ABC','0','2','769','2021-11-20 04:49:39','sortie');
INSERT INTO `fiche_stock` VALUES ('27','348','amoxiline','250','Kamdem','0','4','769','2021-11-20 04:49:53','sortie');
INSERT INTO `fiche_stock` VALUES ('28','416','metronidazol','200','Kamdem','0','1','249','2021-11-20 04:49:53','sortie');
INSERT INTO `fiche_stock` VALUES ('29','420','amoxiciline','250','ABC','100','0','549','2021-11-24 20:14:53','livraison');
INSERT INTO `fiche_stock` VALUES ('30','348','amoxi','200','ABC','100','0','869','2021-11-24 20:20:10','livraison');
INSERT INTO `fiche_stock` VALUES ('31','348','amoxi','200','ABC','0','2','867','2021-12-04 15:57:37','sortie');
INSERT INTO `fiche_stock` VALUES ('32','349','paracétamol','100','ABC','0','2','767','2021-12-04 15:57:37','sortie');
INSERT INTO `fiche_stock` VALUES ('33','348','amoxi','200','ABC','0','9','858','2021-12-04 15:59:04','sortie');
INSERT INTO `fiche_stock` VALUES ('34','348','amoxi','200','ABC','0','2','856','2021-12-04 15:59:21','sortie');
INSERT INTO `fiche_stock` VALUES ('35','348','amoxi','200','ABC','0','1','855','2021-12-04 15:59:47','sortie');
INSERT INTO `fiche_stock` VALUES ('36','420','amoxiciline','250','ABC','0','2','547','2021-12-04 15:59:47','sortie');
INSERT INTO `fiche_stock` VALUES ('37','348','amoxi','200','ABC','0','9','846','2021-12-04 16:05:28','sortie');
INSERT INTO `fiche_stock` VALUES ('38','683','ccc','100','Dr Obam','10','0','10','2021-12-05 11:09:26','livraison');
INSERT INTO `fiche_stock` VALUES ('39','683','ccc','100','Dr Obam','15','0','25','2021-12-05 11:10:09','livraison');
INSERT INTO `fiche_stock` VALUES ('40','683','ccc','100','Dr Obam','0','0','20','2021-12-05 11:13:04','inventaire');
INSERT INTO `fiche_stock` VALUES ('41','683','ccc','100','Kamdem','0','1','19','2021-12-07 10:31:12','sortie');
INSERT INTO `fiche_stock` VALUES ('42','420','amoxiciline','250','ABC','0','2','545','2021-12-10 11:54:21','sortie');
INSERT INTO `fiche_stock` VALUES ('43','678','transfuseur','500','Kamdem','0','1','883','2021-12-10 11:54:50','sortie');
INSERT INTO `fiche_stock` VALUES ('44','419','metronidazol','200','Kamdem','0','2','443','2021-12-10 11:54:50','sortie');
INSERT INTO `fiche_stock` VALUES ('45','420','amoxiciline','250','Kamdem','0','2','543','2021-12-10 11:55:14','sortie');
INSERT INTO `fiche_stock` VALUES ('46','348','amoxi','200','ABC','0','9','837','2021-12-12 19:16:00','sortie');
INSERT INTO `fiche_stock` VALUES ('47','420','amoxiciline','250','ABC','0','1','542','2021-12-20 08:10:59','sortie');
INSERT INTO `fiche_stock` VALUES ('48','349','paracétamol','100','ABC','0','5','762','2021-12-20 08:10:59','sortie');
INSERT INTO `fiche_stock` VALUES ('49','349','paracétamol','100','Kamdem','0','2','760','2021-12-20 08:14:57','sortie');
INSERT INTO `fiche_stock` VALUES ('50','420','amoxiciline','250','Kamdem','0','1','541','2021-12-20 08:14:57','sortie');
INSERT INTO `fiche_stock` VALUES ('51','683','ccc','100','Kamdem','0','2','17','2022-01-17 09:26:44','sortie');
INSERT INTO `fiche_stock` VALUES ('52','683','ccc','100','ABC','0','1','16','2022-01-26 04:09:37','sortie');
INSERT INTO `fiche_stock` VALUES ('53','676','sayana press','500','ABC','0','4','725','2022-01-26 04:15:48','sortie');
INSERT INTO `fiche_stock` VALUES ('54','348','amoxi','200','ABC','0','7','830','2022-01-26 04:15:48','sortie');
INSERT INTO `fiche_stock` VALUES ('55','348','amoxi','200','ABC','0','1','829','2022-01-26 04:29:48','sortie');
INSERT INTO `fiche_stock` VALUES ('56','683','ccc','100','ABC','0','2','14','2022-01-26 05:51:29','sortie');
INSERT INTO `fiche_stock` VALUES ('57','348','amoxi','200','ABC','0','4','825','2022-01-26 05:51:29','sortie');
INSERT INTO `fiche_stock` VALUES ('58','683','ccc','100','ABC','0','2','12','2022-01-28 12:39:39','sortie');
INSERT INTO `fiche_stock` VALUES ('59','344','metronidazol','250','ABC','0','1','769','2022-01-28 12:39:39','sortie');
INSERT INTO `fiche_stock` VALUES ('60','683','ccc','100','ABC','0','1','11','2022-01-28 15:35:28','sortie');
INSERT INTO `fiche_stock` VALUES ('61','683','ccc','100','ABC','0','1','10','2022-01-28 17:29:59','sortie');
INSERT INTO `fiche_stock` VALUES ('62','344','metronidazol','250','ABC','0','4','765','2022-01-28 17:29:59','sortie');
INSERT INTO `fiche_stock` VALUES ('63','348','amoxi','200','ABC','0','1','824','2022-01-29 14:56:15','sortie');
INSERT INTO `fiche_stock` VALUES ('64','350','minoxidil 300ml','7500','ABC','0','1','779','2022-01-29 14:56:15','sortie');
INSERT INTO `fiche_stock` VALUES ('65','348','amoxi','200','ABC','0','2','822','2022-01-29 14:57:08','sortie');
INSERT INTO `fiche_stock` VALUES ('66','677','perfuseur','250','ABC','0','1','449','2022-01-29 14:57:08','sortie');
INSERT INTO `fiche_stock` VALUES ('67','344','metronidazol','250','ABC','0','1','764','2022-01-29 14:57:50','sortie');
INSERT INTO `fiche_stock` VALUES ('68','676','sayana press','500','ABC','0','1','724','2022-01-29 14:57:50','sortie');
INSERT INTO `fiche_stock` VALUES ('69','344','metronidazol','250','ABC','0','5','759','2022-01-29 14:58:03','sortie');
INSERT INTO `fiche_stock` VALUES ('70','677','perfuseur','250','ABC','0','1','448','2022-01-29 15:08:06','sortie');
INSERT INTO `fiche_stock` VALUES ('71','420','amoxiciline','250','ABC','0','1','540','2022-01-29 15:16:03','sortie');
INSERT INTO `fiche_stock` VALUES ('72','349','paracétamol','100','Kamdem','0','1','759','2022-02-05 14:46:15','sortie');
INSERT INTO `fiche_stock` VALUES ('73','420','amoxiciline','250','Kamdem','0','2','538','2022-02-05 14:47:00','sortie');
INSERT INTO `fiche_stock` VALUES ('74','349','paracétamol','100','Kamdem','0','1','758','2022-02-05 14:47:00','sortie');
INSERT INTO `fiche_stock` VALUES ('75','415','arthemeter','1800','ABC','0','1','698','2022-02-07 21:03:00','sortie');
INSERT INTO `fiche_stock` VALUES ('76','344','metronidazol','250','Kamdem','0','9','750','2022-02-16 01:30:20','sortie');
INSERT INTO `fiche_stock` VALUES ('77','420','amoxiciline','250','Kamdem','0','8','530','2022-02-16 01:30:20','sortie');
INSERT INTO `fiche_stock` VALUES ('78','420','amoxiciline','250','ABC','0','3','527','2022-02-16 01:32:52','sortie');
INSERT INTO `fiche_stock` VALUES ('79','677','perfuseur','250','ABC','0','8','440','2022-02-16 01:32:52','sortie');
INSERT INTO `fiche_stock` VALUES ('80','677','perfuseur','250','ABC','0','1','439','2022-02-16 02:04:06','sortie');
INSERT INTO `fiche_stock` VALUES ('81','683','ccc','100','ABC','0','10','0','2022-02-16 02:09:31','sortie');
INSERT INTO `fiche_stock` VALUES ('82','683','ccc','100','ABC','25','0','25','2022-02-16 02:11:49','livraison');
INSERT INTO `fiche_stock` VALUES ('83','348','amoxi','200','ABC','0','2','820','2022-02-17 16:15:47','sortie');
INSERT INTO `fiche_stock` VALUES ('84','415','arthemeter','1800','ABC','0','1','697','2022-02-17 16:16:32','sortie');
INSERT INTO `fiche_stock` VALUES ('85','349','paracétamol','100','ABC','0','2','756','2022-02-17 16:17:39','sortie');
INSERT INTO `fiche_stock` VALUES ('86','676','sayana press','500','ABC','0','1','723','2022-02-17 16:17:39','sortie');
INSERT INTO `fiche_stock` VALUES ('87','349','paracétamol','100','ABC','0','2','754','2022-02-17 16:17:39','sortie');
INSERT INTO `fiche_stock` VALUES ('88','676','sayana press','500','ABC','0','1','722','2022-02-17 16:17:39','sortie');
INSERT INTO `fiche_stock` VALUES ('89','676','sayana press','500','ABC','0','1','721','2022-02-17 16:18:18','sortie');
INSERT INTO `fiche_stock` VALUES ('90','676','sayana press','500','ABC','0','1','720','2022-02-17 16:18:18','sortie');
INSERT INTO `fiche_stock` VALUES ('91','676','sayana press','500','ABC','0','1','719','2022-02-17 16:18:18','sortie');
INSERT INTO `fiche_stock` VALUES ('92','676','sayana press','500','ABC','0','1','718','2022-02-17 16:20:29','sortie');
INSERT INTO `fiche_stock` VALUES ('93','415','arthemeter','1800','ABC','0','1','696','2022-02-17 16:21:09','sortie');
INSERT INTO `fiche_stock` VALUES ('94','415','arthemeter','1800','ABC','0','1','695','2022-02-17 16:21:14','sortie');
INSERT INTO `fiche_stock` VALUES ('95','676','sayana press','500','ABC','0','1','717','2022-02-17 16:21:52','sortie');
INSERT INTO `fiche_stock` VALUES ('96','676','sayana press','500','ABC','0','1','716','2022-02-17 16:58:02','sortie');
INSERT INTO `fiche_stock` VALUES ('97','344','metronidazol','250','ABC','0','2','748','2022-02-28 21:07:44','sortie');
INSERT INTO `fiche_stock` VALUES ('98','344','metronidazol','250','ABC','0','2','746','2022-02-28 21:08:19','sortie');
INSERT INTO `fiche_stock` VALUES ('99','344','metronidazol','250','ABC','0','2','744','2022-02-28 21:10:37','sortie');
INSERT INTO `fiche_stock` VALUES ('100','344','metronidazol','250','ABC','0','2','742','2022-02-28 21:12:38','sortie');
INSERT INTO `fiche_stock` VALUES ('101','344','metronidazol','250','ABC','0','2','740','2022-02-28 21:14:45','sortie');
INSERT INTO `fiche_stock` VALUES ('102','420','amoxiciline','250','ABC','0','2','525','2022-02-28 21:33:36','sortie');
INSERT INTO `fiche_stock` VALUES ('103','348','amoxi','200','Kamdem','0','1','819','2022-02-28 21:35:11','sortie');
INSERT INTO `fiche_stock` VALUES ('104','683','ccc','100','Kamdem','0','1','24','2022-02-28 21:43:34','sortie');
INSERT INTO `fiche_stock` VALUES ('105','348','amoxi','200','Kamdem','0','1','818','2022-02-28 21:43:34','sortie');
INSERT INTO `fiche_stock` VALUES ('106','683','ccc','100','ABC','0','1','23','2022-02-28 21:47:38','sortie');
INSERT INTO `fiche_stock` VALUES ('107','348','amoxi','200','ABC','0','2','816','2022-03-01 12:53:38','sortie');
INSERT INTO `fiche_stock` VALUES ('108','348','amoxi','200','ABC','0','2','814','2022-03-01 12:53:38','sortie');
INSERT INTO `fiche_stock` VALUES ('109','348','amoxi','200','ABC','0','2','812','2022-03-01 12:53:39','sortie');
INSERT INTO `fiche_stock` VALUES ('110','348','amoxi','200','ABC','0','2','810','2022-03-01 12:59:33','sortie');
INSERT INTO `fiche_stock` VALUES ('111','683','ccc','100','Kamdem','0','2','21','2022-03-01 12:59:49','sortie');
INSERT INTO `fiche_stock` VALUES ('112','348','amoxi','200','Kamdem','0','1','809','2022-03-01 13:00:51','sortie');
INSERT INTO `fiche_stock` VALUES ('113','683','ccc','100','Kamdem','0','1','20','2022-03-01 13:01:57','sortie');
INSERT INTO `fiche_stock` VALUES ('114','348','amoxi','200','ABC','0','2','807','2022-03-01 13:03:27','sortie');
INSERT INTO `fiche_stock` VALUES ('115','348','amoxi','200','ABC','0','2','805','2022-03-01 13:04:32','sortie');
INSERT INTO `fiche_stock` VALUES ('116','683','ccc','100','Kamdem','0','1','19','2022-03-01 13:07:23','sortie');
INSERT INTO `fiche_stock` VALUES ('117','420','amoxiciline','250','Kamdem','0','1','524','2022-03-02 12:47:42','sortie');
INSERT INTO `fiche_stock` VALUES ('118','420','amoxiciline','250','ABC','0','1','523','2022-03-02 12:51:26','sortie');
INSERT INTO `fiche_stock` VALUES ('119','683','ccc','100','ABC','0','2','17','2022-03-02 13:06:19','sortie');
INSERT INTO `fiche_stock` VALUES ('120','348','amoxi','200','Kamdem','0','1','804','2022-03-02 13:08:18','sortie');
INSERT INTO `fiche_stock` VALUES ('121','683','ccc','100','Kamdem','0','3','14','2022-03-02 13:08:38','sortie');
INSERT INTO `fiche_stock` VALUES ('122','348','amoxi','200','Kamdem','0','1','803','2022-03-02 13:08:38','sortie');
INSERT INTO `fiche_stock` VALUES ('123','683','ccc','100','Kamdem','0','1','13','2022-03-02 13:11:10','sortie');
INSERT INTO `fiche_stock` VALUES ('124','348','amoxi','200','ABC','0','3','800','2022-03-25 04:48:24','sortie');
INSERT INTO `fiche_stock` VALUES ('125','349','paracétamol','100','ABC','0','4','750','2022-03-25 05:22:42','sortie');
INSERT INTO `fiche_stock` VALUES ('126','415','arthemeter','1800','ABC','0','2','693','2022-03-25 05:22:42','sortie');
INSERT INTO `fiche_stock` VALUES ('127','415','arthemeter','1800','ABC','0','1','692','2022-03-25 05:26:30','sortie');
INSERT INTO `fiche_stock` VALUES ('128','349','paracétamol','100','Kamdem','0','1','749','2022-05-06 21:06:28','sortie');
INSERT INTO `fiche_stock` VALUES ('129','677','perfuseur','250','Kamdem','0','2','437','2022-05-06 21:06:42','sortie');
INSERT INTO `fiche_stock` VALUES ('130','420','amoxiciline','250','Kamdem','0','5','518','2022-05-06 21:06:51','sortie');
INSERT INTO `fiche_stock` VALUES ('131','676','sayana press','500','ABC','0','1','715','2022-05-06 21:09:13','sortie');
INSERT INTO `fiche_stock` VALUES ('132','348','amoxi','200','ABC','0','1','799','2022-05-08 09:59:36','sortie');
INSERT INTO `fiche_stock` VALUES ('133','683','ccc','100','ABC','0','2','11','2022-07-18 12:08:50','sortie');
INSERT INTO `fiche_stock` VALUES ('134','350','minoxidil 300ml','7500','ABC','0','1','778','2022-07-18 12:12:51','sortie');
INSERT INTO `fiche_stock` VALUES ('135','349','paracétamol','100','ABC','0','2','747','2022-07-18 12:14:41','sortie');
INSERT INTO `fiche_stock` VALUES ('136','676','sayana press','500','ABC','0','1','714','2022-07-18 12:14:41','sortie');
INSERT INTO `fiche_stock` VALUES ('137','678','transfuseur','500','ABC','0','1','882','2022-07-18 12:14:41','sortie');
INSERT INTO `fiche_stock` VALUES ('138','344','metronidazol','250','ABC','0','1','739','2022-07-18 12:14:41','sortie');
INSERT INTO `fiche_stock` VALUES ('139','349','paracétamol','100','ABC','0','1','746','2022-07-18 12:18:47','sortie');
INSERT INTO `fiche_stock` VALUES ('140','676','sayana press','500','ABC','0','1','713','2022-07-18 12:18:48','sortie');
INSERT INTO `fiche_stock` VALUES ('141','683','ccc','100','ABC','0','1','10','2022-07-18 12:18:48','sortie');
INSERT INTO `fiche_stock` VALUES ('142','676','sayana press','500','ABC','0','3','710','2022-07-18 12:30:59','sortie');
INSERT INTO `fiche_stock` VALUES ('143','344','metronidazol','250','ABC','0','2','737','2022-07-18 12:30:59','sortie');
INSERT INTO `fiche_stock` VALUES ('144','683','ccc','100','Kamdem','0','1','9','2022-07-18 13:03:27','sortie');
INSERT INTO `fiche_stock` VALUES ('145','678','transfuseur','500','ABC','0','2','880','2022-07-18 15:59:49','sortie');
INSERT INTO `fiche_stock` VALUES ('146','415','arthemeter','1800','ABC','0','1','691','2022-07-19 11:28:19','sortie');
INSERT INTO `fiche_stock` VALUES ('147','344','metronidazol','250','ABC','0','1','736','2022-07-19 11:28:19','sortie');
INSERT INTO `fiche_stock` VALUES ('148','349','paracétamol','100','ABC','0','2','744','2022-07-19 11:28:19','sortie');
INSERT INTO `fiche_stock` VALUES ('149','678','transfuseur','500','Kamdem','0','2','878','2022-07-28 11:41:11','sortie');
INSERT INTO `fiche_stock` VALUES ('150','677','perfuseur','250','Kamdem','0','2','435','2022-07-28 11:41:11','sortie');
INSERT INTO `fiche_stock` VALUES ('151','677','perfuseur','250','Kamdem','0','2','433','2022-07-28 11:41:25','sortie');
INSERT INTO `fiche_stock` VALUES ('152','420','amoxiciline','250','Kamdem','0','4','514','2022-07-28 11:41:47','sortie');
INSERT INTO `fiche_stock` VALUES ('153','344','metronidazol','250','Kamdem','0','1','735','2022-07-28 11:41:47','sortie');
INSERT INTO `fiche_stock` VALUES ('154','418','ibuprofene','150','ABC','3','0','250','2022-10-09 13:29:55','livraison');
INSERT INTO `fiche_stock` VALUES ('155','684','artefan','1700','ABC','10','0','10','2022-10-09 13:40:48','livraison');
INSERT INTO `fiche_stock` VALUES ('156','685','cofantrine','1500','ABC','10','0','10','2022-10-09 13:40:48','livraison');
INSERT INTO `fiche_stock` VALUES ('157','681','litacol','250','ABC','10','0','10','2022-10-09 13:40:48','livraison');
INSERT INTO `fiche_stock` VALUES ('158','686','malacur','1000','ABC','25','0','25','2022-10-09 14:57:20','livraison');
INSERT INTO `fiche_stock` VALUES ('159','420','amoxiciline','250','ABC','12','0','526','2022-10-09 15:15:00','livraison');
INSERT INTO `fiche_stock` VALUES ('160','686','malacur','1000','ABC','0','2','23','2022-10-12 15:55:31','sortie');
INSERT INTO `fiche_stock` VALUES ('161','418','ibuprofene','150','ABC','0','1','249','2022-10-12 15:55:31','sortie');
INSERT INTO `fiche_stock` VALUES ('162','415','arthemeter','1500','ABC','0','1','690','2022-10-12 16:00:27','sortie');


DROP TABLE IF EXISTS `fournisseurs`;
CREATE TABLE `fournisseurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_fournisseur` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `fournisseurs` VALUES ('3','AUCUN');
INSERT INTO `fournisseurs` VALUES ('4','CARP');
INSERT INTO `fournisseurs` VALUES ('5','SPC');
INSERT INTO `fournisseurs` VALUES ('6','UBIPHAR');
INSERT INTO `fournisseurs` VALUES ('7','JOHN MEDICAL');
INSERT INTO `fournisseurs` VALUES ('8','MEDIPHARMA');
INSERT INTO `fournisseurs` VALUES ('9','GC PHARMA');


DROP TABLE IF EXISTS `historique`;
CREATE TABLE `historique` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prod` int(11) NOT NULL,
  `id_facture` varchar(255) NOT NULL,
  `date_vente` datetime NOT NULL,
  `code` varchar(255) NOT NULL,
  `designation` text NOT NULL,
  `categorie` text NOT NULL,
  `genre` varchar(255) NOT NULL,
  `date_peremption` varchar(50) NOT NULL,
  `quantite` varchar(255) NOT NULL,
  `prix_total` int(11) NOT NULL,
  `nom_vendeur` varchar(255) NOT NULL,
  `caissier` varchar(255) NOT NULL,
  `status_vente` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=428 DEFAULT CHARSET=utf8mb4;

INSERT INTO `historique` VALUES ('145','352','188202101280809213982551347133','2021-09-18 01:33:47','MASL','ibuprofene',' cp','','03-24','1','150','Dr Obam','','payé');
INSERT INTO `historique` VALUES ('148','346','18820210152018553719966182932','2021-09-18 03:02:29','AMAK','eferalgan','comprimé efervescent','','02-23','1','100','Dr Obam','','payé');
INSERT INTO `historique` VALUES ('149','348','1882021014675534760423203428323','2021-09-18 03:23:28','KASL','amoxiline','comprimé','','12-24','1','200','Dr Obam','','payé');
INSERT INTO `historique` VALUES ('150','346','1882021014675534760423203428323','2021-09-18 03:23:28','AMAK','eferalgan','comprimé efervescent','','02-23','2','200','Dr Obam','','payé');
INSERT INTO `historique` VALUES ('151','349','1882021012178017291817815301041','2021-09-18 10:41:00','KAAA','paracétamol','comprimé','','10-25','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('152','351','1882021012178017291817815301041','2021-09-18 10:41:00','ZMOS','arthemeter','comprimé','','05-22','1','1700','Kamdem','','payé');
INSERT INTO `historique` VALUES ('153','352','1882021012178017291817815301041','2021-09-18 10:41:00','MASL','ibuprofene',' cp','','03-24','3','450','Kamdem','','payé');
INSERT INTO `historique` VALUES ('154','348','792021018512142716597291431545','2021-10-07 15:45:43','KASL','amoxiline','comprimé','','12-24','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('155','351','792021018512142716597291431545','2021-10-07 15:45:43','ZMOS','arthemeter','comprimé','','05-22','2','3400','Kamdem','','payé');
INSERT INTO `historique` VALUES ('156','348','792021014866090084821688351552','2021-10-07 15:52:35','KASL','amoxiline','comprimé','','12-24','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('157','347','792021018228985629146843411556','2021-10-07 15:56:41','ZMOS','arthemeter','comprimé','','02-22','1','1700','Kamdem','','payé');
INSERT INTO `historique` VALUES ('158','344','79202101600974228178926145162','2021-10-07 16:02:45','MASL','metronidazol',' ','','08-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('159','349','7920210128566028470537774461649','2021-10-07 16:49:46','KAAA','paracétamol','comprimé','','10-25','1','100','Dr Obam','','payé');
INSERT INTO `historique` VALUES ('161','348','1092021019236225698463736321847','2021-10-10 18:47:32','KASL','amoxiline','comprimé','','12-24','1','200','Dr Obam','','payé');
INSERT INTO `historique` VALUES ('162','349','1092021019236225698463736321847','2021-10-10 18:47:32','KAAA','paracétamol','comprimé','','10-25','2','200','Dr Obam','','payé');
INSERT INTO `historique` VALUES ('164','347','119202101440571230639903246839','2021-10-11 08:39:46','ZMOS','arthemeter','comprimé','','02-22','1','1700','Kamdem','','payé');
INSERT INTO `historique` VALUES ('165','352','119202101614247173344512356848','2021-10-11 08:48:57','MASL','ibuprofene',' cp','','03-24','1','150','ABC','','payé');
INSERT INTO `historique` VALUES ('168','344','11920210111497887400363949291244','2021-10-11 12:44:29','MASL','metronidazol',' ','','08-25','2','400','Kamdem','','payé');
INSERT INTO `historique` VALUES ('169','344','7b61','2021-10-18 19:30:08','MASL','metronidazol',' ','','08-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('170','347','b58d','2021-10-26 17:26:00','ZMOS','arthemeter','pharmacie','','02-22','1','1800','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('171','349','b58d','2021-10-26 17:26:01','KAAA','paracétamol','pharmacie','','10-25','2','200','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('172','349','2433','2021-10-26 17:33:32','KAAA','paracétamol','comprimé','','10-25','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('173','347','4eef','2021-10-26 17:36:42','ZMOS','arthemeter','pharmacie','','02-22','1','1800','Kamdem','','payé');
INSERT INTO `historique` VALUES ('174','344','4e0f','2021-10-27 10:07:26','MASL','metronidazol','pharmacie','','08-25','3','600','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('175','347','c2c4','2021-10-27 18:50:02','ZMOS','arthemeter','pharmacie','','02-22','1','1800','Kamdem','','payé');
INSERT INTO `historique` VALUES ('176','349','c2c4','2021-10-27 18:50:02','KAAA','paracétamol','pharmacie','','10-25','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('177','348','76ab','2021-10-27 18:50:31','KASL','amoxiline','pharmacie','','12-24','2','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('178','416','bf01','2021-10-27 18:51:19','MASL','metronidazol','pharmacie','','08-25','1','200','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('179','349','bf01','2021-10-27 18:51:19','KAAA','paracétamol','pharmacie','','10-25','2','200','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('180','418','bf01','2021-10-27 18:51:19','MASL','ibuprofene','pharmacie','','03-24','5','750','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('181','347','3db2','2021-10-27 21:06:55','ZMOS','arthemeter','pharmacie','','02-22','1','1800','Kamdem','','payé');
INSERT INTO `historique` VALUES ('182','349','3db2','2021-10-27 21:06:55','KAAA','paracétamol','pharmacie','','10-25','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('183','352','3db2','2021-10-27 21:06:55','MASL','ibuprofene','pharmacie','','03-24','1','150','Kamdem','','payé');
INSERT INTO `historique` VALUES ('184','348','4c4b','2021-10-27 21:07:27','KASL','amoxiline','pharmacie','','12-24','4','1000','Kamdem','','payé');
INSERT INTO `historique` VALUES ('185','416','4c4b','2021-10-27 21:07:27','MASL','metronidazol','pharmacie','','08-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('186','346','c0db','2021-10-28 15:28:44','AMAK','eferalgan','pharmacie','','02-23','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('187','415','c0db','2021-10-28 15:28:44','ZMOS','arthemeter','pharmacie','','02-25','1','1800','Kamdem','','payé');
INSERT INTO `historique` VALUES ('188','418','20c7','2021-10-28 15:29:43','MASL','ibuprofene','pharmacie','','03-24','2','300','Kamdem','','payé');
INSERT INTO `historique` VALUES ('189','349','20c7','2021-10-28 15:29:43','KAAA','paracétamol','pharmacie','','10-25','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('190','346','20c7','2021-10-28 15:29:43','AMAK','eferalgan','pharmacie','','02-23','4','400','Kamdem','','payé');
INSERT INTO `historique` VALUES ('191','352','e2c0','2021-10-28 15:30:09','MASL','ibuprofene','pharmacie','','03-24','5','750','Kamdem','','payé');
INSERT INTO `historique` VALUES ('192','348','1468','2021-10-28 15:31:10','KASL','amoxiline','pharmacie','','12-24','4','1000','Kamdem','','payé');
INSERT INTO `historique` VALUES ('193','418','1468','2021-10-28 15:31:10','MASL','ibuprofene','pharmacie','','03-24','1','150','Kamdem','','payé');
INSERT INTO `historique` VALUES ('194','419','c0db','2021-10-28 15:31:50','MASL','metronidazol','pharmacie','','08-25','2','400','Kamdem','','payé');
INSERT INTO `historique` VALUES ('195','420','c0db','2021-10-28 15:31:50','KASL','amoxiline','pharmacie','','12-24','1','250','Kamdem','','payé');
INSERT INTO `historique` VALUES ('198','347','a35c','2021-11-12 15:25:45','ZMOS','arthemeter','pharmacie','','02-22','1','1800','Kamdem','','payé');
INSERT INTO `historique` VALUES ('199','348','9c22','2021-11-14 18:30:13','KASL','amoxiline','comprimé','','12-24','1','250','Kamdem','','payé');
INSERT INTO `historique` VALUES ('200','344','9c22','2021-11-14 18:30:13','MASL','metronidazol',' ','','08-25','2','400','Kamdem','','payé');
INSERT INTO `historique` VALUES ('201','349','9c22','2021-11-14 18:30:13','KAAA','paracétamol','comprimé','','10-25','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('203','352','58ba2100','2021-11-14 19:06:12','MASL','ibuprofene','pharmacie','','03-24','2','300','Kamdem','','payé');
INSERT INTO `historique` VALUES ('204','347','58ba2100','2021-11-14 19:06:12','ZMOS','arthemeter','pharmacie','','02-22','1','1800','Kamdem','','payé');
INSERT INTO `historique` VALUES ('205','344','6d0d200','2021-11-14 19:29:34','MASL','metronidazol','pharmacie','','08-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('206','349','b823500','2021-11-14 19:30:11','KAAA','paracétamol','pharmacie','','10-25','5','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('207','349','8b90200','2021-11-14 19:39:48','KAAA','paracétamol','pharmacie','','10-25','2','200','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('208','677','8c24500','2021-11-19 18:36:40','','perfuseur','','','','2','500','ABC','','payé');
INSERT INTO `historique` VALUES ('209','676','2ab52500','2021-11-19 18:36:56','','sayana press','','','','5','2500','ABC','','payé');
INSERT INTO `historique` VALUES ('210','678','f6921300','2021-11-19 18:37:48','','transfuseur','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('211','344','f6921300','2021-11-19 18:37:48','MASL','metronidazol',' ','','08-25','4','800','ABC','','payé');
INSERT INTO `historique` VALUES ('212','344','458e1400','2021-11-19 19:03:26','MASL','metronidazol','pharmacie','','08-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('213','676','458e1400','2021-11-19 19:03:26','','sayana press','pharmacie','','','2','1000','ABC','','payé');
INSERT INTO `historique` VALUES ('214','678','9a9e1500','2021-11-19 19:03:49','','transfuseur','','','','3','1500','ABC','','payé');
INSERT INTO `historique` VALUES ('215','349','b06c200','2021-11-20 04:44:41','KAAA','paracétamol','comprimé','','10-25','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('216','678','beb41100','2021-11-20 04:45:05','','transfuseur','pharmacie','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('217','419','beb41100','2021-11-20 04:45:05','MASL','metronidazol','pharmacie','','08-25','3','600','ABC','','payé');
INSERT INTO `historique` VALUES ('218','676','c30d500','2021-11-20 04:45:22','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('219','346','3d61100','2021-11-21 04:10:31','AMAK','eferalgan','comprimé efervescent','','02-23','1','100','ABC','','non payé');
INSERT INTO `historique` VALUES ('220','348','63ac700','2021-11-24 20:22:57','KASL','amoxi','comprimé','','12-24/05-25','1','200','ABC','','payé');
INSERT INTO `historique` VALUES ('221','420','63ac700','2021-11-24 20:22:57','KASL','amoxiciline','comprimé','','12-24/02-25','2','500','ABC','','payé');
INSERT INTO `historique` VALUES ('222','348','2b861800','2021-11-25 20:14:26','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('223','348','ee781800','2021-11-25 20:20:34','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('224','348','74391800','2021-11-25 20:23:23','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('225','348','34f31800','2021-11-25 20:24:12','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('226','348','ea0e1800','2021-11-25 20:25:48','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('227','347','a74a10800','2021-11-25 20:26:20','ZMOS','arthemeter','comprimé','','02-22','6','10800','ABC','','non payé');
INSERT INTO `historique` VALUES ('228','348','6a4c1800','2021-11-25 20:31:51','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('229','348','a0df400','2021-11-25 20:40:27','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('230','348','f3e41800','2021-11-25 20:44:59','KASL','amoxi','pharmacie','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('231','348','656d1800','2021-11-25 20:46:36','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','payé');
INSERT INTO `historique` VALUES ('232','348','f7fa1800','2021-11-25 20:47:22','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('233','348','66e71800','2021-11-25 20:48:21','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','payé');
INSERT INTO `historique` VALUES ('234','348','ac4b1800','2021-11-25 20:50:09','KASL','amoxi','comprimé','','12-24/05-25','9','1800','ABC','','payé');
INSERT INTO `historique` VALUES ('235','348','42e15250','2021-11-25 20:50:50','KASL','amoxi','comprimé','','12-24/05-25','10','2000','ABC','','non payé');
INSERT INTO `historique` VALUES ('236','678','42e15250','2021-11-25 20:50:50','','transfuseur','','','','4','2000','ABC','','non payé');
INSERT INTO `historique` VALUES ('237','677','42e15250','2021-11-25 20:50:51','','perfuseur','','','','5','1250','ABC','','non payé');
INSERT INTO `historique` VALUES ('238','348','a2bc600','2021-11-25 20:51:33','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('239','349','a2bc600','2021-11-25 20:51:33','KAAA','paracétamol','comprimé','','10-25','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('240','683','9fbc100','2021-12-05 11:30:35','','ccc','c','sp','','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('241','347','603b3600','2021-12-09 14:47:45','ZMOS','arthemeter','comprimé','','02-22','2','3600','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('242','348','6860500','2021-12-09 14:48:00','KASL','amoxi','comprimé','','12-24/05-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('243','683','6860500','2021-12-09 14:48:00','','ccc','c','sp','','3','300','Kamdem','','payé');
INSERT INTO `historique` VALUES ('244','420','0a71500','2021-12-09 14:48:28','KASL','amoxiciline','comprimé','','12-24/02-25','2','500','ABC','','payé');
INSERT INTO `historique` VALUES ('245','415','a9611800','2021-12-10 11:39:07','ZMOS','arthemeter','comprimé','','02-25','1','1800','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('246','420','efc5500','2021-12-10 11:44:48','KASL','amoxiciline','comprimé','','12-24/02-25','2','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('247','419','561d900','2021-12-10 11:49:50','MASL','metronidazol',' ','','08-25','2','400','Kamdem','','payé');
INSERT INTO `historique` VALUES ('248','678','561d900','2021-12-10 11:49:50','','transfuseur','','','','1','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('249','420','4a6a500','2021-12-12 19:34:29','KASL','amoxiciline','comprimé','','12-24/02-25','2','500','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('250','349','d9e5450','2021-12-20 07:44:28','KAAA','paracétamol','comprimé','','10-25','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('251','420','d9e5450','2021-12-20 07:44:28','KASL','amoxiciline','comprimé','','12-24/02-25','1','250','Kamdem','','payé');
INSERT INTO `historique` VALUES ('252','676','ebaa500','2021-12-20 07:45:20','','sayana press','','','','1','500','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('253','352','faed300','2021-12-20 07:45:50','MASL','ibuprofene',' cp','','03-24','2','300','ABC','','non payé');
INSERT INTO `historique` VALUES ('254','420','0cab750','2021-12-20 07:47:37','KASL','amoxiciline','pharmacie','','12-24/02-25','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('255','349','0cab750','2021-12-20 07:47:37','KAAA','paracétamol','pharmacie','','10-25','5','500','ABC','','payé');
INSERT INTO `historique` VALUES ('256','683','134b200','2022-01-17 09:21:46','','ccc','c','sp','','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('257','348','aa79400','2022-01-21 10:11:10','KASL','amoxi','comprimé','','12-24/05-25','2','400','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('258','683','09f6100','2022-01-21 10:11:58','','ccc','c','sp','','1','100','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('259','683','c577100','2022-01-21 10:12:38','','ccc','c','sp','','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('260','683','5646100','2022-01-21 10:19:11','','ccc','c','sp','','1','100','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('261','683','068a100','2022-01-21 10:19:44','','ccc','c','sp','','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('262','348','3415200','2022-01-21 10:20:17','KASL','amoxi','comprimé','','12-24/05-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('263','348','9b04200','2022-01-21 10:32:57','KASL','amoxi','comprimé','','12-24/05-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('264','683','7c49100','2022-01-21 10:34:24','','ccc','c','sp','','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('265','348','608d200','2022-01-21 10:36:01','KASL','amoxi','comprimé','','12-24/05-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('266','683','c168300','2022-01-21 10:37:41','','ccc','c','sp','','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('267','348','c168300','2022-01-21 10:37:41','KASL','amoxi','comprimé','','12-24/05-25','1','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('268','683','65b8200','2022-01-21 10:40:31','','ccc','c','sp','','2','200','Kamdem','','payé');
INSERT INTO `historique` VALUES ('269','683','b3911600','2022-01-26 03:41:46','','ccc','pharmacie','sp','','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('270','348','b3911600','2022-01-26 03:41:46','KASL','amoxi','pharmacie','','12-24/05-25','7','1400','ABC','','payé');
INSERT INTO `historique` VALUES ('271','683','a400100','2022-01-26 04:05:20','','ccc','c','sp','','1','100','ABC','','payé');
INSERT INTO `historique` VALUES ('272','683','8b41100','2022-01-26 04:09:01','','ccc','c','sp','','1','100','ABC','','payé');
INSERT INTO `historique` VALUES ('273','676','0f693400','2022-01-26 04:14:58','','sayana press','','','','4','2000','ABC','','payé');
INSERT INTO `historique` VALUES ('274','348','0f693400','2022-01-26 04:14:58','KASL','amoxi','comprimé','','12-24/05-25','7','1400','ABC','','payé');
INSERT INTO `historique` VALUES ('275','348','d768200','2022-01-26 04:29:23','KASL','amoxi','comprimé','','12-24/05-25','1','200','ABC','','payé');
INSERT INTO `historique` VALUES ('276','348','c2471000','2022-01-26 05:50:07','KASL','amoxi','comprimé','','12-24/05-25','4','800','ABC','','payé');
INSERT INTO `historique` VALUES ('277','683','c2471000','2022-01-26 05:50:07','','ccc','c','sp','','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('278','683','e07c450','2022-01-28 12:37:31','','ccc','c','sp','','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('279','344','e07c450','2022-01-28 12:37:31','MASL','metronidazol',' ','','08-25','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('280','683','6e21100','2022-01-28 15:35:08','','ccc','c','sp','','1','100','ABC','','payé');
INSERT INTO `historique` VALUES ('281','344','43e71100','2022-01-28 17:29:42','MASL','metronidazol',' ','','08-25','4','1000','ABC','','payé');
INSERT INTO `historique` VALUES ('282','683','43e71100','2022-01-28 17:29:42','','ccc','c','sp','','1','100','ABC','','payé');
INSERT INTO `historique` VALUES ('283','677','mhe250','2022-01-29 01:27:10','','perfuseur','','','','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('284','348','b195650','2022-01-29 14:49:12','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('285','677','b195650','2022-01-29 14:49:12','','perfuseur','','','','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('286','350','72637700','2022-01-29 14:50:07','MAAS','minoxidil 300ml','','','02-23','1','7500','ABC','','payé');
INSERT INTO `historique` VALUES ('287','348','72637700','2022-01-29 14:50:07','KASL','amoxi','comprimé','','12-24/05-25','1','200','ABC','','payé');
INSERT INTO `historique` VALUES ('288','344','35de1250','2022-01-29 14:50:41','MASL','metronidazol',' ','','08-25','5','1250','ABC','','payé');
INSERT INTO `historique` VALUES ('289','344','159d750','2022-01-29 14:51:27','MASL','metronidazol',' ','','08-25','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('290','676','159d750','2022-01-29 14:51:27','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('291','677','995c250','2022-01-29 15:07:53','','perfuseur','','','','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('292','420','c55642932f250','2022-01-29 15:14:50','KASL','amoxiciline','comprimé','','12-24/02-25','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('293','420','d9d1bdf1c8600','2022-02-05 14:44:17','KASL','amoxiciline','comprimé','','12-24/02-25','2','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('294','349','d9d1bdf1c8600','2022-02-05 14:44:17','KAAA','paracétamol','comprimé','','10-25','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('295','349','3d2f964701100','2022-02-05 14:45:45','KAAA','paracétamol','comprimé','','10-25','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('296','415','f78da026e71800','2022-02-05 15:03:13','ZMOS','arthemeter','comprimé','','02-25','1','1800','ABC','','payé');
INSERT INTO `historique` VALUES ('297','420','39736e781d4250','2022-02-16 01:29:58','KASL','amoxiciline','comprimé','','12-24/02-25','8','2000','Kamdem','','payé');
INSERT INTO `historique` VALUES ('298','344','39736e781d4250','2022-02-16 01:29:58','MASL','metronidazol',' ','','08-25','9','2250','Kamdem','','payé');
INSERT INTO `historique` VALUES ('299','420','b87faa51912750','2022-02-16 01:32:05','KASL','amoxiciline','comprimé','','12-24/02-25','3','750','ABC','','payé');
INSERT INTO `historique` VALUES ('300','677','b87faa51912750','2022-02-16 01:32:05','','perfuseur','','','','8','2000','ABC','','payé');
INSERT INTO `historique` VALUES ('303','683','22252d2b4f1000','2022-02-16 02:09:04','','ccc','c','sp','','10','1000','ABC','','payé');
INSERT INTO `historique` VALUES ('304','348','ad1009d2ed400','2022-02-17 16:15:32','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('305','415','29c66ea2771800','2022-02-17 16:16:15','ZMOS','arthemeter','comprimé','','02-25','1','1800','ABC','','payé');
INSERT INTO `historique` VALUES ('306','349','4ffe459650700','2022-02-17 16:17:28','KAAA','paracétamol','comprimé','','10-25','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('307','676','4ffe459650700','2022-02-17 16:17:28','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('308','676','e7938b0357500','2022-02-17 16:18:04','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('309','420','cf13becefc500','2022-02-17 16:29:26','KASL','amoxiciline','comprimé','','12-24/02-25','2','500','ABC','','payé');
INSERT INTO `historique` VALUES ('310','676','62930e9426500','2022-02-17 16:57:45','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('311','344','4c678c42e1500','2022-02-28 21:06:53','MASL','metronidazol',' ','','08-25','2','500','ABC','','payé');
INSERT INTO `historique` VALUES ('312','683','d563423deb100','2022-02-28 21:47:27','','ccc','c','sp','','1','100','ABC','','payé');
INSERT INTO `historique` VALUES ('313','348','c18f6c108f400','2022-03-01 12:53:12','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('314','348','c7fbfc2cc6400','2022-03-01 12:58:51','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('315','348','3a228478ac400','2022-03-01 13:03:13','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('316','348','b57e08914e400','2022-03-01 13:04:23','KASL','amoxi','comprimé','','12-24/05-25','2','400','ABC','','payé');
INSERT INTO `historique` VALUES ('317','683','5c1a49a68d200','2022-03-01 13:09:40','','ccc','c','sp','','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('318','420','5d63cb5d17250','2022-03-02 12:16:36','KASL','amoxiciline','comprimé','','12-24/02-25','1','250','Kamdem','','payé');
INSERT INTO `historique` VALUES ('319','420','fc0629b379250','2022-03-02 12:46:06','KASL','amoxiciline','comprimé','','12-24/02-25','1','250','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('320','420','bfe4a83d02250','2022-03-02 12:47:15','KASL','amoxiciline','comprimé','','12-24/02-25','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('321','348','72e6032c21600','2022-03-25 04:47:49','KASL','amoxi','comprimé','','12-24/05-25','3','600','ABC','','payé');
INSERT INTO `historique` VALUES ('322','420','5740488a20750','2022-03-25 04:48:51','KASL','amoxiciline','comprimé','','12-24/02-25','3','750','ABC','','non payé');
INSERT INTO `historique` VALUES ('323','415','0657d847e31800','2022-03-25 05:21:37','ZMOS','arthemeter','comprimé','','02-25','1','1800','ABC','','payé');
INSERT INTO `historique` VALUES ('324','349','a67671eec34000','2022-03-25 05:21:55','KAAA','paracétamol','comprimé','','10-25','4','400','ABC','','payé');
INSERT INTO `historique` VALUES ('325','415','a67671eec34000','2022-03-25 05:21:55','ZMOS','arthemeter','comprimé','','02-25','2','3600','ABC','','payé');
INSERT INTO `historique` VALUES ('326','420','d40d87da541250','2022-05-06 21:05:46','KASL','amoxiciline','comprimé','','12-24/02-25','5','1250','Kamdem','','payé');
INSERT INTO `historique` VALUES ('327','677','faa4e6f280500','2022-05-06 21:06:06','','perfuseur','','','','2','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('328','349','17ae1e720e100','2022-05-06 21:06:18','KAAA','paracétamol','comprimé','','10-25','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('329','676','03a903dd47500','2022-05-06 21:08:19','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('330','348','d437614dfb200','2022-05-08 09:59:25','KASL','amoxi','comprimé','','12-24/05-25','1','200','ABC','','payé');
INSERT INTO `historique` VALUES ('331','420','332da40f202500','2022-07-12 19:28:50','KASL','amoxiciline','comprimé','','12-24/02-25','10','2500','ABC','','non payé');
INSERT INTO `historique` VALUES ('332','683','860256bc53200','2022-07-18 12:07:43','','ccc','c','sp','','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('333','350','98375968907500','2022-07-18 12:12:38','MAAS','minoxidil 300ml','','','02-23','1','7500','ABC','','payé');
INSERT INTO `historique` VALUES ('334','349','d20bd1987d1450','2022-07-18 12:13:32','KAAA','paracétamol','comprimé','','10-25','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('335','676','d20bd1987d1450','2022-07-18 12:13:32','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('336','678','d20bd1987d1450','2022-07-18 12:13:32','','transfuseur','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('337','344','d20bd1987d1450','2022-07-18 12:13:32','MASL','metronidazol',' ','','08-25','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('338','349','5053ee34de700','2022-07-18 12:16:17','KAAA','paracétamol','comprimé','','10-25','1','100','ABC','','payé');
INSERT INTO `historique` VALUES ('339','676','5053ee34de700','2022-07-18 12:16:17','','sayana press','','','','1','500','ABC','','payé');
INSERT INTO `historique` VALUES ('340','683','5053ee34de700','2022-07-18 12:16:17','','ccc','c','sp','','1','100','ABC','','payé');
INSERT INTO `historique` VALUES ('341','676','f52974eee22000','2022-07-18 12:30:45','','sayana press','','','','3','1500','ABC','','payé');
INSERT INTO `historique` VALUES ('342','344','f52974eee22000','2022-07-18 12:30:45','MASL','metronidazol',' ','','08-25','2','500','ABC','','payé');
INSERT INTO `historique` VALUES ('343','683','12d4792bb8100','2022-07-18 13:03:12','','ccc','c','sp','','1','100','Kamdem','','payé');
INSERT INTO `historique` VALUES ('344','678','9dc6acd3a01000','2022-07-18 15:59:23','','transfuseur','','','','2','1000','ABC','','payé');
INSERT INTO `historique` VALUES ('345','683','335487e1dd100','2022-07-18 16:00:44','','ccc','c','sp','','1','100','ABC','','non payé');
INSERT INTO `historique` VALUES ('346','678','5a1f1a3c0d500','2022-07-18 16:27:34','','transfuseur','','','','1','500','ABC','','non payé');
INSERT INTO `historique` VALUES ('347','415','35c300e8552250','2022-07-19 11:28:07','ZMOS','arthemeter','comprimé','','02-25','1','1800','ABC','','payé');
INSERT INTO `historique` VALUES ('348','344','35c300e8552250','2022-07-19 11:28:07','MASL','metronidazol',' ','','08-25','1','250','ABC','','payé');
INSERT INTO `historique` VALUES ('349','349','35c300e8552250','2022-07-19 11:28:07','KAAA','paracétamol','comprimé','','10-25','2','200','ABC','','payé');
INSERT INTO `historique` VALUES ('350','440','26feb5004b1500','2022-07-20 16:00:39','','paracetamol 500mg','cp','','10/2022','5','500','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('351','449','26feb5004b1500','2022-07-20 16:00:39','','ibuprofene + paracetamol','sp','','7/2023','1','1000','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('352','344','ee9c7ceae21250','2022-07-28 11:40:00','MASL','metronidazol',' ','','08-25','1','250','Kamdem','','payé');
INSERT INTO `historique` VALUES ('353','420','ee9c7ceae21250','2022-07-28 11:40:00','KASL','amoxiciline','comprimé','','12-24/02-25','4','1000','Kamdem','','payé');
INSERT INTO `historique` VALUES ('354','677','e85697cac7500','2022-07-28 11:40:12','','perfuseur','','','','2','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('355','677','2ba2be5ad01500','2022-07-28 11:40:27','','perfuseur','','','','2','500','Kamdem','','payé');
INSERT INTO `historique` VALUES ('356','678','2ba2be5ad01500','2022-07-28 11:40:27','','transfuseur','','','','2','1000','Kamdem','','payé');
INSERT INTO `historique` VALUES ('357','420','217b01de521000','2022-08-18 15:03:39','KASL','amoxiciline','comprimé','','12-24/02-25','4','1000','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('358','415','b640abc9123600','2022-08-18 15:07:55','ZMOS','arthemeter','comprimé','','02-25','2','3600','Kamdem','','non payé');
INSERT INTO `historique` VALUES ('359','415','6fe44aa6c540700','2022-10-09 13:16:22','ZMOS','arthemeter','comprimé','','02-25','4','7200','ABC','','non payé');
INSERT INTO `historique` VALUES ('360','350','6fe44aa6c540700','2022-10-09 13:16:22','MAAS','minoxidil 300ml','','','02-23','4','30000','ABC','','non payé');
INSERT INTO `historique` VALUES ('361','678','6fe44aa6c540700','2022-10-09 13:16:22','','transfuseur','','','','5','2500','ABC','','non payé');
INSERT INTO `historique` VALUES ('362','344','6fe44aa6c540700','2022-10-09 13:16:22','MASL','metronidazol',' ','','08-25','4','1000','ABC','','non payé');
INSERT INTO `historique` VALUES ('363','420','4c9c3a337c53900','2022-10-09 13:19:35','KASL','amoxiciline','comprimé','','12-24/02-25','4','1000','ABC','','non payé');
INSERT INTO `historique` VALUES ('364','350','4c9c3a337c53900','2022-10-09 13:19:35','MAAS','minoxidil 300ml','','','02-23','7','52500','ABC','','non payé');
INSERT INTO `historique` VALUES ('365','683','4c9c3a337c53900','2022-10-09 13:19:35','','ccc','c','sp','','4','400','ABC','','non payé');
INSERT INTO `historique` VALUES ('366','350','e328718eee7900','2022-10-09 13:21:46','MAAS','minoxidil 300ml','','','02-23','1','7500','ABC','','non payé');
INSERT INTO `historique` VALUES ('367','683','e328718eee7900','2022-10-09 13:21:46','','ccc','c','sp','','4','400','ABC','','non payé');
INSERT INTO `historique` VALUES ('368','683','77ee73b0b4400','2022-10-09 13:22:29','','ccc','c','sp','','4','400','ABC','','non payé');
INSERT INTO `historique` VALUES ('369','350','7af913dc7e37900','2022-10-09 13:24:48','MAAS','minoxidil 300ml','','','02-23','5','37500','ABC','','non payé');
INSERT INTO `historique` VALUES ('370','349','7af913dc7e37900','2022-10-09 13:24:48','KAAA','paracétamol','comprimé','','10-25','4','400','ABC','','non payé');
INSERT INTO `historique` VALUES ('371','676','4d55ce80856150','2022-10-09 13:26:49','','sayana press','','','','10','5000','ABC','','non payé');
INSERT INTO `historique` VALUES ('372','349','4d55ce80856150','2022-10-09 13:26:49','KAAA','paracétamol','comprimé','','10-25','4','400','ABC','','non payé');
INSERT INTO `historique` VALUES ('373','677','4d55ce80856150','2022-10-09 13:26:49','','perfuseur','','','','3','750','ABC','','non payé');
INSERT INTO `historique` VALUES ('374','418','eeaa2bf7b4750','2022-10-09 13:30:50','MASL','ibuprofene',' cp','sp','03-24','5','750','ABC','','non payé');
INSERT INTO `historique` VALUES ('375','418','1bdb235aa9750','2022-10-09 13:31:05','MASL','ibuprofene',' cp','sp','03-24','5','750','ABC','','non payé');
INSERT INTO `historique` VALUES ('376','418','a70f6ea4fc1100','2022-10-09 13:31:47','MASL','ibuprofene',' cp','sp','03-24','4','600','ABC','','non payé');
INSERT INTO `historique` VALUES ('377','676','a70f6ea4fc1100','2022-10-09 13:31:47','','sayana press','','','','1','500','ABC','','non payé');
INSERT INTO `historique` VALUES ('378','344','e75eb4b7151500','2022-10-09 13:33:07','MASL','metronidazol',' ','','08-25','5','1250','ABC','','non payé');
INSERT INTO `historique` VALUES ('379','677','e75eb4b7151500','2022-10-09 13:33:07','','perfuseur','','','','1','250','ABC','','non payé');
INSERT INTO `historique` VALUES ('380','344','8ca85799f31750','2022-10-09 13:34:03','MASL','metronidazol',' ','','08-25','5','1250','ABC','','non payé');
INSERT INTO `historique` VALUES ('381','676','8ca85799f31750','2022-10-09 13:34:03','','sayana press','','','','1','500','ABC','','non payé');
INSERT INTO `historique` VALUES ('382','418','f5086b3dfd850','2022-10-09 13:35:34','MASL','ibuprofene',' cp','sp','03-24','4','600','ABC','','non payé');
INSERT INTO `historique` VALUES ('383','344','f5086b3dfd850','2022-10-09 13:35:34','MASL','metronidazol',' ','','08-25','1','250','ABC','','non payé');
INSERT INTO `historique` VALUES ('384','418','ef6f4f2d9e700','2022-10-09 13:36:36','MASL','ibuprofene',' cp','sp','03-24','4','600','ABC','','non payé');
INSERT INTO `historique` VALUES ('385','349','ef6f4f2d9e700','2022-10-09 13:36:36','KAAA','paracétamol','comprimé','','10-25','1','100','ABC','','non payé');
INSERT INTO `historique` VALUES ('386','349','36fbb45939450','2022-10-09 13:38:26','KAAA','paracétamol','comprimé','','10-25','3','300','ABC','','non payé');
INSERT INTO `historique` VALUES ('387','418','36fbb45939450','2022-10-09 13:38:26','MASL','ibuprofene',' cp','sp','03-24','1','150','ABC','','non payé');
INSERT INTO `historique` VALUES ('388','418','f79f1bf8f63550','2022-10-09 13:42:24','MASL','ibuprofene',' cp','sp','03-24','2','300','ABC','','non payé');
INSERT INTO `historique` VALUES ('389','685','f79f1bf8f63550','2022-10-09 13:42:24','','cofantrine','cp','generique','','2','3000','ABC','','non payé');
INSERT INTO `historique` VALUES ('390','681','f79f1bf8f63550','2022-10-09 13:42:24','','litacol','cp','','','1','250','ABC','','non payé');
INSERT INTO `historique` VALUES ('391','681','ae31ecc962800','2022-10-09 13:43:11','','litacol','cp','','','2','500','ABC','','non payé');
INSERT INTO `historique` VALUES ('392','418','ae31ecc962800','2022-10-09 13:43:11','MASL','ibuprofene',' cp','sp','03-24','2','300','ABC','','non payé');
INSERT INTO `historique` VALUES ('393','685','d571ad19be4650','2022-10-09 13:44:09','','cofantrine','cp','generique','','3','4500','ABC','','non payé');
INSERT INTO `historique` VALUES ('394','418','d571ad19be4650','2022-10-09 13:44:09','MASL','ibuprofene',' cp','sp','03-24','1','150','ABC','','non payé');
INSERT INTO `historique` VALUES ('395','685','973c23d8f86200','2022-10-09 13:46:19','','cofantrine','cp','generique','','3','4500','ABC','','non payé');
INSERT INTO `historique` VALUES ('396','684','973c23d8f86200','2022-10-09 13:46:19','','artefan','','generique','','1','1700','ABC','','non payé');
INSERT INTO `historique` VALUES ('397','418','71fcf267624800','2022-10-09 13:47:10','MASL','ibuprofene',' cp','sp','03-24','2','300','ABC','','non payé');
INSERT INTO `historique` VALUES ('398','685','71fcf267624800','2022-10-09 13:47:10','','cofantrine','cp','generique','','3','4500','ABC','','non payé');
INSERT INTO `historique` VALUES ('399','685','cbdace5a343300','2022-10-09 13:48:30','','cofantrine','cp','generique','','1','1500','ABC','','non payé');
INSERT INTO `historique` VALUES ('400','415','cbdace5a343300','2022-10-09 13:48:30','ZMOS','arthemeter','comprimé','','02-25','1','1800','ABC','','non payé');
INSERT INTO `historique` VALUES ('401','685','dd988ecf7d6100','2022-10-09 13:51:09','','cofantrine','cp','generique','','2','3000','ABC','','non payé');
INSERT INTO `historique` VALUES ('402','349','dd988ecf7d6100','2022-10-09 13:51:09','KAAA','paracétamol','comprimé','','10-25','4','400','ABC','','non payé');
INSERT INTO `historique` VALUES ('403','420','dd988ecf7d6100','2022-10-09 13:51:09','KASL','amoxiciline','comprimé','','12-24/02-25','4','1000','ABC','','non payé');
INSERT INTO `historique` VALUES ('404','684','dd988ecf7d6100','2022-10-09 13:51:09','','artefan','','generique','','1','1700','ABC','','non payé');
INSERT INTO `historique` VALUES ('405','348','7517107822800','2022-10-09 14:11:53','KASL','amoxi','comprimé','','12-24/05-25','4','800','ABC','','non payé');
INSERT INTO `historique` VALUES ('406','348','c30f9a4a1a800','2022-10-09 14:13:49','KASL','amoxi','comprimé','','12-24/05-25','4','800','ABC','','non payé');
INSERT INTO `historique` VALUES ('407','684','6d94a3a56c3650','2022-10-09 14:14:29','','artefan','','generique','','2','3400','ABC','','non payé');
INSERT INTO `historique` VALUES ('408','681','6d94a3a56c3650','2022-10-09 14:14:29','','litacol','cp','','','1','250','ABC','','non payé');
INSERT INTO `historique` VALUES ('409','684','b1fbf43ec18900','2022-10-09 14:15:10','','artefan','','generique','','5','8500','ABC','','non payé');
INSERT INTO `historique` VALUES ('410','349','b1fbf43ec18900','2022-10-09 14:15:10','KAAA','paracétamol','comprimé','','10-25','4','400','ABC','','non payé');
INSERT INTO `historique` VALUES ('411','684','dfcbce074915800','2022-10-09 14:20:33','','artefan','','generique','','4','6800','ABC','','non payé');
INSERT INTO `historique` VALUES ('412','678','dfcbce074915800','2022-10-09 14:20:33','','transfuseur','','','','8','4000','ABC','','non payé');
INSERT INTO `historique` VALUES ('413','676','dfcbce074915800','2022-10-09 14:20:33','','sayana press','','','','10','5000','ABC','','non payé');
INSERT INTO `historique` VALUES ('414','348','ed5965f5291850','2022-10-09 14:50:11','KASL','amoxi','comprimé','','12-24/05-25','4','800','ABC','','non payé');
INSERT INTO `historique` VALUES ('415','677','ed5965f5291850','2022-10-09 14:50:11','','perfuseur','','','','3','750','ABC','','non payé');
INSERT INTO `historique` VALUES ('416','418','ed5965f5291850','2022-10-09 14:50:11','MASL','ibuprofene',' cp','sp','03-24','2','300','ABC','','non payé');
INSERT INTO `historique` VALUES ('417','686','5ff1644df73000','2022-10-09 14:58:50','','malacur','cp','sp','','2','2000','ABC','','non payé');
INSERT INTO `historique` VALUES ('418','420','5ff1644df73000','2022-10-09 14:58:50','KASL','amoxiciline','comprimé','','12-24/02-25','4','1000','ABC','','non payé');
INSERT INTO `historique` VALUES ('419','415','e4255faa663250','2022-10-09 17:15:08','ZMOS','arthemeter','comprimé','','02-25','2','3000','ABC','','non payé');
INSERT INTO `historique` VALUES ('420','420','e4255faa663250','2022-10-09 17:15:08','KASL','amoxiciline','comprimé','','12-24/02-25','1','250','ABC','','non payé');
INSERT INTO `historique` VALUES ('421','420','183777e9782500','2022-10-12 08:44:58','KASL','amoxiciline','comprimé','','12-24/02-25','6','1500','ABC','','non payé');
INSERT INTO `historique` VALUES ('422','686','183777e9782500','2022-10-12 08:44:58','','malacur','cp','sp','','1','1000','ABC','','non payé');
INSERT INTO `historique` VALUES ('423','686','a354f9be882150','2022-10-12 15:53:23','','malacur','cp','sp','','2','2000','ABC','','payé');
INSERT INTO `historique` VALUES ('424','418','a354f9be882150','2022-10-12 15:53:23','MASL','ibuprofene',' cp','sp','03-24','1','150','ABC','','payé');
INSERT INTO `historique` VALUES ('425','415','d60995bdd01500','2022-10-12 16:00:11','ZMOS','arthemeter','comprimé','','02-25','1','1500','ABC','','payé');
INSERT INTO `historique` VALUES ('426','685','9aa6fddff73000','2022-10-12 16:00:59','','cofantrine','cp','generique','','2','3000','ABC','','non payé');
INSERT INTO `historique` VALUES ('427','677','769ae2746b750','2022-10-12 16:01:19','','perfuseur','','','','3','750','ABC','','non payé');


DROP TABLE IF EXISTS `historique_services`;
CREATE TABLE `historique_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_facture` varchar(255) NOT NULL,
  `designation` text NOT NULL,
  `prix` int(11) NOT NULL,
  `categorie` varchar(200) NOT NULL,
  `reduction` int(11) NOT NULL,
  `caissier` varchar(200) NOT NULL,
  `date_fait` date NOT NULL,
  `heure_fait` time NOT NULL,
  `patient` varchar(150) NOT NULL,
  `assurance` varchar(255) NOT NULL,
  `date_heure` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=494 DEFAULT CHARSET=utf8mb4;

INSERT INTO `historique_services` VALUES ('134','238202101177063916033074486957','CHR K5','2500','','50','Kamdem','2021-09-23','09:57:06','Nolla','','2021-09-23 09:57:06');
INSERT INTO `historique_services` VALUES ('135','19202101623393367672800716055','CHR Incision','2000','','0','Kamdem','2021-10-01','00:55:16','Richard Kenfack','','2021-10-01 00:55:16');
INSERT INTO `historique_services` VALUES ('136','19202101950887884150173116114','CHR K10','10000','','0','Kamdem','2021-10-01','01:14:16','Alan Kamga','','2021-10-01 01:14:16');
INSERT INTO `historique_services` VALUES ('137','192021010638884030351858424119','CHR K10','10000','','0','Kamdem','2021-10-01','01:19:24','Bob Manga','','2021-10-01 01:19:24');
INSERT INTO `historique_services` VALUES ('138','192021011134685269710935512142','CHR Incision','2000','','0','Kamdem','2021-10-01','01:42:12','Richard Kenfack','','2021-10-01 01:42:12');
INSERT INTO `historique_services` VALUES ('139','19202101226977731707909580144','CHR K1','1000','','0','Kamdem','2021-10-01','01:44:00','ali mohammed','','2021-10-01 01:44:00');
INSERT INTO `historique_services` VALUES ('140','1920210166302306143280356146','CHR K14','14000','','0','Kamdem','2021-10-01','01:46:56','Bob Manga','','2021-10-01 01:46:56');
INSERT INTO `historique_services` VALUES ('141','19202101140995588024167343629','CHR K10','10000','','0','Kamdem','2021-10-01','02:09:36','Bob Manga','','2021-10-01 02:09:36');
INSERT INTO `historique_services` VALUES ('142','19202101386926404517832950210','CHR K1','1000','','0','Kamdem','2021-10-01','02:10:50','ali mohammed','','2021-10-01 02:10:50');
INSERT INTO `historique_services` VALUES ('145','392021019275605961920956481922','CHR K10','10000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('146','392021019275605961920956481922','CHR K1','1000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('147','392021019275605961920956481922','CHR K1','1000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('148','392021019275605961920956481922','LAB ACHVC','4500','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('149','392021019275605961920956481922','LAB AMH','48000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('150','392021019275605961920956481922','MED Ami','1500','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('151','392021019275605961920956481922','MED Ami','1500','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('152','392021019275605961920956481922','MED Dossier médical','1000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('153','392021019275605961920956481922','Echographie Pelvienne Endovaginale','12000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('154','392021019275605961920956481922','RX Age osseux (main et poignet)','20000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('155','392021019275605961920956481922','RX Bras (F/P)','12000','','0','Kamdem','2021-10-03','19:22:48','Nolla','','2021-10-03 19:22:48');
INSERT INTO `historique_services` VALUES ('156','392021016269490718940572343','CHR K1','1000','','0','Kamdem','2021-10-03','23:43:07','Richard Kenfack','','2021-10-03 23:43:07');
INSERT INTO `historique_services` VALUES ('157','392021016269490718940572343','CHR K10','10000','','0','Kamdem','2021-10-03','23:43:07','Richard Kenfack','','2021-10-03 23:43:07');
INSERT INTO `historique_services` VALUES ('158','392021016269490718940572343','LAB AC anti Hbs','13500','','0','Kamdem','2021-10-03','23:43:07','Richard Kenfack','','2021-10-03 23:43:07');
INSERT INTO `historique_services` VALUES ('159','392021016269490718940572343','LAB ASLO','4000','','0','Kamdem','2021-10-03','23:43:07','Richard Kenfack','','2021-10-03 23:43:07');
INSERT INTO `historique_services` VALUES ('160','49202101030359975529935083207','CHR K1','1000','','0','Kamdem','2021-10-04','00:07:32','Nolla','','2021-10-04 00:07:32');
INSERT INTO `historique_services` VALUES ('161','49202101030359975529935083207','CHR K2','2000','','0','Kamdem','2021-10-04','00:07:32','Nolla','','2021-10-04 00:07:32');
INSERT INTO `historique_services` VALUES ('162','5920210101911466067047529219196','LAB ACE','20000','','0','Kamdem','2021-10-05','19:06:19','Bob Manga','','2021-10-05 19:06:19');
INSERT INTO `historique_services` VALUES ('163','5920210101911466067047529219196','Echographie Occulaire','12000','','0','Kamdem','2021-10-05','19:06:19','Bob Manga','','2021-10-05 19:06:19');
INSERT INTO `historique_services` VALUES ('164','5920210101911466067047529219196','RX Sternum, clavicule (F/P)','10000','','0','Kamdem','2021-10-05','19:06:19','Bob Manga','','2021-10-05 19:06:19');
INSERT INTO `historique_services` VALUES ('165','5920210101911466067047529219196','CHR K1','1000','','0','Kamdem','2021-10-05','19:06:19','Bob Manga','','2021-10-05 19:06:19');
INSERT INTO `historique_services` VALUES ('166','5920210101911466067047529219196','Echographie Occulaire','12000','','0','Kamdem','2021-10-05','19:06:19','Bob Manga','','2021-10-05 19:06:19');
INSERT INTO `historique_services` VALUES ('167','59202101663952295399742150197','Echographie Occulaire','12000','','0','Kamdem','2021-10-05','19:07:50','Bob Manga','','2021-10-05 19:07:50');
INSERT INTO `historique_services` VALUES ('168','59202101663952295399742150197','Echographie Occulaire','12000','','0','Kamdem','2021-10-05','19:07:50','Bob Manga','','2021-10-05 19:07:50');
INSERT INTO `historique_services` VALUES ('169','59202101663952295399742150197','CHR K1','1000','','0','Kamdem','2021-10-05','19:07:50','Bob Manga','','2021-10-05 19:07:50');
INSERT INTO `historique_services` VALUES ('170','59202101663952295399742150197','LAB ACE','20000','','0','Kamdem','2021-10-05','19:07:50','Bob Manga','','2021-10-05 19:07:50');
INSERT INTO `historique_services` VALUES ('171','59202101663952295399742150197','RX Sternum, clavicule (F/P)','10000','','0','Kamdem','2021-10-05','19:07:50','Bob Manga','','2021-10-05 19:07:50');
INSERT INTO `historique_services` VALUES ('172','69202101665831606096897625836','CHR K1','1000','','0','Kamdem','2021-10-06','08:36:25','Alan Kamga','','2021-10-06 08:36:25');
INSERT INTO `historique_services` VALUES ('173','69202101665831606096897625836','MED Ami','1500','','0','Kamdem','2021-10-06','08:36:25','Alan Kamga','','2021-10-06 08:36:25');
INSERT INTO `historique_services` VALUES ('174','69202101665831606096897625836','MED Ami','1500','','0','Kamdem','2021-10-06','08:36:25','Alan Kamga','','2021-10-06 08:36:25');
INSERT INTO `historique_services` VALUES ('175','69202101665831606096897625836','LAB Transaminases (SGOT/SGPT)','8000','','0','Kamdem','2021-10-06','08:36:25','Alan Kamga','','2021-10-06 08:36:25');
INSERT INTO `historique_services` VALUES ('176','69202101665831606096897625836','MED Ami','1500','','0','Kamdem','2021-10-06','08:36:25','Alan Kamga','','2021-10-06 08:36:25');
INSERT INTO `historique_services` VALUES ('177','69202101858513092452877931838','MED Soins infirmiers','1000','','0','Kamdem','2021-10-06','08:38:31','ali mohammed','','2021-10-06 08:38:31');
INSERT INTO `historique_services` VALUES ('178','69202101858513092452877931838','MED Dossier médical','1000','','0','Kamdem','2021-10-06','08:38:31','ali mohammed','','2021-10-06 08:38:31');
INSERT INTO `historique_services` VALUES ('179','69202101858513092452877931838','MED Pose cathether','1000','','0','Kamdem','2021-10-06','08:38:31','ali mohammed','','2021-10-06 08:38:31');
INSERT INTO `historique_services` VALUES ('180','69202101858513092452877931838','MED Hospitalisation simple','1500','','0','Kamdem','2021-10-06','08:38:31','ali mohammed','','2021-10-06 08:38:31');
INSERT INTO `historique_services` VALUES ('181','692021019303816969979544291234','CHR K1','1000','','0','Kamdem','2021-10-06','12:34:29','Bob Manga','','2021-10-06 12:34:29');
INSERT INTO `historique_services` VALUES ('182','692021010732292521303827830131','CHR K10','10000','','0','Kamdem','2021-10-06','13:01:30','abel','','2021-10-06 13:01:30');
INSERT INTO `historique_services` VALUES ('183','692021012325474606859818728135','LAB Chlamydia','8000','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('184','692021012325474606859818728135','LAB ACHVC','4500','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('185','692021012325474606859818728135','LAB AC anti Hbe','13500','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('186','692021012325474606859818728135','LAB Calcium','3600','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('187','692021012325474606859818728135','LAB Calcium','3600','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('188','692021012325474606859818728135','LAB Calcium','3600','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('189','692021012325474606859818728135','LAB Calcium','3600','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('190','692021012325474606859818728135','LAB Calcium','3600','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('191','692021012325474606859818728135','LAB NFS','6300','','0','Kamdem','2021-10-06','13:05:28','masse','','2021-10-06 13:05:28');
INSERT INTO `historique_services` VALUES ('192','692021018870879161099268351310','MED Ami','1500','','0','Kamdem','2021-10-06','13:10:35','ekedi','','2021-10-06 13:10:35');
INSERT INTO `historique_services` VALUES ('193','692021018870879161099268351310','MED Dossier médical','1000','','0','Kamdem','2021-10-06','13:10:35','ekedi','','2021-10-06 13:10:35');
INSERT INTO `historique_services` VALUES ('194','692021018870879161099268351310','MED Pose cathether','1000','','0','Kamdem','2021-10-06','13:10:35','ekedi','','2021-10-06 13:10:35');
INSERT INTO `historique_services` VALUES ('195','69202101371016474820312491341','CO Carnet de consultation','400','','0','Kamdem','2021-10-06','13:41:09','ali mohammed','','2021-10-06 13:41:09');
INSERT INTO `historique_services` VALUES ('196','69202101371016474820312491341','CO Consultation simple','600','','0','Kamdem','2021-10-06','13:41:09','ali mohammed','','2021-10-06 13:41:09');
INSERT INTO `historique_services` VALUES ('197','692021014140097386492354421342','CO Carnet de consultation','400','','0','Kamdem','2021-10-06','13:42:42','mbezele','','2021-10-06 13:42:42');
INSERT INTO `historique_services` VALUES ('198','692021014140097386492354421342','CO Consultation simple','600','','0','Kamdem','2021-10-06','13:42:42','mbezele','','2021-10-06 13:42:42');
INSERT INTO `historique_services` VALUES ('199','69202101765434379205538501348','MA Forfait maternité','7600','','0','Kamdem','2021-10-06','13:48:00','kengne marie','','2021-10-06 13:48:00');
INSERT INTO `historique_services` VALUES ('200','69202101765434379205538501348','CHR K20','20000','','0','Kamdem','2021-10-06','13:48:00','kengne marie','','2021-10-06 13:48:00');
INSERT INTO `historique_services` VALUES ('201','69202101765434379205538501348','CO Consultation prénatale','5500','','0','Kamdem','2021-10-06','13:48:00','kengne marie','','2021-10-06 13:48:00');
INSERT INTO `historique_services` VALUES ('202','69202101568828491293746461349','MED Hospitalisation VIP','5000','','0','Kamdem','2021-10-06','13:49:46','Nolla','','2021-10-06 13:49:46');
INSERT INTO `historique_services` VALUES ('203','69202101568828491293746461349','MED Hospitalisation VIP','5000','','0','Kamdem','2021-10-06','13:49:46','Nolla','','2021-10-06 13:49:46');
INSERT INTO `historique_services` VALUES ('204','69202101568828491293746461349','MED Hospitalisation VIP','5000','','0','Kamdem','2021-10-06','13:49:46','Nolla','','2021-10-06 13:49:46');
INSERT INTO `historique_services` VALUES ('205','692021018745001022219552561353','MED Soins infirmiers','1000','','0','Kamdem','2021-10-06','13:53:56','BABILLON Christian','','2021-10-06 13:53:56');
INSERT INTO `historique_services` VALUES ('206','692021018745001022219552561353','MED Soins infirmiers','1000','','0','Kamdem','2021-10-06','13:53:56','BABILLON Christian','','2021-10-06 13:53:56');
INSERT INTO `historique_services` VALUES ('207','692021018745001022219552561353','CHR Pansement simple','500','','0','Kamdem','2021-10-06','13:53:56','BABILLON Christian','','2021-10-06 13:53:56');
INSERT INTO `historique_services` VALUES ('208','692021018745001022219552561353','MED Soins infirmiers','1000','','0','Kamdem','2021-10-06','13:53:56','BABILLON Christian','','2021-10-06 13:53:56');
INSERT INTO `historique_services` VALUES ('209','692021018745001022219552561353','MED Soins infirmiers','1000','','0','Kamdem','2021-10-06','13:53:56','BABILLON Christian','','2021-10-06 13:53:56');
INSERT INTO `historique_services` VALUES ('210','692021018745001022219552561353','CHR Pansement simple','500','','0','Kamdem','2021-10-06','13:53:56','BABILLON Christian','','2021-10-06 13:53:56');
INSERT INTO `historique_services` VALUES ('211','692021018745001022219552561353','CHR Pansement simple','500','','0','Kamdem','2021-10-06','13:53:56','BABILLON Christian','','2021-10-06 13:53:56');
INSERT INTO `historique_services` VALUES ('212','692021012137960758899633571355','LAB Glycémie à jeun','1000','','0','Kamdem','2021-10-06','13:55:57','NOLLA Jules Roland','','2021-10-06 13:55:57');
INSERT INTO `historique_services` VALUES ('213','692021012137960758899633571355','LAB Hémoglobine glycossylée (HBA1C)','10800','','0','Kamdem','2021-10-06','13:55:57','NOLLA Jules Roland','','2021-10-06 13:55:57');
INSERT INTO `historique_services` VALUES ('214','692021012137960758899633571355','LAB Triglycérides','3600','','0','Kamdem','2021-10-06','13:55:57','NOLLA Jules Roland','','2021-10-06 13:55:57');
INSERT INTO `historique_services` VALUES ('215','69202101015887847848990555131357','CO Carnet de consultation','400','','0','Kamdem','2021-10-06','13:57:13','BABILLON Christian','','2021-10-06 13:57:13');
INSERT INTO `historique_services` VALUES ('216','69202101015887847848990555131357','CO Consultation simple','600','','0','Kamdem','2021-10-06','13:57:13','BABILLON Christian','','2021-10-06 13:57:13');
INSERT INTO `historique_services` VALUES ('217','11920210132491774748837292294','MED Hospitalisation payant','3000','','0','Kamdem','2021-10-11','09:04:22','ekedi','','2021-10-11 09:04:22');
INSERT INTO `historique_services` VALUES ('218','11920210132491774748837292294','LAB ACHVC','4500','','0','Kamdem','2021-10-11','09:04:22','ekedi','','2021-10-11 09:04:22');
INSERT INTO `historique_services` VALUES ('221','1492021010389943647516624171441','CHR K10','10000','','0','Kamdem','2021-10-14','14:41:17','kengne marie','','2021-10-14 14:41:17');
INSERT INTO `historique_services` VALUES ('222','1492021010389943647516624171441','Echographie Pelvienne','7500','','0','Kamdem','2021-10-14','14:41:17','kengne marie','','2021-10-14 14:41:17');
INSERT INTO `historique_services` VALUES ('223','1492021010389943647516624171441','LAB ASLO','4000','','0','Kamdem','2021-10-14','14:41:17','kengne marie','','2021-10-14 14:41:17');
INSERT INTO `historique_services` VALUES ('224','1492021010389943647516624171441','CO Carnet de consultation','400','','0','Kamdem','2021-10-14','14:41:17','kengne marie','','2021-10-14 14:41:17');
INSERT INTO `historique_services` VALUES ('225','1492021010389943647516624171441','CHR K1','1000','','0','Kamdem','2021-10-14','14:41:17','kengne marie','','2021-10-14 14:41:17');
INSERT INTO `historique_services` VALUES ('226','1492021010389943647516624171441','LAB ACE','20000','','0','Kamdem','2021-10-14','14:41:17','kengne marie','','2021-10-14 14:41:17');
INSERT INTO `historique_services` VALUES ('227','1492021010389943647516624171441','Echographie parties molles','10000','','0','Kamdem','2021-10-14','14:41:17','kengne marie','','2021-10-14 14:41:17');
INSERT INTO `historique_services` VALUES ('228','1492021010389943647516624171441','MED Ami','1500','','0','Kamdem','2021-10-14','14:41:18','kengne marie','','2021-10-14 14:41:18');
INSERT INTO `historique_services` VALUES ('229','1492021010389943647516624171441','MED Ami','1500','','0','Kamdem','2021-10-14','14:41:18','kengne marie','','2021-10-14 14:41:18');
INSERT INTO `historique_services` VALUES ('230','1492021010389943647516624171441','MED Ami','1500','','0','Kamdem','2021-10-14','14:41:18','kengne marie','','2021-10-14 14:41:18');
INSERT INTO `historique_services` VALUES ('231','1492021010389943647516624171441','RX Avant-bras (F/P)','12000','','0','Kamdem','2021-10-14','14:41:18','kengne marie','','2021-10-14 14:41:18');
INSERT INTO `historique_services` VALUES ('232','1492021010389943647516624171441','RX Doigt (F/P)','10000','','0','Kamdem','2021-10-14','14:41:18','kengne marie','','2021-10-14 14:41:18');
INSERT INTO `historique_services` VALUES ('233','149202101479631270946957467155','RX Rachis dorsal (F/P)','15000','','0','Kamdem','2021-10-14','15:05:07','Alan Kamga','','2021-10-14 15:05:07');
INSERT INTO `historique_services` VALUES ('234','149202101479631270946957467155','CHR K1','1000','','0','Kamdem','2021-10-14','15:05:07','Alan Kamga','','2021-10-14 15:05:07');
INSERT INTO `historique_services` VALUES ('235','149202101479631270946957467155','MED Injection','500','','0','Kamdem','2021-10-14','15:05:07','Alan Kamga','','2021-10-14 15:05:07');
INSERT INTO `historique_services` VALUES ('236','149202101479631270946957467155','MED Hospitalisation simple','1500','','0','Kamdem','2021-10-14','15:05:07','Alan Kamga','','2021-10-14 15:05:07');
INSERT INTO `historique_services` VALUES ('237','149202101479631270946957467155','LAB ACHVC','4500','','0','Kamdem','2021-10-14','15:05:07','Alan Kamga','','2021-10-14 15:05:07');
INSERT INTO `historique_services` VALUES ('238','149202101479631270946957467155','MED Injection','500','','0','Kamdem','2021-10-14','15:05:07','Alan Kamga','','2021-10-14 15:05:07');
INSERT INTO `historique_services` VALUES ('239','149202101639862157864042181522','CHR Incision','2000','','0','Kamdem','2021-10-14','15:22:18','masse','','2021-10-14 15:22:18');
INSERT INTO `historique_services` VALUES ('240','1492021015812375733171891511523','CHR K10','10000','','0','Kamdem','2021-10-14','15:23:51','ali mohammed','','2021-10-14 15:23:51');
INSERT INTO `historique_services` VALUES ('241','1492021015812375733171891511523','MED Injection','500','','0','Kamdem','2021-10-14','15:23:51','ali mohammed','','2021-10-14 15:23:51');
INSERT INTO `historique_services` VALUES ('242','1492021015812375733171891511523','MED Pose cathether','1000','','0','Kamdem','2021-10-14','15:23:51','ali mohammed','','2021-10-14 15:23:51');
INSERT INTO `historique_services` VALUES ('243','1492021015812375733171891511523','MED Dossier médical','1000','','0','Kamdem','2021-10-14','15:23:51','ali mohammed','','2021-10-14 15:23:51');
INSERT INTO `historique_services` VALUES ('244','1492021015812375733171891511523','MED Hospitalisation simple','1500','','0','Kamdem','2021-10-14','15:23:51','ali mohammed','','2021-10-14 15:23:51');
INSERT INTO `historique_services` VALUES ('245','1492021015812375733171891511523','MA Forfait maternité','7600','','0','Kamdem','2021-10-14','15:23:51','ali mohammed','','2021-10-14 15:23:51');
INSERT INTO `historique_services` VALUES ('246','1492021015812375733171891511523','MA Suture vaginale','7500','','0','Kamdem','2021-10-14','15:23:51','ali mohammed','','2021-10-14 15:23:51');
INSERT INTO `historique_services` VALUES ('247','a5cc','CHR Incision','2000','','0','Kamdem','2021-10-15','11:23:57','abel','','2021-10-15 11:23:57');
INSERT INTO `historique_services` VALUES ('248','997c','CHR Circoncision','5000','','0','Kamdem','2021-10-17','14:54:25','Omah ley','','2021-10-17 14:54:25');
INSERT INTO `historique_services` VALUES ('249','37b4','LAB D.dimeres','20000','','0','Kamdem','2021-10-18','14:10:42','Bob Manga','','2021-10-18 14:10:42');
INSERT INTO `historique_services` VALUES ('250','37b4','Echographie Thyroidienne, Echographie Cervicale (parotide…)','20000','','0','Kamdem','2021-10-18','14:10:42','Bob Manga','','2021-10-18 14:10:42');
INSERT INTO `historique_services` VALUES ('251','37b4','Echographie Rénale (ou voies urinaires ou arbres urinaires)','10000','','0','Kamdem','2021-10-18','14:10:42','Bob Manga','','2021-10-18 14:10:42');
INSERT INTO `historique_services` VALUES ('252','37b4','Echographie Testiculaire (ou scrotale ou bourses)','12500','','0','Kamdem','2021-10-18','14:10:42','Bob Manga','','2021-10-18 14:10:42');
INSERT INTO `historique_services` VALUES ('253','cc3a','LAB Chlamydia PCR','35000','','0','Kamdem','2021-10-18','20:43:18','mbezele','','2021-10-18 20:43:18');
INSERT INTO `historique_services` VALUES ('254','956f','CHR K1','1000','','0','Kamdem','2021-10-18','22:17:58','Bob Manga','','2021-10-18 22:17:58');
INSERT INTO `historique_services` VALUES ('255','956f','CHR K10','10000','','0','Kamdem','2021-10-18','22:17:58','Bob Manga','','2021-10-18 22:17:58');
INSERT INTO `historique_services` VALUES ('256','956f','CHR K1','1000','','0','Kamdem','2021-10-18','22:17:58','Bob Manga','','2021-10-18 22:17:58');
INSERT INTO `historique_services` VALUES ('257','ffa3','CHR K11','11000','','0','Kamdem','2021-10-18','22:22:58','masse','','2021-10-18 22:22:58');
INSERT INTO `historique_services` VALUES ('258','419d','CHR Incision','2000','','0','Kamdem','2021-10-19','10:37:37','bernard nanga','','2021-10-19 10:37:37');
INSERT INTO `historique_services` VALUES ('259','401c','LAB Widal et Felix','3600','','0','Kamdem','2021-10-19','10:39:30','masse','','2021-10-19 10:39:30');
INSERT INTO `historique_services` VALUES ('260','620a','CHR K1','1000','','0','Kamdem','2021-10-20','10:35:20','Bob Manga','','2021-10-20 10:35:20');
INSERT INTO `historique_services` VALUES ('261','56a7','CHR K1','1000','','0','Kamdem','2021-10-20','12:03:05','Bob Manga','','2021-10-20 12:03:05');
INSERT INTO `historique_services` VALUES ('262','60c7','CHR K2','2000','','0','Kamdem','2021-10-20','12:04:10','Richard Kenfack','','2021-10-20 12:04:10');
INSERT INTO `historique_services` VALUES ('264','8493','LAB NFS','1890','','30','Kamdem','2021-10-23','10:47:44','abel','','2021-10-23 10:47:44');
INSERT INTO `historique_services` VALUES ('265','8493','LAB GE','300','','30','Kamdem','2021-10-23','10:47:45','abel','','2021-10-23 10:47:45');
INSERT INTO `historique_services` VALUES ('266','3afa','CHR K1','500','','50','Kamdem','2021-10-23','10:52:09','Nolla','','2021-10-23 10:52:09');
INSERT INTO `historique_services` VALUES ('267','e868','CHR K1','1000','','30','Kamdem','2021-10-23','10:55:31','Bob Manga','','2021-10-23 10:55:31');
INSERT INTO `historique_services` VALUES ('268','c390','CHR K1','1000','','0','Kamdem','2021-10-25','16:42:45','abel','','2021-10-25 16:42:45');
INSERT INTO `historique_services` VALUES ('269','10cb','CHR Incision','2000','','0','Kamdem','2021-10-25','16:44:35','Nolla','','2021-10-25 16:44:35');
INSERT INTO `historique_services` VALUES ('270','10cb','CHR K1','1000','','0','Kamdem','2021-10-25','16:44:35','Nolla','','2021-10-25 16:44:35');
INSERT INTO `historique_services` VALUES ('271','be7a','CHR K1','1000','','0','Kamdem','2021-10-25','16:49:09','ali mohammed','','2021-10-25 16:49:09');
INSERT INTO `historique_services` VALUES ('272','be7a','CHR Incision','2000','','0','Kamdem','2021-10-25','16:49:09','ali mohammed','','2021-10-25 16:49:09');
INSERT INTO `historique_services` VALUES ('273','e334','CHR Incision','2000','','30','Kamdem','2021-10-25','16:50:52','Nolla','','2021-10-25 16:50:52');
INSERT INTO `historique_services` VALUES ('274','e334','CHR K1','1000','','30','Kamdem','2021-10-25','16:50:52','Nolla','','2021-10-25 16:50:52');
INSERT INTO `historique_services` VALUES ('275','2cc0','CHR K1','1000','','0','Kamdem','2021-10-25','16:58:47','ariane','','2021-10-25 16:58:47');
INSERT INTO `historique_services` VALUES ('276','3adf','CHR Incision','2000','','0','Kamdem','2021-10-25','17:14:50','Alan Kamga','','2021-10-25 17:14:50');
INSERT INTO `historique_services` VALUES ('277','2708','CHR Circoncision','5000','','0','Kamdem','2021-10-25','17:19:03','Alan Kamga','','2021-10-25 17:19:03');
INSERT INTO `historique_services` VALUES ('278','ccee','CHR K1','1000','','0','Kamdem','2021-10-25','17:20:09','Bob Manga','','2021-10-25 17:20:09');
INSERT INTO `historique_services` VALUES ('279','4696','CHR Incision','2000','','0','Kamdem','2021-10-25','17:20:51','Richard Kenfack','','2021-10-25 17:20:51');
INSERT INTO `historique_services` VALUES ('280','d2b4','CHR K1','1000','','0','Kamdem','2021-10-25','17:28:37','Richard Kenfack','','2021-10-25 17:28:37');
INSERT INTO `historique_services` VALUES ('281','714d','CHR Circoncision','5000','','0','Kamdem','2021-10-25','17:29:38','ali mohammed','','2021-10-25 17:29:38');
INSERT INTO `historique_services` VALUES ('282','bf3e','CHR Incision','2000','','0','Kamdem','2021-10-27','10:45:12','Alan Kamga','','2021-10-27 10:45:12');
INSERT INTO `historique_services` VALUES ('283','a96a','LAB Widal et Felix','3600','','0','Kamdem','2021-10-27','16:28:31','Alan Kamga','','2021-10-27 16:28:31');
INSERT INTO `historique_services` VALUES ('284','3cb9','LAB Triglycérides','3600','','0','Kamdem','2021-10-27','18:40:00','Alan Kamga','','2021-10-27 18:40:00');
INSERT INTO `historique_services` VALUES ('285','3cb9','LAB Widal et Felix','3600','','0','Kamdem','2021-10-27','18:40:00','Alan Kamga','','2021-10-27 18:40:00');
INSERT INTO `historique_services` VALUES ('286','59e1','LAB ASLO','4000','','0','Kamdem','2021-10-27','18:45:13','Alan Kamga','','2021-10-27 18:45:13');
INSERT INTO `historique_services` VALUES ('287','c2c1','LAB Acide urique','2700','','0','Kamdem','2021-10-27','19:04:49','Alan Kamga','','2021-10-27 19:04:49');
INSERT INTO `historique_services` VALUES ('288','1c53','LAB Dosage HCV','18000','','0','Kamdem','2021-10-27','21:04:46','Alan Kamga','','2021-10-27 21:04:46');
INSERT INTO `historique_services` VALUES ('289','c804','LAB ACHVC','4500','','0','Kamdem','2021-10-27','21:05:21','Alan Kamga','','2021-10-27 21:05:21');
INSERT INTO `historique_services` VALUES ('290','c804','RX Rachis cervical (F/P + %)','20000','','0','Kamdem','2021-10-27','21:05:21','Alan Kamga','','2021-10-27 21:05:21');
INSERT INTO `historique_services` VALUES ('291','f6d6','LAB Widal et Felix','3600','','0','Kamdem','2021-10-28','15:34:22','Alan Kamga','','2021-10-28 15:34:22');
INSERT INTO `historique_services` VALUES ('292','f6d6','LAB Glycémie à jeun','1000','','0','Kamdem','2021-10-28','15:34:22','Alan Kamga','','2021-10-28 15:34:22');
INSERT INTO `historique_services` VALUES ('293','0de6','LAB Chlamydia','8000','','0','Kamdem','2021-10-28','15:35:01','Alan Kamga','','2021-10-28 15:35:01');
INSERT INTO `historique_services` VALUES ('294','0de6','LAB Calcium','3600','','0','Kamdem','2021-10-28','15:35:01','Alan Kamga','','2021-10-28 15:35:01');
INSERT INTO `historique_services` VALUES ('295','0de6','LAB Créatine','2700','','0','Kamdem','2021-10-28','15:35:01','Alan Kamga','','2021-10-28 15:35:01');
INSERT INTO `historique_services` VALUES ('296','1841','LAB D.dimeres','20000','','0','Kamdem','2021-10-28','15:35:35','abel','','2021-10-28 15:35:35');
INSERT INTO `historique_services` VALUES ('297','1841','LAB CRP','3600','','0','Kamdem','2021-10-28','15:35:35','abel','','2021-10-28 15:35:35');
INSERT INTO `historique_services` VALUES ('298','d9e3','LAB GE','1000','','0','Kamdem','2021-10-28','15:36:08','ekedi','','2021-10-28 15:36:08');
INSERT INTO `historique_services` VALUES ('299','d9e3','LAB Fer serique','5400','','0','Kamdem','2021-10-28','15:36:08','ekedi','','2021-10-28 15:36:08');
INSERT INTO `historique_services` VALUES ('300','649e','CHR Incision','2000','','0','Kamdem','2021-11-12','09:16:19','Nolla','','2021-11-12 09:16:19');
INSERT INTO `historique_services` VALUES ('301','649e','CHR Pansement simple','500','','0','Kamdem','2021-11-12','09:16:19','Nolla','','2021-11-12 09:16:19');
INSERT INTO `historique_services` VALUES ('302','649e','Echographie parties molles','10000','','0','Kamdem','2021-11-12','09:16:19','Nolla','','2021-11-12 09:16:19');
INSERT INTO `historique_services` VALUES ('303','9776','CHR K1','1000','chirurgie','0','Kamdem','2021-11-13','03:36:45','Alan Kamga','','2021-11-13 03:36:45');
INSERT INTO `historique_services` VALUES ('304','9776','LAB Calcium','3600','Laboratoire','0','Kamdem','2021-11-13','03:36:45','Alan Kamga','','2021-11-13 03:36:45');
INSERT INTO `historique_services` VALUES ('305','2518','CA Consultation simple','900','Carnet','0','Kamdem','2021-11-14','18:21:01','BABILLON Christian','','2021-11-14 18:21:01');
INSERT INTO `historique_services` VALUES ('306','2518','LAB Magnésium','3600','Laboratoire','0','Kamdem','2021-11-14','18:21:01','BABILLON Christian','','2021-11-14 18:21:01');
INSERT INTO `historique_services` VALUES ('307','2518','MA Test de grossesse','2000','Maternité','0','Kamdem','2021-11-14','18:21:01','BABILLON Christian','','2021-11-14 18:21:01');
INSERT INTO `historique_services` VALUES ('308','2518','RX Calcanéum (F/P)','10000','Imagerie','0','Kamdem','2021-11-14','18:21:01','BABILLON Christian','','2021-11-14 18:21:01');
INSERT INTO `historique_services` VALUES ('309','2518','MED Oxygene','5000','Medecine','0','Kamdem','2021-11-14','18:21:01','BABILLON Christian','','2021-11-14 18:21:01');
INSERT INTO `historique_services` VALUES ('310','ec9f400','CA Carnet de consultation','400','Carnet','0','Kamdem','2021-11-14','19:00:36','Richard Kenfack','','2021-11-14 19:00:36');
INSERT INTO `historique_services` VALUES ('311','9f8d20000','LAB ACE','20000','service','0','Kamdem','2021-11-14','19:15:02','rogers','','2021-11-14 19:15:02');
INSERT INTO `historique_services` VALUES ('312','e70d17100','LAB ACHVC','4500','service','0','Kamdem','2021-11-14','19:15:39','rogers','','2021-11-14 19:15:39');
INSERT INTO `historique_services` VALUES ('313','e70d17100','LAB Dosage Toxo','12600','service','0','Kamdem','2021-11-14','19:15:39','rogers','','2021-11-14 19:15:39');
INSERT INTO `historique_services` VALUES ('314','716d2000','CHR Incision','2000','service','0','Kamdem','2021-11-14','19:24:56','rogers','','2021-11-14 19:24:56');
INSERT INTO `historique_services` VALUES ('315','a12611000','CHR K1','1000','chirurgie','50','Kamdem','2021-11-14','20:14:32','ross','','2021-11-14 20:14:32');
INSERT INTO `historique_services` VALUES ('316','a12611000','CHR K10','10000','Chirurgie','50','Kamdem','2021-11-14','20:14:32','ross','','2021-11-14 20:14:32');
INSERT INTO `historique_services` VALUES ('317','cc9213600','CHR K1','1000','chirurgie','30','Kamdem','2021-11-14','20:16:03','Nolla','','2021-11-14 20:16:03');
INSERT INTO `historique_services` VALUES ('318','cc9213600','LAB Dosage Toxo','12600','Laboratoire','30','Kamdem','2021-11-14','20:16:03','Nolla','','2021-11-14 20:16:03');
INSERT INTO `historique_services` VALUES ('322','4fe125100','LAB Cholestérol total','3600','Laboratoire','0','Kamdem','2021-11-15','10:44:54','rogers','','2021-11-15 10:44:54');
INSERT INTO `historique_services` VALUES ('323','4fe125100','LAB BU','1000','Laboratoire','0','Kamdem','2021-11-15','10:44:54','rogers','','2021-11-15 10:44:54');
INSERT INTO `historique_services` VALUES ('324','4fe125100','CHR Pansement simple','500','Chirurgie','0','Kamdem','2021-11-15','10:44:54','rogers','','2021-11-15 10:44:54');
INSERT INTO `historique_services` VALUES ('325','4fe125100','Echo Dopper Testiculaire','20000','Imagerie','0','Kamdem','2021-11-15','10:44:55','rogers','','2021-11-15 10:44:55');
INSERT INTO `historique_services` VALUES ('326','7c0363200','LAB ASLO','4000','Laboratoire','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('327','7c0363200','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('328','7c0363200','LAB ASLO','4000','Laboratoire','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('329','7c0363200','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('330','7c0363200','LAB Dosage Toxo','12600','Laboratoire','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('331','7c0363200','LAB ASLO','4000','Laboratoire','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('332','7c0363200','LAB Hepatite C','4500','Laboratoire','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('333','7c0363200','LAB Dosage Toxo','12600','Laboratoire','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('334','7c0363200','Echographie Occulaire','12000','Imagerie','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('335','7c0363200','Echographie Pelvienne','7500','Imagerie','0','Kamdem','2021-11-16','10:54:49','alea','','2021-11-16 10:54:49');
INSERT INTO `historique_services` VALUES ('336','4877400','CA Carnet de consultation','400','Carnet','0','Kamdem','2021-12-04','15:41:16','baba','','2021-12-04 15:41:16');
INSERT INTO `historique_services` VALUES ('337','b9a5900','CA Consultation simple','900','Carnet','0','Kamdem','2021-12-04','15:43:37','baba','','2021-12-04 15:43:37');
INSERT INTO `historique_services` VALUES ('338','7df71000','CHR K1','1000','chirurgie','0','Kamdem','2021-12-04','15:49:09','boba','','2021-12-04 15:49:09');
INSERT INTO `historique_services` VALUES ('339','902820000','LAB ACE','20000','Laboratoire','50','Kamdem','2021-12-07','10:29:32','rod','','2021-12-07 10:29:32');
INSERT INTO `historique_services` VALUES ('340','faac2000','CHR Incision','2000','Chirurgie','0','Kamdem','2021-12-09','15:01:58','Nolla','','2021-12-09 15:01:58');
INSERT INTO `historique_services` VALUES ('341','bf931500','MED Hospitalisation simple','1500','Medecine','0','Kamdem','2021-12-09','15:02:27','baba','','2021-12-09 15:02:27');
INSERT INTO `historique_services` VALUES ('342','852e10800','LAB Hémoglobine glycossylée (HBA1C)','10800','Laboratoire','0','Kamdem','2021-12-09','15:03:05','baba','','2021-12-09 15:03:05');
INSERT INTO `historique_services` VALUES ('343','eef823200','LAB Acide urique','2700','Laboratoire','50','Kamdem','2021-12-12','19:06:09','masse','','2021-12-12 19:06:09');
INSERT INTO `historique_services` VALUES ('344','eef823200','LAB ACE','20000','Laboratoire','50','Kamdem','2021-12-12','19:06:09','masse','','2021-12-12 19:06:09');
INSERT INTO `historique_services` VALUES ('345','90c22000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-01-04','02:16:55','ali mohammed','','2022-01-04 02:16:55');
INSERT INTO `historique_services` VALUES ('346','e9145000','LAB ACHVC','4500','Laboratoire','0','Kamdem','2022-01-17','11:41:50','Bob Manga','','2022-01-17 11:41:50');
INSERT INTO `historique_services` VALUES ('347','7cf534000','LAB AC anti Hbs','13500','Laboratoire','50','Kamdem','2022-01-17','11:43:03','Alan Kamga','','2022-01-17 11:43:03');
INSERT INTO `historique_services` VALUES ('348','7cf534000','LAB ACE','20000','Laboratoire','50','Kamdem','2022-01-17','11:43:03','Alan Kamga','','2022-01-17 11:43:03');
INSERT INTO `historique_services` VALUES ('349','3f2f35500','RX Bassin (F/P)','15000','Imagerie','30','Kamdem','2022-01-17','11:46:03','ali mohammed','','2022-01-17 11:46:03');
INSERT INTO `historique_services` VALUES ('350','3f2f35500','RX Rashis lombaire (F/P + %)','20000','Imagerie','30','Kamdem','2022-01-17','11:46:03','ali mohammed','','2022-01-17 11:46:03');
INSERT INTO `historique_services` VALUES ('351','9fec15500','RX Bassin (F/P)','15000','Imagerie','0','Kamdem','2022-01-17','11:46:51','Nolla','','2022-01-17 11:46:51');
INSERT INTO `historique_services` VALUES ('352','8bc937300','LAB LH','18000','Laboratoire','0','Kamdem','2022-01-18','13:17:14','Nolla','','2022-01-18 13:17:14');
INSERT INTO `historique_services` VALUES ('353','8bc937300','LAB Electrophorese','10800','Laboratoire','0','Kamdem','2022-01-18','13:17:14','Nolla','','2022-01-18 13:17:14');
INSERT INTO `historique_services` VALUES ('354','8bc937300','LAB H.PYLORI','8000','Laboratoire','0','Kamdem','2022-01-18','13:17:14','Nolla','','2022-01-18 13:17:14');
INSERT INTO `historique_services` VALUES ('355','e1e518500','RX Cheville (F/P)','10000','Imagerie','0','Kamdem','2022-01-18','13:18:16','masse','','2022-01-18 13:18:16');
INSERT INTO `historique_services` VALUES ('356','e1e518500','LAB H.PYLORI','8000','Laboratoire','0','Kamdem','2022-01-18','13:18:17','masse','','2022-01-18 13:18:17');
INSERT INTO `historique_services` VALUES ('357','81e427200','LAB Cholestérol LDL','3600','Laboratoire','0','Kamdem','2022-01-18','13:21:05','ali mohammed','','2022-01-18 13:21:05');
INSERT INTO `historique_services` VALUES ('358','81e427200','Echographie Occulaire','12000','Imagerie','0','Kamdem','2022-01-18','13:21:05','ali mohammed','','2022-01-18 13:21:05');
INSERT INTO `historique_services` VALUES ('359','81e427200','LAB Cholestérol total','3600','Laboratoire','0','Kamdem','2022-01-18','13:21:05','ali mohammed','','2022-01-18 13:21:05');
INSERT INTO `historique_services` VALUES ('360','81e427200','Echographie Pelvienne','7500','Imagerie','0','Kamdem','2022-01-18','13:21:05','ali mohammed','','2022-01-18 13:21:05');
INSERT INTO `historique_services` VALUES ('361','fd0292000','Echographie Occulaire','12000','Imagerie','0','Kamdem','2022-01-18','13:29:06','Bob Manga','','2022-01-18 13:29:06');
INSERT INTO `historique_services` VALUES ('362','fd0292000','Echographie Pelvienne','7500','Imagerie','0','Kamdem','2022-01-18','13:29:06','Bob Manga','','2022-01-18 13:29:06');
INSERT INTO `historique_services` VALUES ('363','fd0292000','LAB ACE','20000','Laboratoire','0','Kamdem','2022-01-18','13:29:06','Bob Manga','','2022-01-18 13:29:06');
INSERT INTO `historique_services` VALUES ('364','fd0292000','LAB ASLO','4000','Laboratoire','0','Kamdem','2022-01-18','13:29:06','Bob Manga','','2022-01-18 13:29:06');
INSERT INTO `historique_services` VALUES ('365','fd0292000','LAB AMH','48000','Laboratoire','0','Kamdem','2022-01-18','13:29:06','Bob Manga','','2022-01-18 13:29:06');
INSERT INTO `historique_services` VALUES ('366','2c171000','CHR K1','1000','chirurgie','0','Kamdem','2022-01-24','10:44:31','Nolla','','2022-01-24 10:44:31');
INSERT INTO `historique_services` VALUES ('367','d0d128000','LAB Oestradiol','18000','Laboratoire','0','Kamdem','2022-01-24','10:45:04','Alan Kamga','','2022-01-24 10:45:04');
INSERT INTO `historique_services` VALUES ('368','d0d128000','CHR K10','10000','Chirurgie','0','Kamdem','2022-01-24','10:45:04','Alan Kamga','','2022-01-24 10:45:04');
INSERT INTO `historique_services` VALUES ('369','e86216500','RX Hanche (F/P)','15000','Imagerie','0','Kamdem','2022-01-26','03:34:19','Omah ley','','2022-01-26 03:34:19');
INSERT INTO `historique_services` VALUES ('370','e86216500','LAB GE','1000','Laboratoire','0','Kamdem','2022-01-26','03:34:19','Omah ley','','2022-01-26 03:34:19');
INSERT INTO `historique_services` VALUES ('371','f64221500','LAB ACE','20000','Laboratoire','0','Kamdem','2022-01-26','03:40:08','presnel','','2022-01-26 03:40:08');
INSERT INTO `historique_services` VALUES ('372','f64221500','LAB BU','1000','Laboratoire','0','Kamdem','2022-01-26','03:40:08','presnel','','2022-01-26 03:40:08');
INSERT INTO `historique_services` VALUES ('373','c5fe15500','LAB Selle + ATB','14000','Laboratoire','0','Kamdem','2022-01-26','04:18:35','erwin','','2022-01-26 04:18:35');
INSERT INTO `historique_services` VALUES ('374','c5fe15500','MED Soins infirmiers','1000','Medecine','0','Kamdem','2022-01-26','04:18:35','erwin','','2022-01-26 04:18:35');
INSERT INTO `historique_services` VALUES ('375','bc0715500','LAB Selle + ATB','14000','Laboratoire','0','Kamdem','2022-01-26','04:22:04','erwin','','2022-01-26 04:22:04');
INSERT INTO `historique_services` VALUES ('376','bc0715500','MED Soins infirmiers','1000','Medecine','0','Kamdem','2022-01-26','04:22:04','erwin','','2022-01-26 04:22:04');
INSERT INTO `historique_services` VALUES ('377','e01722500','LAB ACE','20000','Laboratoire','0','Kamdem','2022-01-26','05:51:14','erwin','','2022-01-26 05:51:14');
INSERT INTO `historique_services` VALUES ('378','e01722500','LAB GE','1000','Laboratoire','0','Kamdem','2022-01-26','05:51:14','erwin','','2022-01-26 05:51:14');
INSERT INTO `historique_services` VALUES ('379','e01722500','MED Soins infirmiers','1000','Medecine','0','Kamdem','2022-01-26','05:51:14','erwin','','2022-01-26 05:51:14');
INSERT INTO `historique_services` VALUES ('380','b73224000','Echographie Rénale (ou voies urinaires ou arbres urinaires)','12000','Imagerie','0','Kamdem','2022-01-27','20:08:19','BABILLON Christian','','2022-01-27 20:08:19');
INSERT INTO `historique_services` VALUES ('381','b73224000','Echographie Occulaire','12000','Imagerie','0','Kamdem','2022-01-27','20:08:19','BABILLON Christian','','2022-01-27 20:08:19');
INSERT INTO `historique_services` VALUES ('382','fe6930000','Echo Dopper des troncs supraortiques','30000','Imagerie','0','Kamdem','2022-01-27','20:20:51','abel','','2022-01-27 20:20:51');
INSERT INTO `historique_services` VALUES ('383','9e2a34000','LAB AC anti Hbc','13500','Laboratoire','50','Kamdem','2022-01-27','20:22:40','ali mohammed','','2022-01-27 20:22:40');
INSERT INTO `historique_services` VALUES ('384','9e2a34000','LAB D.dimeres','20000','Laboratoire','50','Kamdem','2022-01-27','20:22:40','ali mohammed','','2022-01-27 20:22:40');
INSERT INTO `historique_services` VALUES ('385','58b63000','MED Hospitalisation payant','3000','Medecine','50','Kamdem','2022-01-27','20:24:09','Bob Manga','','2022-01-27 20:24:09');
INSERT INTO `historique_services` VALUES ('386','4adf25000','LAB ACE','20000','Laboratoire','0','Kamdem','2022-01-27','21:06:59','erwin','','2022-01-27 21:06:59');
INSERT INTO `historique_services` VALUES ('387','4adf25000','LAB TPHA/VDRL','4500','Laboratoire','0','Kamdem','2022-01-27','21:06:59','erwin','','2022-01-27 21:06:59');
INSERT INTO `historique_services` VALUES ('388','6b0123500','LAB ACE','20000','Laboratoire','0','Kamdem','2022-01-28','14:40:25','erwin','','2022-01-28 14:40:25');
INSERT INTO `historique_services` VALUES ('389','6b0123500','MED Hospitalisation payant','3000','Medecine','0','Kamdem','2022-01-28','14:40:25','erwin','','2022-01-28 14:40:25');
INSERT INTO `historique_services` VALUES ('390','7dr400','CA Carnet de consultation','400','Carnet','0','Kamdem','2022-01-29','01:28:09','abel','','2022-01-29 01:28:09');
INSERT INTO `historique_services` VALUES ('391','207923600','LAB Magnésium','3600','Laboratoire','0','Kamdem','2022-01-29','14:55:32','baba','','2022-01-29 14:55:32');
INSERT INTO `historique_services` VALUES ('392','207923600','LAB D.dimeres','20000','Laboratoire','0','Kamdem','2022-01-29','14:55:32','baba','','2022-01-29 14:55:32');
INSERT INTO `historique_services` VALUES ('393','8ea53400','CA Carnet de consultation','400','Carnet','0','Kamdem','2022-01-29','15:03:32','bernard nanga','','2022-01-29 15:03:32');
INSERT INTO `historique_services` VALUES ('394','8ea53400','CHR Pose sonde nase-gastrique','3000','Chirurgie','0','Kamdem','2022-01-29','15:03:32','bernard nanga','','2022-01-29 15:03:32');
INSERT INTO `historique_services` VALUES ('395','347b12000','RX Jambe (F/P)','12000','Imagerie','30','Kamdem','2022-01-29','15:04:24','ekedi','','2022-01-29 15:04:24');
INSERT INTO `historique_services` VALUES ('396','tiilech1000','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-01-29','15:15:53','Bob Manga','','2022-01-29 15:15:53');
INSERT INTO `historique_services` VALUES ('397','9lv58pi14000','LAB PCV','2000','Laboratoire','0','Kamdem','2022-01-31','19:27:50','erwin','','2022-01-31 19:27:50');
INSERT INTO `historique_services` VALUES ('398','9lv58pi14000','LAB ECBU + ATB','12000','Laboratoire','0','Kamdem','2022-01-31','19:27:50','erwin','','2022-01-31 19:27:50');
INSERT INTO `historique_services` VALUES ('399','cmlpvue20000','CHR K20','20000','Chirurgie','0','Kamdem','2022-02-04','19:08:36','albar','','2022-02-04 19:08:36');
INSERT INTO `historique_services` VALUES ('400','46d4ko320000','CHR K20','20000','Chirurgie','0','Kamdem','2022-02-04','19:08:59','Alan Kamga','','2022-02-04 19:08:59');
INSERT INTO `historique_services` VALUES ('401','2vs499s25000','CHR K20','20000','Chirurgie','0','Kamdem','2022-02-04','19:11:09','albar','','2022-02-04 19:11:09');
INSERT INTO `historique_services` VALUES ('402','2vs499s25000','','5000','maternité','0','Kamdem','2022-02-04','19:11:09','albar','','2022-02-04 19:11:09');
INSERT INTO `historique_services` VALUES ('403','mi4v900','CA Consultation simple','900','Carnet','0','Kamdem','2022-02-04','19:17:21','Alan Kamga','','2022-02-04 19:17:21');
INSERT INTO `historique_services` VALUES ('404','t1hkl4g21000','LAB ACE','20000','Laboratoire','0','Kamdem','2022-02-05','14:17:29','mbezele','','2022-02-05 14:17:29');
INSERT INTO `historique_services` VALUES ('405','t1hkl4g21000','LAB GE','1000','Laboratoire','0','Kamdem','2022-02-05','14:17:29','mbezele','','2022-02-05 14:17:29');
INSERT INTO `historique_services` VALUES ('406','gc5jdf43400','CA Consultation simple','900','Carnet','50','Kamdem','2022-02-07','20:41:21','albar','','2022-02-07 20:41:21');
INSERT INTO `historique_services` VALUES ('407','gc5jdf43400','CHR Incision','2000','Chirurgie','50','Kamdem','2022-02-07','20:41:21','albar','','2022-02-07 20:41:21');
INSERT INTO `historique_services` VALUES ('408','ol68gpp5000','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-02-10','10:20:22','Alan Kamga','aucune','2022-02-10 10:20:22');
INSERT INTO `historique_services` VALUES ('409','c11nmta2000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-02-10','10:22:27','ali mohammed','aucune','2022-02-10 10:22:27');
INSERT INTO `historique_services` VALUES ('410','4mh9e0a12000','LAB ASLO','4000','Laboratoire','0','Kamdem','2022-02-10','10:24:01','rogers','assuretous','2022-02-10 10:24:01');
INSERT INTO `historique_services` VALUES ('411','4mh9e0a12000','LAB ALAT ASAT','8000','Laboratoire','0','Kamdem','2022-02-10','10:24:01','rogers','assuretous','2022-02-10 10:24:01');
INSERT INTO `historique_services` VALUES ('412','lp3glah2000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-02-10','10:49:01','albar','aucune','2022-02-10 10:49:01');
INSERT INTO `historique_services` VALUES ('413','2igu99r26200','CHR Incision','2000','Chirurgie','0','Kamdem','2022-02-10','10:57:38','ariane','aucune','2022-02-10 10:57:38');
INSERT INTO `historique_services` VALUES ('414','2igu99r26200','LAB BU','1000','Laboratoire','0','Kamdem','2022-02-10','10:57:38','ariane','aucune','2022-02-10 10:57:38');
INSERT INTO `historique_services` VALUES ('415','2igu99r26200','LAB D.dimeres','20000','Laboratoire','0','Kamdem','2022-02-10','10:57:38','ariane','aucune','2022-02-10 10:57:38');
INSERT INTO `historique_services` VALUES ('416','2igu99r26200','LAB Creatinine','2700','Laboratoire','0','Kamdem','2022-02-10','10:57:38','ariane','aucune','2022-02-10 10:57:38');
INSERT INTO `historique_services` VALUES ('417','otcd0c51900','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-02-16','02:00:41','bernard nanga','aucune','2022-02-16 02:00:41');
INSERT INTO `historique_services` VALUES ('418','otcd0c51900','CA Consultation simple','900','Carnet','0','Kamdem','2022-02-16','02:00:41','bernard nanga','aucune','2022-02-16 02:00:41');
INSERT INTO `historique_services` VALUES ('419','jlf43ld1000','CA Carnet de consultation','400','Carnet','0','Kamdem','2022-02-21','16:00:52','Alan Kamga','aucune','2022-02-21 16:00:52');
INSERT INTO `historique_services` VALUES ('420','jlf43ld1000','CA Consultation simple','600','Carnet','0','Kamdem','2022-02-21','16:00:52','Alan Kamga','aucune','2022-02-21 16:00:52');
INSERT INTO `historique_services` VALUES ('421','kir1fcf1000','UPEC Crachats','1000','Upec','0','Kamdem','2022-02-21','16:01:17','Bob Manga','aucune','2022-02-21 16:01:17');
INSERT INTO `historique_services` VALUES ('422','49a9cs24600','LAB Calcium','3600','Laboratoire','0','er','2022-02-21','16:01:58','boba','aucune','2022-02-21 16:01:58');
INSERT INTO `historique_services` VALUES ('423','49a9cs24600','UPEC Crachats','1000','Upec','0','er','2022-02-21','16:01:58','boba','aucune','2022-02-21 16:01:58');
INSERT INTO `historique_services` VALUES ('424','i8cquql5000','LAB ACHVC','4500','Laboratoire','0','Kamdem','2022-02-21','18:19:08','BABILLON Christian','aucune','2022-02-21 18:19:08');
INSERT INTO `historique_services` VALUES ('425','dto2l5s14000','LAB AC anti Hbs','13500','Laboratoire','0','Kamdem','2022-02-21','18:57:53','erwin','Ascoma','2022-02-21 18:57:53');
INSERT INTO `historique_services` VALUES ('426','timag8s10000','CHR K10','10000','Chirurgie','50','Kamdem','2022-02-21','19:01:09','albar','aucune','2022-02-21 19:01:09');
INSERT INTO `historique_services` VALUES ('427','130iu5h10000','CHR K10','10000','Chirurgie','0','Kamdem','2022-02-21','19:16:46','Alan Kamga','aucune','2022-02-21 19:16:46');
INSERT INTO `historique_services` VALUES ('428','268bvqv8500','LAB ALAT ASAT','8000','Laboratoire','0','er','2022-02-21','19:30:24','bernard nanga','aucune','2022-02-21 19:30:24');
INSERT INTO `historique_services` VALUES ('429','o32030h900','CA Consultation simple','900','Carnet','0','Kamdem','2022-02-21','19:46:16','ali mohammed','aucune','2022-02-21 19:46:16');
INSERT INTO `historique_services` VALUES ('430','2jlhjcf1000','CHR K1','1000','chirurgie','0','Kamdem','2022-02-21','19:47:12','abel','aucune','2022-02-21 19:47:12');
INSERT INTO `historique_services` VALUES ('431','vs8gtqv14500','LAB Spermogramme','14000','Laboratoire','0','Kamdem','2022-02-28','18:03:06','rogers','assuretous','2022-02-28 18:03:06');
INSERT INTO `historique_services` VALUES ('432','d4qse8030000','Echo Mammographie','30000','Imagerie','0','Kamdem','2022-02-28','18:03:27','ali mohammed','aucune','2022-02-28 18:03:27');
INSERT INTO `historique_services` VALUES ('433','e4os7jh48000','LAB AMH','48000','Laboratoire','0','Kamdem','2022-02-28','18:04:05','alea','aucune','2022-02-28 18:04:05');
INSERT INTO `historique_services` VALUES ('434','6ptbgn78000','LAB Chlamydia','8000','Laboratoire','0','Kamdem','2022-02-28','18:06:32','baba','assuretous','2022-02-28 18:06:32');
INSERT INTO `historique_services` VALUES ('435','bf9n0e91000','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-02-28','18:07:17','baba','assuretous','2022-02-28 18:07:17');
INSERT INTO `historique_services` VALUES ('436','ja033ri5000','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-02-28','18:07:45','ariane','aucune','2022-02-28 18:07:45');
INSERT INTO `historique_services` VALUES ('437','rjb8ceo900','CA Consultation simple','900','Carnet','0','Kamdem','2022-02-28','18:12:27','ariane','aucune','2022-02-28 18:12:27');
INSERT INTO `historique_services` VALUES ('438','3tbqf6b10000','CHR K10','10000','Chirurgie','0','Kamdem','2022-02-28','20:43:24','baba','assuretous','2022-02-28 20:43:24');
INSERT INTO `historique_services` VALUES ('439','u77v11c1000','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-03-02','11:16:06','ndo jamal','aucune','2022-03-02 11:16:06');
INSERT INTO `historique_services` VALUES ('440','sahanqn1000','CHR K1','1000','chirurgie','0','Kamdem','2022-03-02','11:17:08','alfred','aucune','2022-03-02 11:17:08');
INSERT INTO `historique_services` VALUES ('441','jq71o2h2000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-03-02','15:40:38','ali mohammed','aucune','2022-03-02 15:40:38');
INSERT INTO `historique_services` VALUES ('442','vvrrioj8000','LAB ALAT ASAT','8000','Laboratoire','0','Kamdem','2022-03-02','15:44:59','ross','aucune','2022-03-02 15:44:59');
INSERT INTO `historique_services` VALUES ('443','00st1gk5500','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-03-02','15:47:46','alfred','aucune','2022-03-02 15:47:46');
INSERT INTO `historique_services` VALUES ('444','do9la8t2500','LAB Groupe sanguin (GS RH)','2000','Laboratoire','0','Kamdem','2022-03-02','15:52:33','erwin','Ascoma','2022-03-02 15:52:33');
INSERT INTO `historique_services` VALUES ('445','j7kfbrs1500','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-03-02','16:03:15','alea','aucune','2022-03-02 16:03:15');
INSERT INTO `historique_services` VALUES ('446','skv4jhs3000','CHR K1','1000','chirurgie','0','Kamdem','2022-03-02','21:53:24','ariane','aucune','2022-03-02 21:53:24');
INSERT INTO `historique_services` VALUES ('447','skv4jhs3000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-03-02','21:53:24','ariane','aucune','2022-03-02 21:53:24');
INSERT INTO `historique_services` VALUES ('448','dicls4d400','CA Carnet de consultation','400','Carnet','0','Kamdem','2022-03-02','21:55:51','alea','aucune','2022-03-02 21:55:51');
INSERT INTO `historique_services` VALUES ('449','f7dntcq45000','Echographie parties molles','10000','Imagerie','0','Kamdem','2022-03-20','20:28:16','Alan Kamga','aucune','2022-03-20 20:28:16');
INSERT INTO `historique_services` VALUES ('450','f7dntcq45000','Echo Dopper Artériel des membres','35000','imagerie','0','Kamdem','2022-03-20','20:28:16','Alan Kamga','aucune','2022-03-20 20:28:16');
INSERT INTO `historique_services` VALUES ('451','n6b5vrm42000','Echographie Occulaire','12000','Imagerie','0','Kamdem','2022-03-20','20:28:32','alea','aucune','2022-03-20 20:28:32');
INSERT INTO `historique_services` VALUES ('452','n6b5vrm42000','Echo Mammographie','30000','Imagerie','0','Kamdem','2022-03-20','20:28:32','alea','aucune','2022-03-20 20:28:32');
INSERT INTO `historique_services` VALUES ('453','jph3hf240500','Echo Mammographie','30000','Imagerie','0','Kamdem','2022-03-20','20:29:28','ali mohammed','aucune','2022-03-20 20:29:28');
INSERT INTO `historique_services` VALUES ('454','jph3hf240500','Echographie parties molles','10000','Imagerie','0','Kamdem','2022-03-20','20:29:28','ali mohammed','aucune','2022-03-20 20:29:28');
INSERT INTO `historique_services` VALUES ('455','8258djn40500','Echo Mammographie','30000','Imagerie','0','Kamdem','2022-03-20','20:30:25','erwin','Ascoma','2022-03-20 20:30:25');
INSERT INTO `historique_services` VALUES ('456','8258djn40500','Echographie parties molles','10000','Imagerie','0','Kamdem','2022-03-20','20:30:25','erwin','Ascoma','2022-03-20 20:30:25');
INSERT INTO `historique_services` VALUES ('457','a0tfc352000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-03-25','04:52:56','abel','aucune','2022-03-25 04:52:56');
INSERT INTO `historique_services` VALUES ('458','g00rh0e4500','LAB ASLO','4000','Laboratoire','0','Kamdem','2022-03-25','04:53:48','ali mohammed','aucune','2022-03-25 04:53:48');
INSERT INTO `historique_services` VALUES ('459','hhsnle45000','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-03-25','05:08:23','erwin','Ascoma','2022-03-25 05:08:23');
INSERT INTO `historique_services` VALUES ('460','ni5h2of18000','LAB LH','18000','Laboratoire','0','Kamdem','2022-03-25','05:10:45','erwin','Ascoma','2022-03-25 05:10:45');
INSERT INTO `historique_services` VALUES ('461','k6ifm8l2500','LAB PU','2000','Laboratoire','0','Kamdem','2022-03-25','05:11:19','erwin','Ascoma','2022-03-25 05:11:19');
INSERT INTO `historique_services` VALUES ('462','jpdhi1n5000','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-03-25','05:37:00','rogers','assuretous','2022-03-25 05:37:00');
INSERT INTO `historique_services` VALUES ('463','fvlh9015000','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-03-25','05:37:38','erwin','Ascoma','2022-03-25 05:37:38');
INSERT INTO `historique_services` VALUES ('464','dajtm5h1500','CHR K1','1000','chirurgie','0','Kamdem','2022-03-25','05:38:03','erwin','Ascoma','2022-03-25 05:38:03');
INSERT INTO `historique_services` VALUES ('465','926v1hl2000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-03-27','12:00:16','erwin','Ascoma','2022-03-27 12:00:16');
INSERT INTO `historique_services` VALUES ('466','20dv1vs25000','Echo Dopper Testiculaire','25000','Imagerie','0','Kamdem','2022-03-27','12:00:29','abel','aucune','2022-03-27 12:00:29');
INSERT INTO `historique_services` VALUES ('467','2f1emn12000','CHR K1','1000','chirurgie','0','Kamdem','2022-05-06','18:46:29','Omah ley','aucune','2022-05-06 18:46:29');
INSERT INTO `historique_services` VALUES ('468','2f1emn12000','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-05-06','18:46:29','Omah ley','aucune','2022-05-06 18:46:29');
INSERT INTO `historique_services` VALUES ('469','tebmduj7800','MED Soins infirmiers','1000','Medecine','0','Kamdem','2022-05-06','18:47:30','albar','aucune','2022-05-06 18:47:30');
INSERT INTO `historique_services` VALUES ('470','tebmduj7800','LAB NFS','6300','Laboratoire','0','Kamdem','2022-05-06','18:47:30','albar','aucune','2022-05-06 18:47:30');
INSERT INTO `historique_services` VALUES ('471','5v3ndvp1000','CHR K1','1000','chirurgie','50','Kamdem','2022-05-21','14:14:47','Alan Kamga','aucune','2022-05-21 14:14:47');
INSERT INTO `historique_services` VALUES ('472','cqlf1ed2000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-05-21','14:15:00','albar','aucune','2022-05-21 14:15:00');
INSERT INTO `historique_services` VALUES ('473','71tn7sr3500','CHR Incision','2000','Chirurgie','30','Kamdem','2022-07-12','19:05:26','Alan Kamga','aucune','2022-07-12 19:05:26');
INSERT INTO `historique_services` VALUES ('474','71tn7sr3500','CA Carnet pédiatrie','1000','Carnet','30','Kamdem','2022-07-12','19:05:26','Alan Kamga','aucune','2022-07-12 19:05:26');
INSERT INTO `historique_services` VALUES ('475','lg10hgt6400','CA Consultation simple','900','Carnet','0','Kamdem','2022-07-12','19:08:40','erwin','Ascoma','2022-07-12 19:08:40');
INSERT INTO `historique_services` VALUES ('476','lg10hgt6400','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-07-12','19:08:40','erwin','Ascoma','2022-07-12 19:08:40');
INSERT INTO `historique_services` VALUES ('477','qdu7c312000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-07-12','19:16:03','Alan Kamga','aucune','2022-07-12 19:16:03');
INSERT INTO `historique_services` VALUES ('478','8v5iuen400','CA Carnet de consultation','400','Carnet','0','Kamdem','2022-07-19','13:08:11','albar','aucune','2022-07-19 13:08:11');
INSERT INTO `historique_services` VALUES ('479','lbj2au61000','CHR K1','1000','chirurgie','0','Kamdem','2022-07-19','13:34:19','alfred','aucune','2022-07-19 13:34:19');
INSERT INTO `historique_services` VALUES ('484','uus92ld1500','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-08-06','12:40:01','albar','aucune','2022-08-06 12:40:01');
INSERT INTO `historique_services` VALUES ('485','g9tk1hi900','CA Carnet de consultation','400','Carnet','0','Kamdem','2022-08-06','12:42:54','alea','aucune','2022-08-06 12:42:54');
INSERT INTO `historique_services` VALUES ('486','jfrqk2j5500','CHR Circoncision','5000','Chirurgie','0','Kamdem','2022-08-06','12:47:57','ali mohammed','aucune','2022-08-06 12:47:57');
INSERT INTO `historique_services` VALUES ('487','2ihqg6i1500','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-08-06','12:50:23','Alan Kamga','aucune','2022-08-06 12:50:23');
INSERT INTO `historique_services` VALUES ('488','8q5234t11500','CHR K1','1000','chirurgie','0','Kamdem','2022-08-06','12:50:53','ariane','aucune','2022-08-06 12:50:53');
INSERT INTO `historique_services` VALUES ('489','8q5234t11500','CHR K10','10000','Chirurgie','0','Kamdem','2022-08-06','12:50:53','ariane','aucune','2022-08-06 12:50:53');
INSERT INTO `historique_services` VALUES ('490','i9per0518000','LAB Dosage HCV','18000','Laboratoire','0','Kamdem','2022-08-06','12:51:27','albar','aucune','2022-08-06 12:51:27');
INSERT INTO `historique_services` VALUES ('491','n1thjdu2000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-09-18','22:29:42','albar','aucune','2022-09-18 22:29:42');
INSERT INTO `historique_services` VALUES ('492','pl2tkv52000','CHR Incision','2000','Chirurgie','0','Kamdem','2022-09-18','22:34:26','ali mohammed','aucune','2022-09-18 22:34:26');
INSERT INTO `historique_services` VALUES ('493','h7606qu1000','CA Carnet pédiatrie','1000','Carnet','0','Kamdem','2022-09-18','22:36:17','alfred','aucune','2022-09-18 22:36:17');


DROP TABLE IF EXISTS `id_facture_assure`;
CREATE TABLE `id_facture_assure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_general` varchar(255) NOT NULL,
  `id_facture` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4;

INSERT INTO `id_facture_assure` VALUES ('1','0','59e1');
INSERT INTO `id_facture_assure` VALUES ('30','0','c2c1');
INSERT INTO `id_facture_assure` VALUES ('32','ps1','d2b4');
INSERT INTO `id_facture_assure` VALUES ('33','9ne','1c53');
INSERT INTO `id_facture_assure` VALUES ('34','9ne','4c4b');
INSERT INTO `id_facture_assure` VALUES ('35','9ne','c804');
INSERT INTO `id_facture_assure` VALUES ('36','9ne','3db2');
INSERT INTO `id_facture_assure` VALUES ('37','gqods2v','f6d6');
INSERT INTO `id_facture_assure` VALUES ('38','gqods2v','0de6');
INSERT INTO `id_facture_assure` VALUES ('39','gqods2v','c0db');
INSERT INTO `id_facture_assure` VALUES ('40','gqods2v','20c7');
INSERT INTO `id_facture_assure` VALUES ('41','gqods2v','e2c0');
INSERT INTO `id_facture_assure` VALUES ('42','ohe5voi','1841');
INSERT INTO `id_facture_assure` VALUES ('43','ohe5voi','1468');
INSERT INTO `id_facture_assure` VALUES ('44','r77ka32','d9e3');
INSERT INTO `id_facture_assure` VALUES ('45','r77ka32','c4ff');
INSERT INTO `id_facture_assure` VALUES ('46','lgma68k','0cab750');
INSERT INTO `id_facture_assure` VALUES ('47','j19nplq','bc0715500');
INSERT INTO `id_facture_assure` VALUES ('48','j19nplq','d768200');
INSERT INTO `id_facture_assure` VALUES ('49','j19nplq','0f693400');
INSERT INTO `id_facture_assure` VALUES ('50','kdiacdv','f64221500');
INSERT INTO `id_facture_assure` VALUES ('51','kdiacdv','b3911600');
INSERT INTO `id_facture_assure` VALUES ('52','htafe9u','35de1250');
INSERT INTO `id_facture_assure` VALUES ('53','htafe9u','159d750');
INSERT INTO `id_facture_assure` VALUES ('54','qb800en','207923600');
INSERT INTO `id_facture_assure` VALUES ('55','qb800en','72637700');
INSERT INTO `id_facture_assure` VALUES ('56','qb800en','995c250');
INSERT INTO `id_facture_assure` VALUES ('57','qb800en','b195650');
INSERT INTO `id_facture_assure` VALUES ('58','v9be8se','e01722500');
INSERT INTO `id_facture_assure` VALUES ('59','v9be8se','6b0123500');
INSERT INTO `id_facture_assure` VALUES ('60','v9be8se','6e21100');
INSERT INTO `id_facture_assure` VALUES ('61','v9be8se','4adf25000');
INSERT INTO `id_facture_assure` VALUES ('62','v9be8se','c2471000');
INSERT INTO `id_facture_assure` VALUES ('63','v9be8se','43e71100');
INSERT INTO `id_facture_assure` VALUES ('64','v9be8se','e07c450');
INSERT INTO `id_facture_assure` VALUES ('65','vdhsaki','vs8gtqv14500');
INSERT INTO `id_facture_assure` VALUES ('66','7sl2fgh','hhsnle45000');
INSERT INTO `id_facture_assure` VALUES ('67','7sl2fgh','k6ifm8l2500');
INSERT INTO `id_facture_assure` VALUES ('68','7sl2fgh','fvlh9015000');
INSERT INTO `id_facture_assure` VALUES ('69','7sl2fgh','ni5h2of18000');
INSERT INTO `id_facture_assure` VALUES ('70','7sl2fgh','dajtm5h1500');
INSERT INTO `id_facture_assure` VALUES ('71','7sl2fgh','0657d847e31800');
INSERT INTO `id_facture_assure` VALUES ('72','7sl2fgh','a67671eec34000');
INSERT INTO `id_facture_assure` VALUES ('73','af8d42a','5053ee34de700');
INSERT INTO `id_facture_assure` VALUES ('74','af8d42a','f52974eee22000');


DROP TABLE IF EXISTS `infos_approvisionnement`;
CREATE TABLE `infos_approvisionnement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_commande` varchar(255) NOT NULL,
  `fournisseur` varchar(255) NOT NULL,
  `vendeur` varchar(255) NOT NULL,
  `montant` int(11) NOT NULL,
  `date_commande` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;

INSERT INTO `infos_approvisionnement` VALUES ('15','05aa850000','B','Dr Obam','850000','2021-08-28 14:26:54');
INSERT INTO `infos_approvisionnement` VALUES ('16','061a452611','A','Dr Obam','452611','2021-08-31 13:50:48');
INSERT INTO `infos_approvisionnement` VALUES ('17','0cdd25000','A','Dr Obam','25000','2021-09-18 00:50:48');
INSERT INTO `infos_approvisionnement` VALUES ('18','fff350000','B','Dr Obam','50000','2021-10-10 19:10:54');
INSERT INTO `infos_approvisionnement` VALUES ('19','c1aa50000','B','ABC','50000','2021-10-11 08:51:33');
INSERT INTO `infos_approvisionnement` VALUES ('20','7f7250000','B','ABC','50000','2021-10-11 12:18:42');
INSERT INTO `infos_approvisionnement` VALUES ('21','5657500','A','ABC','500','2021-11-14 18:32:16');
INSERT INTO `infos_approvisionnement` VALUES ('22','977f5000','A','ABC','5000','2021-11-19 07:24:39');
INSERT INTO `infos_approvisionnement` VALUES ('23','447e5000','A','ABC','5000','2021-11-19 07:33:56');
INSERT INTO `infos_approvisionnement` VALUES ('24','acbb50000','A','ABC','50000','2021-11-19 17:34:30');
INSERT INTO `infos_approvisionnement` VALUES ('25','59aa50000','A','ABC','50000','2021-11-19 17:39:25');
INSERT INTO `infos_approvisionnement` VALUES ('26','eda050000','A','ABC','50000','2021-11-19 17:41:15');
INSERT INTO `infos_approvisionnement` VALUES ('27','c41c1000','AUCUN','ABC','1000','2021-11-24 20:14:53');
INSERT INTO `infos_approvisionnement` VALUES ('28','12d8100','AUCUN','ABC','100','2021-11-24 20:20:10');
INSERT INTO `infos_approvisionnement` VALUES ('29','a8b4110','AUCUN','Dr Obam','110','2021-12-05 11:09:26');
INSERT INTO `infos_approvisionnement` VALUES ('30','6e36110','AUCUN','Dr Obam','110','2021-12-05 11:10:09');
INSERT INTO `infos_approvisionnement` VALUES ('31','cce65422','AUCUN','ABC','5422','2022-02-16 02:11:49');
INSERT INTO `infos_approvisionnement` VALUES ('32','58254500','AUCUN','ABC','4500','2022-10-09 13:29:55');
INSERT INTO `infos_approvisionnement` VALUES ('33','3d1f1','AUCUN','ABC','1','2022-10-09 13:40:48');
INSERT INTO `infos_approvisionnement` VALUES ('34','1059123','AUCUN','ABC','123','2022-10-09 14:55:30');
INSERT INTO `infos_approvisionnement` VALUES ('35','6953123','AUCUN','ABC','123','2022-10-09 14:57:20');
INSERT INTO `infos_approvisionnement` VALUES ('36','5d1a23ed','AUCUN','ABC','23','2022-10-09 15:15:00');


DROP TABLE IF EXISTS `medicaments`;
CREATE TABLE `medicaments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL DEFAULT 'non défini',
  `designation` varchar(255) NOT NULL,
  `categorie` varchar(100) NOT NULL DEFAULT 'non défini',
  `genre` varchar(255) NOT NULL,
  `pu_vente` int(11) NOT NULL,
  `pu_achat` int(11) NOT NULL,
  `conditionnement` text NOT NULL,
  `en_stock` int(11) NOT NULL,
  `min_rec` int(11) NOT NULL DEFAULT 0,
  `date_peremption` varchar(255) NOT NULL DEFAULT 'non défini',
  `date_approv` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=688 DEFAULT CHARSET=utf8mb4;

INSERT INTO `medicaments` VALUES ('344','MASL','metronidazol',' ','','250','100',' ','735','150','08-25','2021-09-18 00:46:22');
INSERT INTO `medicaments` VALUES ('346','AMAK','eferalgan','comprimé efervescent','','100','50','plaquette de 10','70','130','02-23','2021-09-18 00:46:22');
INSERT INTO `medicaments` VALUES ('348','KASL','amoxi','comprimé','','200','50','B/20','799','50','12-24/05-25','2021-09-18 00:46:22');
INSERT INTO `medicaments` VALUES ('349','KAAA','paracétamol','comprimé','','100','45','plaquette de 10','744','50','10-25','2021-09-18 00:46:22');
INSERT INTO `medicaments` VALUES ('350','MAAS','minoxidil 300ml','','','7500','5000','paquet de 10 tubes','778','80','02-23','2021-09-18 00:46:22');
INSERT INTO `medicaments` VALUES ('415','ZMOS','arthemeter','comprimé','','1500','900','plaquette de 6','690','80','02-25','2021-10-10 19:10:54');
INSERT INTO `medicaments` VALUES ('418','MASL','ibuprofene',' cp','sp','150','100',' ','249','150','03-24','2021-10-11 08:51:33');
INSERT INTO `medicaments` VALUES ('420','KASL','amoxiciline','comprimé','','250','50','B/10','526','100','12-24/02-25','2021-10-11 12:18:42');
INSERT INTO `medicaments` VALUES ('676','','sayana press','','','500','0','B/1','710','0','','2021-11-14 18:32:16');
INSERT INTO `medicaments` VALUES ('677','','perfuseur','','','250','0','B/1','433','0','','2021-11-14 18:32:16');
INSERT INTO `medicaments` VALUES ('678','','transfuseur','','','500','0','B/1','878','0','','2021-11-14 18:32:16');
INSERT INTO `medicaments` VALUES ('681','','litacol','cp','','250','0','B/4','10','100','','2021-12-02 17:44:16');
INSERT INTO `medicaments` VALUES ('682','','bbb','c','generique','150','0','','0','0','','2021-12-05 11:04:59');
INSERT INTO `medicaments` VALUES ('683','','ccc','c','sp','100','0','','9','10','','2021-12-05 11:05:29');
INSERT INTO `medicaments` VALUES ('684','','artefan','','generique','1700','0','b/6','10','10','','2022-02-05 14:57:32');
INSERT INTO `medicaments` VALUES ('685','','cofantrine','cp','generique','1500','0','b/6','10','0','','2022-02-16 02:12:32');
INSERT INTO `medicaments` VALUES ('686','','malacur','cp','sp','1000','0','p/6','23','10','','2022-10-09 14:56:54');


DROP TABLE IF EXISTS `patients`;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` text NOT NULL,
  `assurance` varchar(200) NOT NULL,
  `type_assurance` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4;

INSERT INTO `patients` VALUES ('1','Alan Kamga','aucune','0');
INSERT INTO `patients` VALUES ('2','Richard Kenfack','aucune','0');
INSERT INTO `patients` VALUES ('3','Bob Manga','aucune','0');
INSERT INTO `patients` VALUES ('4','ali mohammed','aucune','0');
INSERT INTO `patients` VALUES ('5','Nolla','aucune','0');
INSERT INTO `patients` VALUES ('6','abel','aucune','0');
INSERT INTO `patients` VALUES ('7','masse','aucune','0');
INSERT INTO `patients` VALUES ('8','ekedi','aucune','0');
INSERT INTO `patients` VALUES ('9','mbezele','aucune','0');
INSERT INTO `patients` VALUES ('10','kengne marie','aucune','0');
INSERT INTO `patients` VALUES ('11','BABILLON Christian','aucune','0');
INSERT INTO `patients` VALUES ('12','NOLLA Jules Roland','aucune','0');
INSERT INTO `patients` VALUES ('13','ross','aucune','0');
INSERT INTO `patients` VALUES ('14','ariane','aucune','0');
INSERT INTO `patients` VALUES ('15','bernard nanga','aucune','0');
INSERT INTO `patients` VALUES ('16','Omah ley','aucune','0');
INSERT INTO `patients` VALUES ('17','alea','aucune','0');
INSERT INTO `patients` VALUES ('18','rogers','assuretous','80');
INSERT INTO `patients` VALUES ('20','hhb hk','aucune','0');
INSERT INTO `patients` VALUES ('21','boba','aucune','0');
INSERT INTO `patients` VALUES ('22','albar','aucune','0');
INSERT INTO `patients` VALUES ('23','rod','aucune','0');
INSERT INTO `patients` VALUES ('24','baba','assuretous','100');
INSERT INTO `patients` VALUES ('26','presnel','assuretous','90');
INSERT INTO `patients` VALUES ('27','erwin','Ascoma','80');
INSERT INTO `patients` VALUES ('28','ndo jamal','aucune','0');
INSERT INTO `patients` VALUES ('29','alfred','aucune','0');
INSERT INTO `patients` VALUES ('30','emilie','aucune','0');
INSERT INTO `patients` VALUES ('31','rodin','aucune','0');


DROP TABLE IF EXISTS `recettes`;
CREATE TABLE `recettes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `montant` int(11) NOT NULL,
  `date_versement` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `recettes_caisse`;
CREATE TABLE `recettes_caisse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `montant` int(11) NOT NULL,
  `date_versement` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `recettes_caisse` VALUES ('1','Dr Obam','192785','2021-08-19 10:31:45');


DROP TABLE IF EXISTS `recettes_enregistres`;
CREATE TABLE `recettes_enregistres` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_recette` varchar(255) NOT NULL,
  `recette_total` int(11) NOT NULL,
  `generalite` int(11) NOT NULL,
  `montant_retire` int(11) NOT NULL,
  `recette_restante` int(11) NOT NULL,
  `caissier` varchar(255) NOT NULL,
  `regisseur` varchar(255) NOT NULL,
  `date_heure` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `recettes_enregistres` VALUES ('1','867638900','38900','9000','18000','20900','Kamdem','Mr Nola','2021-09-10 21:35:36');
INSERT INTO `recettes_enregistres` VALUES ('4','5b5645000','45000','9250','25000','20000','Kamdem','Mr Nola','2021-09-11 15:42:35');
INSERT INTO `recettes_enregistres` VALUES ('5','d7de33000','33000','4500','6750','26250','Kamdem','Mr Nola','2021-09-23 09:50:16');
INSERT INTO `recettes_enregistres` VALUES ('6','1b40144000','144000','0','56000','88000','Kamdem','Mr Nola','2021-10-04 01:59:21');
INSERT INTO `recettes_enregistres` VALUES ('7','5402128000','128000','0','46100','81900','Kamdem','Mr Nola','2021-10-06 12:49:16');
INSERT INTO `recettes_enregistres` VALUES ('8','f7d84600','4600','0','400','4200','Kamdem','Mr Nola','2021-11-14 05:47:23');
INSERT INTO `recettes_enregistres` VALUES ('11','11bb4600','4600','0','0','4600','er','Mr Nola','2022-02-21 16:54:37');


DROP TABLE IF EXISTS `services`;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` text NOT NULL,
  `prix` int(11) NOT NULL,
  `categorie` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8mb4;

INSERT INTO `services` VALUES ('1','CHR K1','1000','chirurgie');
INSERT INTO `services` VALUES ('2','CHR K2','2000','Chirurgie');
INSERT INTO `services` VALUES ('3','CHR K3','3000','Chirurgie');
INSERT INTO `services` VALUES ('4','CHR K4','4000','Chirurgie');
INSERT INTO `services` VALUES ('5','CHR K5','5000','Chirurgie');
INSERT INTO `services` VALUES ('6','CHR K6','6000','Chirurgie');
INSERT INTO `services` VALUES ('7','CHR K7','7000','Chirurgie');
INSERT INTO `services` VALUES ('8','CHR K8','8000','Chirurgie');
INSERT INTO `services` VALUES ('9','CHR K9','9000','Chirurgie');
INSERT INTO `services` VALUES ('10','CHR K10','10000','Chirurgie');
INSERT INTO `services` VALUES ('11','CHR K11','11000','Chirurgie');
INSERT INTO `services` VALUES ('12','CHR K12','12000','Chirurgie');
INSERT INTO `services` VALUES ('13','CHR K13','13000','Chirurgie');
INSERT INTO `services` VALUES ('14','CHR K14','14000','Chirurgie');
INSERT INTO `services` VALUES ('15','CHR K15','15000','Chirurgie');
INSERT INTO `services` VALUES ('16','CHR K16','16000','Chirurgie');
INSERT INTO `services` VALUES ('17','CHR K17','17000','Chirurgie');
INSERT INTO `services` VALUES ('18','CHR K18','18000','Chirurgie');
INSERT INTO `services` VALUES ('19','CHR K19','19000','Chirurgie');
INSERT INTO `services` VALUES ('20','CHR K20','20000','Chirurgie');
INSERT INTO `services` VALUES ('21','CHR K21','21000','Chirurgie');
INSERT INTO `services` VALUES ('22','CHR K22','22000','Chirurgie');
INSERT INTO `services` VALUES ('23','CHR K23','23000','Chirurgie');
INSERT INTO `services` VALUES ('24','CHR K24','24000','Chirurgie');
INSERT INTO `services` VALUES ('25','CHR K25','25000','Chirurgie');
INSERT INTO `services` VALUES ('26','CHR K26','26000','Chirurgie');
INSERT INTO `services` VALUES ('27','CHR K27','27000','Chirurgie');
INSERT INTO `services` VALUES ('28','CHR K28','28000','Chirurgie');
INSERT INTO `services` VALUES ('29','CHR K29','29000','Chirurgie');
INSERT INTO `services` VALUES ('30','CHR K30','30000','Chirurgie');
INSERT INTO `services` VALUES ('31','CHR K31','31000','Chirurgie');
INSERT INTO `services` VALUES ('32','CHR K32','32000','Chirurgie');
INSERT INTO `services` VALUES ('33','CHR K33','33000','Chirurgie');
INSERT INTO `services` VALUES ('34','CHR K34','34000','Chirurgie');
INSERT INTO `services` VALUES ('35','CHR K35','35000','Chirurgie');
INSERT INTO `services` VALUES ('36','CHR K36','36000','Chirurgie');
INSERT INTO `services` VALUES ('37','CHR K37','37000','Chirurgie');
INSERT INTO `services` VALUES ('38','CHR K38','38000','Chirurgie');
INSERT INTO `services` VALUES ('39','CHR K39','39000','Chirurgie');
INSERT INTO `services` VALUES ('40','CHR K40','40000','Chirurgie');
INSERT INTO `services` VALUES ('41','CHR K41','41000','Chirurgie');
INSERT INTO `services` VALUES ('42','CHR K42','42000','Chirurgie');
INSERT INTO `services` VALUES ('43','CHR K43','43000','Chirurgie');
INSERT INTO `services` VALUES ('44','CHR K44','44000','Chirurgie');
INSERT INTO `services` VALUES ('45','CHR K45','45000','Chirurgie');
INSERT INTO `services` VALUES ('46','CHR K46','46000','Chirurgie');
INSERT INTO `services` VALUES ('47','CHR K47','47000','Chirurgie');
INSERT INTO `services` VALUES ('48','CHR K48','48000','Chirurgie');
INSERT INTO `services` VALUES ('49','CHR K49','49000','Chirurgie');
INSERT INTO `services` VALUES ('50','CHR K50','50000','Chirurgie');
INSERT INTO `services` VALUES ('51','CHR K51','51000','Chirurgie');
INSERT INTO `services` VALUES ('52','CHR K52','52000','Chirurgie');
INSERT INTO `services` VALUES ('53','CHR K53','53000','Chirurgie');
INSERT INTO `services` VALUES ('54','CHR K54','54000','Chirurgie');
INSERT INTO `services` VALUES ('55','CHR K55','55000','Chirurgie');
INSERT INTO `services` VALUES ('56','CHR K56','56000','Chirurgie');
INSERT INTO `services` VALUES ('57','CHR K57','57000','Chirurgie');
INSERT INTO `services` VALUES ('58','CHR K58','58000','Chirurgie');
INSERT INTO `services` VALUES ('59','CHR K59','59000','Chirurgie');
INSERT INTO `services` VALUES ('60','CHR K60','60000','Chirurgie');
INSERT INTO `services` VALUES ('61','CHR K61','61000','Chirurgie');
INSERT INTO `services` VALUES ('62','CHR K62','62000','Chirurgie');
INSERT INTO `services` VALUES ('63','CHR K63','63000','Chirurgie');
INSERT INTO `services` VALUES ('64','CHR K64','64000','Chirurgie');
INSERT INTO `services` VALUES ('65','CHR K65','65000','Chirurgie');
INSERT INTO `services` VALUES ('66','CHR K66','66000','Chirurgie');
INSERT INTO `services` VALUES ('67','CHR K67','67000','Chirurgie');
INSERT INTO `services` VALUES ('68','CHR K68','68000','Chirurgie');
INSERT INTO `services` VALUES ('69','CHR K69','69000','Chirurgie');
INSERT INTO `services` VALUES ('70','CHR K70','70000','Chirurgie');
INSERT INTO `services` VALUES ('71','CHR K71','71000','Chirurgie');
INSERT INTO `services` VALUES ('72','CHR K72','72000','Chirurgie');
INSERT INTO `services` VALUES ('73','CHR K73','73000','Chirurgie');
INSERT INTO `services` VALUES ('74','CHR K74','74000','Chirurgie');
INSERT INTO `services` VALUES ('75','CHR K75','75000','Chirurgie');
INSERT INTO `services` VALUES ('76','CHR K76','76000','Chirurgie');
INSERT INTO `services` VALUES ('77','CHR K77','77000','Chirurgie');
INSERT INTO `services` VALUES ('78','CHR K78','78000','Chirurgie');
INSERT INTO `services` VALUES ('79','CHR K79','79000','Chirurgie');
INSERT INTO `services` VALUES ('80','CHR K80','80000','Chirurgie');
INSERT INTO `services` VALUES ('81','CHR K81','81000','Chirurgie');
INSERT INTO `services` VALUES ('82','CHR K82','82000','Chirurgie');
INSERT INTO `services` VALUES ('83','CHR K83','83000','Chirurgie');
INSERT INTO `services` VALUES ('84','CHR K84','84000','Chirurgie');
INSERT INTO `services` VALUES ('85','CHR K85','85000','Chirurgie');
INSERT INTO `services` VALUES ('86','CHR K86','86000','Chirurgie');
INSERT INTO `services` VALUES ('87','CHR K87','87000','Chirurgie');
INSERT INTO `services` VALUES ('88','CHR K88','88000','Chirurgie');
INSERT INTO `services` VALUES ('89','CHR K89','89000','Chirurgie');
INSERT INTO `services` VALUES ('90','CHR K90','90000','Chirurgie');
INSERT INTO `services` VALUES ('91','CHR K91','91000','Chirurgie');
INSERT INTO `services` VALUES ('92','CHR K92','92000','Chirurgie');
INSERT INTO `services` VALUES ('93','CHR K93','93000','Chirurgie');
INSERT INTO `services` VALUES ('94','CHR K94','94000','Chirurgie');
INSERT INTO `services` VALUES ('95','CHR K95','95000','Chirurgie');
INSERT INTO `services` VALUES ('96','CHR K96','96000','Chirurgie');
INSERT INTO `services` VALUES ('97','CHR K97','97000','Chirurgie');
INSERT INTO `services` VALUES ('98','CHR K98','98000','Chirurgie');
INSERT INTO `services` VALUES ('99','CHR K99','99000','Chirurgie');
INSERT INTO `services` VALUES ('100','CHR K100','100000','Chirurgie');
INSERT INTO `services` VALUES ('101','CHR Pansement simple','500','Chirurgie');
INSERT INTO `services` VALUES ('102','CHR Pansement complexe','1000','Chirurgie');
INSERT INTO `services` VALUES ('103','CHR Pose sonde nase-gastrique','3000','Chirurgie');
INSERT INTO `services` VALUES ('104','CHR Pose sonde urinaire','3000','Chirurgie');
INSERT INTO `services` VALUES ('105','CHR Suture','1000','Chirurgie');
INSERT INTO `services` VALUES ('106','CHR Circoncision','5000','Chirurgie');
INSERT INTO `services` VALUES ('107','CHR Incision','2000','Chirurgie');
INSERT INTO `services` VALUES ('108','Echographie Abdominale (foie, rate, vésicule biliaire, pancréas…)','10000','Imagerie');
INSERT INTO `services` VALUES ('109','Echographie Abdominopelvienne','15000','Imagerie');
INSERT INTO `services` VALUES ('110','Echographie Pelvienne','7500','Imagerie');
INSERT INTO `services` VALUES ('111','Echographie Pelvienne Endovaginale','10000','Imagerie');
INSERT INTO `services` VALUES ('112','Echographie Mammaire (ou sein)','10000','Imagerie');
INSERT INTO `services` VALUES ('113','Echographie Rénale (ou voies urinaires ou arbres urinaires)','10000','Imagerie');
INSERT INTO `services` VALUES ('114','Echographie Obstétricale (1er, 2e, 3e, trimestre)','8000','Imagerie');
INSERT INTO `services` VALUES ('115','Echographie Reno-Vesico-Prostatique','20000','Imagerie');
INSERT INTO `services` VALUES ('116','Echographie Testiculaire (ou scrotale ou bourses)','12500','Imagerie');
INSERT INTO `services` VALUES ('117','Echographie Thyroidienne, Echographie Cervicale (parotide…)','20000','Imagerie');
INSERT INTO `services` VALUES ('118','Echographie Occulaire','12000','Imagerie');
INSERT INTO `services` VALUES ('119','Echographie parties molles','10000','Imagerie');
INSERT INTO `services` VALUES ('120','Echographie Transfontanellaire','15000','Imagerie');
INSERT INTO `services` VALUES ('121','Echo Doppler Veneux des membres inférieur','25000','Imagerie');
INSERT INTO `services` VALUES ('122','Echo Dopper Artériel des membres','30000','imagerie');
INSERT INTO `services` VALUES ('123','Echo Dopper Testiculaire','20000','Imagerie');
INSERT INTO `services` VALUES ('124','Echo Dopper des troncs supraortiques','25000','Imagerie');
INSERT INTO `services` VALUES ('125','Echographie Osteo Articulaire (genou, coude, épaule…)','15000','Imagerie');
INSERT INTO `services` VALUES ('126','RX Articulation antalo-axoidienne','10000','Imagerie');
INSERT INTO `services` VALUES ('127','RX Articulation Temporo-Mandibulaire','10000','Imagerie');
INSERT INTO `services` VALUES ('128','RX Blondeau/Hirtz/Worms/Shuller','10000','Imagerie');
INSERT INTO `services` VALUES ('129','RX Cavum (Profil)','10000','Imagerie');
INSERT INTO `services` VALUES ('130','RX Crane (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('131','RX Défilé maxiliaire','10000','Imagerie');
INSERT INTO `services` VALUES ('132','RX Os propre du nez (OPN)','10000','Imagerie');
INSERT INTO `services` VALUES ('133','RX Selle turcique','10000','Imagerie');
INSERT INTO `services` VALUES ('134','RX Sinus complet','20000','Imagerie');
INSERT INTO `services` VALUES ('135','RX Avant-bras (F/P)','12000','Imagerie');
INSERT INTO `services` VALUES ('136','RX Bras (F/P)','12000','Imagerie');
INSERT INTO `services` VALUES ('137','RX Coude (F/P)','12000','Imagerie');
INSERT INTO `services` VALUES ('138','RX Epaule (F/P)','12000','Imagerie');
INSERT INTO `services` VALUES ('139','RX Epaule 3 incidences','20000','Imagerie');
INSERT INTO `services` VALUES ('140','RX Main (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('141','RX Poignet (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('142','RX Doigt (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('143','RX Age osseux (main et poignet)','20000','Imagerie');
INSERT INTO `services` VALUES ('144','RX Bassin (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('145','RX Calcanéum (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('146','RX Cheville (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('147','RX Fémur (F/P)','12000','Imagerie');
INSERT INTO `services` VALUES ('148','RX Genou (F/P)','12000','Imagerie');
INSERT INTO `services` VALUES ('149','RX Genou (F/P + 30° . 60°)','20000','Imagerie');
INSERT INTO `services` VALUES ('150','RX Hanche (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('151','RX Jambe (F/P)','12000','Imagerie');
INSERT INTO `services` VALUES ('152','RX Orteil (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('153','RX Pied (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('154','RX Gril costal (F)','15000','Imagerie');
INSERT INTO `services` VALUES ('155','RX Gril costal (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('156','RX Sternum, clavicule (F/P)','10000','Imagerie');
INSERT INTO `services` VALUES ('157','RX Thorax (F)','9000','Imagerie');
INSERT INTO `services` VALUES ('158','RX Thorax (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('159','RX Rachis cervical (F/P + %)','20000','Imagerie');
INSERT INTO `services` VALUES ('160','RX Rachis cervical (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('161','RX Rachis complet','45000','Imagerie');
INSERT INTO `services` VALUES ('162','RX Rachis dorsal (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('163','RX Rachis dorso-lombaire (F/P)','25000','Imagerie');
INSERT INTO `services` VALUES ('164','RX Rashis lombaire (F/P + %)','20000','Imagerie');
INSERT INTO `services` VALUES ('165','RX Rashis lombaire (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('166','RX Rashis lombo-sacré (F/P)','15000','Imagerie');
INSERT INTO `services` VALUES ('167','CA Consultation simple','600','Carnet');
INSERT INTO `services` VALUES ('168','MA Consultation prénatale','5500','Maternité');
INSERT INTO `services` VALUES ('169','CA Carnet de consultation','400','Carnet');
INSERT INTO `services` VALUES ('170','CA Carnet pédiatrie','1000','Carnet');
INSERT INTO `services` VALUES ('171','SP Consultation gynécologue','3000','Consultation Spécialiste');
INSERT INTO `services` VALUES ('172','SP Consultation cardiologue','5000','Consultation Spécialiste');
INSERT INTO `services` VALUES ('173','SP Consultation endocrinologue','7000','Consultation Spécialiste');
INSERT INTO `services` VALUES ('174','SP Consultation pédiatre','3000','Consultation Spécialiste');
INSERT INTO `services` VALUES ('175','SP Consultation kinésithépeute','5000','Consultation Spécialiste');
INSERT INTO `services` VALUES ('176','SP Consultation chirurgien','5000','Consultation Spécialiste');
INSERT INTO `services` VALUES ('177','SP Consultation psychologue','5000','Consultation Spécialiste');
INSERT INTO `services` VALUES ('178','MED Soins infirmiers','1000','Medecine');
INSERT INTO `services` VALUES ('179','MED Pose cathether','1000','Medecine');
INSERT INTO `services` VALUES ('180','MED Injection','500','Medecine');
INSERT INTO `services` VALUES ('181','MED Ami','1500','Medecine');
INSERT INTO `services` VALUES ('182','MED Dossier médical','1000','Medecine');
INSERT INTO `services` VALUES ('183','MED Hospitalisation simple','1500','Medecine');
INSERT INTO `services` VALUES ('184','MED Hospitalisation payant','3000','Medecine');
INSERT INTO `services` VALUES ('185','MED Hospitalisation VIP','5000','Medecine');
INSERT INTO `services` VALUES ('186','MA Forfait maternité','7600','Maternité');
INSERT INTO `services` VALUES ('187','MA Surveillance syntho','5000','Maternité');
INSERT INTO `services` VALUES ('188','MA Induction','5000','Maternité');
INSERT INTO `services` VALUES ('189','MA Suture vaginale','7500','Maternité');
INSERT INTO `services` VALUES ('190','MA Suture col','10000','Maternité');
INSERT INTO `services` VALUES ('191','MA Suture périnée','5000','Maternité');
INSERT INTO `services` VALUES ('192','UPEC Crachats','1000','Upec');
INSERT INTO `services` VALUES ('193','LAB Cholestérol total','3600','Laboratoire');
INSERT INTO `services` VALUES ('194','LAB Cholestérol HDL','3600','Laboratoire');
INSERT INTO `services` VALUES ('195','LAB Cholestérol LDL','3600','Laboratoire');
INSERT INTO `services` VALUES ('196','LAB Triglycérides','3600','Laboratoire');
INSERT INTO `services` VALUES ('197','LAB Urée','2700','Laboratoire');
INSERT INTO `services` VALUES ('198','LAB Creatinine','2700','Laboratoire');
INSERT INTO `services` VALUES ('199','LAB Ionogramme complet (Na, K, Cl, Ca2+, Mg2+','13500','Laboratoire');
INSERT INTO `services` VALUES ('200','LAB Ionogramme simple (Na, K, Cl) ','9000','Laboratoire');
INSERT INTO `services` VALUES ('201','LAB Calcium','3600','Laboratoire');
INSERT INTO `services` VALUES ('202','LAB Chlore','2700','Laboratoire');
INSERT INTO `services` VALUES ('203','LAB Magnésium','3600','Laboratoire');
INSERT INTO `services` VALUES ('204','LAB Fer serique','5400','Laboratoire');
INSERT INTO `services` VALUES ('205','LAB Hémoglobine glycossylée (HBA1C)','10800','Laboratoire');
INSERT INTO `services` VALUES ('206','LAB Lipides','6300','Laboratoire');
INSERT INTO `services` VALUES ('207','LAB Phosphore','2700','Laboratoire');
INSERT INTO `services` VALUES ('208','LAB Protide','1800','Laboratoire');
INSERT INTO `services` VALUES ('209','LAB Acide urique','2700','Laboratoire');
INSERT INTO `services` VALUES ('210','LAB Ferritine','18000','Laboratoire');
INSERT INTO `services` VALUES ('211','LAB Lipasse','10800','Laboratoire');
INSERT INTO `services` VALUES ('212','LAB Transaminases (SGOT/SGPT)','8000','Laboratoire');
INSERT INTO `services` VALUES ('213','LAB NFS','6300','Laboratoire');
INSERT INTO `services` VALUES ('214','LAB GE','1000','Laboratoire');
INSERT INTO `services` VALUES ('215','LAB TDR','200','Laboratoire');
INSERT INTO `services` VALUES ('216','LAB VS','2000','Laboratoire');
INSERT INTO `services` VALUES ('217','LAB Snip test','2000','Laboratoire');
INSERT INTO `services` VALUES ('218','LAB Microfilaire','2000','Laboratoire');
INSERT INTO `services` VALUES ('219','LAB Groupe sanguin (GS RH)','2000','Laboratoire');
INSERT INTO `services` VALUES ('220','LAB Selle','500','Laboratoire');
INSERT INTO `services` VALUES ('221','LAB Selle + ATB','14000','Laboratoire');
INSERT INTO `services` VALUES ('222','LAB ECBU','2000','Laboratoire');
INSERT INTO `services` VALUES ('223','LAB ECBU + ATB','12000','Laboratoire');
INSERT INTO `services` VALUES ('224','LAB PU','2000','Laboratoire');
INSERT INTO `services` VALUES ('225','LAB PU + ATB','14000','Laboratoire');
INSERT INTO `services` VALUES ('226','LAB PCV','2000','Laboratoire');
INSERT INTO `services` VALUES ('227','LAB PCV + ATB','14000','Laboratoire');
INSERT INTO `services` VALUES ('228','LAB Mycoplasme','14000','Laboratoire');
INSERT INTO `services` VALUES ('229','LAB Spermogramme','14000','Laboratoire');
INSERT INTO `services` VALUES ('230','LAB Widal et Felix','3600','Laboratoire');
INSERT INTO `services` VALUES ('231','LAB TPHA/VDRL','4500','Laboratoire');
INSERT INTO `services` VALUES ('232','LAB Chlamydia','8000','Laboratoire');
INSERT INTO `services` VALUES ('233','LAB Toxo','8000','Laboratoire');
INSERT INTO `services` VALUES ('234','LAB Rubéole','8000','Laboratoire');
INSERT INTO `services` VALUES ('235','LAB CRP','3600','Laboratoire');
INSERT INTO `services` VALUES ('236','LAB ASLO','4000','Laboratoire');
INSERT INTO `services` VALUES ('237','LAB Facteur Rhumatoide','4500','Laboratoire');
INSERT INTO `services` VALUES ('238','LAB AgHbs','3600','Laboratoire');
INSERT INTO `services` VALUES ('239','LAB ACHVC','4500','Laboratoire');
INSERT INTO `services` VALUES ('240','LAB H.PYLORI','8000','Laboratoire');
INSERT INTO `services` VALUES ('241','LAB Glycémie à jeun','1000','Laboratoire');
INSERT INTO `services` VALUES ('242','LAB AgHbs','13500','Laboratoire');
INSERT INTO `services` VALUES ('243','LAB AC anti Hbs','13500','Laboratoire');
INSERT INTO `services` VALUES ('244','LAB AC anti Hbe','13500','Laboratoire');
INSERT INTO `services` VALUES ('245','LAB AC anti Hbc','13500','Laboratoire');
INSERT INTO `services` VALUES ('246','LAB Dosage AgHbs','12600','Laboratoire');
INSERT INTO `services` VALUES ('247','LAB Dosage HCV','18000','Laboratoire');
INSERT INTO `services` VALUES ('248','LAB Dosage Toxo','12600','Laboratoire');
INSERT INTO `services` VALUES ('249','LAB Herpes 1 et 2','18000','Laboratoire');
INSERT INTO `services` VALUES ('250','LAB IgE totales','16200','Laboratoire');
INSERT INTO `services` VALUES ('251','LAB Chlamydia PCR','35000','Laboratoire');
INSERT INTO `services` VALUES ('252','LAB Béta HCG serique','6000','Laboratoire');
INSERT INTO `services` VALUES ('253','LAB Béta HCG Dosage ','20000','Laboratoire');
INSERT INTO `services` VALUES ('254','LAB Cortisolémie','36000','Laboratoire');
INSERT INTO `services` VALUES ('255','LAB Testotérone','21600','Laboratoire');
INSERT INTO `services` VALUES ('256','LAB Oestradiol','18000','Laboratoire');
INSERT INTO `services` VALUES ('257','LAB LH','18000','Laboratoire');
INSERT INTO `services` VALUES ('258','LAB FSH','18000','Laboratoire');
INSERT INTO `services` VALUES ('259','LAB Progestérone','20000','Laboratoire');
INSERT INTO `services` VALUES ('260','LAB Prolactine','20000','Laboratoire');
INSERT INTO `services` VALUES ('261','LAB T3','20000','Laboratoire');
INSERT INTO `services` VALUES ('262','LAB T4','20000','Laboratoire');
INSERT INTO `services` VALUES ('263','LAB TSH','20000','Laboratoire');
INSERT INTO `services` VALUES ('264','LAB AFP','20000','Laboratoire');
INSERT INTO `services` VALUES ('265','LAB ACE','20000','Laboratoire');
INSERT INTO `services` VALUES ('266','LAB PSA libre','25000','Laboratoire');
INSERT INTO `services` VALUES ('267','LAB PSA totale','25000','Laboratoire');
INSERT INTO `services` VALUES ('268','LAB NT Pro BNP','27000','Laboratoire');
INSERT INTO `services` VALUES ('269','LAB Troponine','20000','Laboratoire');
INSERT INTO `services` VALUES ('270','LAB D.dimeres','20000','Laboratoire');
INSERT INTO `services` VALUES ('271','LAB Procalcitomie','30000','Laboratoire');
INSERT INTO `services` VALUES ('272','LAB Protéinurie de 24h','7800','Laboratoire');
INSERT INTO `services` VALUES ('273','LAB AMH','48000','Laboratoire');
INSERT INTO `services` VALUES ('274','LAB Speculum','1000','Laboratoire');
INSERT INTO `services` VALUES ('275','MA Test de grossesse','2000','Maternité');
INSERT INTO `services` VALUES ('276','LAB Electrophorese','10800','Laboratoire');
INSERT INTO `services` VALUES ('277','LAB Profil lipidique','14400','Laboratoire');
INSERT INTO `services` VALUES ('278','LAB Hepatite C','4500','Laboratoire');
INSERT INTO `services` VALUES ('279','LAB VIH','0','Laboratoire');
INSERT INTO `services` VALUES ('280','LAB ALAT ASAT','8000','Laboratoire');
INSERT INTO `services` VALUES ('281','LAB Hepatite B et C','8100','Laboratoire');
INSERT INTO `services` VALUES ('282','Echo Mammographie','30000','Imagerie');
INSERT INTO `services` VALUES ('283','MED Oxygene','5000','Medecine');
INSERT INTO `services` VALUES ('284','MED Pansement','500','Medecine');
INSERT INTO `services` VALUES ('285','LAB BU','1000','Laboratoire');
INSERT INTO `services` VALUES ('288','k20','20000','chirurgie');
INSERT INTO `services` VALUES ('290','ld','2','laboratoire');
INSERT INTO `services` VALUES ('291','Circoncision','2000','chirurgie');
INSERT INTO `services` VALUES ('292','K1','1000','chirurgie');


DROP TABLE IF EXISTS `services_urgences`;
CREATE TABLE `services_urgences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` text NOT NULL,
  `prix` int(11) NOT NULL,
  `categorie` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8mb4;

INSERT INTO `services_urgences` VALUES ('1','CHR K1','1000','chirurgie');
INSERT INTO `services_urgences` VALUES ('2','CHR K2','2000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('3','CHR K3','3000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('4','CHR K4','4000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('5','CHR K5','5000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('6','CHR K6','6000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('7','CHR K7','7000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('8','CHR K8','8000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('9','CHR K9','9000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('10','CHR K10','10000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('11','CHR K11','11000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('12','CHR K12','12000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('13','CHR K13','13000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('14','CHR K14','14000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('15','CHR K15','15000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('16','CHR K16','16000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('17','CHR K17','17000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('18','CHR K18','18000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('19','CHR K19','19000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('20','CHR K20','20000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('21','CHR K21','21000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('22','CHR K22','22000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('23','CHR K23','23000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('24','CHR K24','24000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('25','CHR K25','25000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('26','CHR K26','26000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('27','CHR K27','27000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('28','CHR K28','28000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('29','CHR K29','29000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('30','CHR K30','30000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('31','CHR K31','31000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('32','CHR K32','32000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('33','CHR K33','33000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('34','CHR K34','34000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('35','CHR K35','35000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('36','CHR K36','36000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('37','CHR K37','37000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('38','CHR K38','38000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('39','CHR K39','39000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('40','CHR K40','40000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('41','CHR K41','41000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('42','CHR K42','42000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('43','CHR K43','43000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('44','CHR K44','44000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('45','CHR K45','45000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('46','CHR K46','46000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('47','CHR K47','47000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('48','CHR K48','48000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('49','CHR K49','49000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('50','CHR K50','50000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('51','CHR K51','51000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('52','CHR K52','52000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('53','CHR K53','53000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('54','CHR K54','54000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('55','CHR K55','55000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('56','CHR K56','56000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('57','CHR K57','57000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('58','CHR K58','58000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('59','CHR K59','59000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('60','CHR K60','60000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('61','CHR K61','61000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('62','CHR K62','62000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('63','CHR K63','63000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('64','CHR K64','64000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('65','CHR K65','65000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('66','CHR K66','66000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('67','CHR K67','67000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('68','CHR K68','68000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('69','CHR K69','69000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('70','CHR K70','70000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('71','CHR K71','71000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('72','CHR K72','72000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('73','CHR K73','73000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('74','CHR K74','74000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('75','CHR K75','75000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('76','CHR K76','76000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('77','CHR K77','77000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('78','CHR K78','78000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('79','CHR K79','79000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('80','CHR K80','80000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('81','CHR K81','81000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('82','CHR K82','82000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('83','CHR K83','83000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('84','CHR K84','84000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('85','CHR K85','85000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('86','CHR K86','86000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('87','CHR K87','87000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('88','CHR K88','88000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('89','CHR K89','89000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('90','CHR K90','90000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('91','CHR K91','91000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('92','CHR K92','92000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('93','CHR K93','93000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('94','CHR K94','94000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('95','CHR K95','95000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('96','CHR K96','96000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('97','CHR K97','97000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('98','CHR K98','98000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('99','CHR K99','99000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('100','CHR K100','100000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('101','CHR Pansement simple','500','Chirurgie');
INSERT INTO `services_urgences` VALUES ('102','CHR Pansement complexe','1000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('103','CHR Pose sonde nase-gastrique','3000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('104','CHR Pose sonde urinaire','3000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('105','CHR Suture','1000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('106','CHR Circoncision','5000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('107','CHR Incision','2000','Chirurgie');
INSERT INTO `services_urgences` VALUES ('108','Echographie Abdominale (foie, rate, vésicule biliaire, pancréas…)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('109','Echographie Abdominopelvienne','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('110','Echographie Pelvienne','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('111','Echographie Pelvienne Endovaginale','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('112','Echographie Mammaire (ou sein)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('113','Echographie Rénale (ou voies urinaires ou arbres urinaires)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('114','Echographie Obstétricale (1er, 2e, 3e, trimestre)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('115','Echographie Reno-Vesico-Prostatique','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('116','Echographie Testiculaire (ou scrotale ou bourses)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('117','Echographie Thyroidienne, Echographie Cervicale (parotide…)','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('118','Echographie Occulaire','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('119','Echographie parties molles','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('120','Echographie Transfontanellaire','17500','Imagerie');
INSERT INTO `services_urgences` VALUES ('121','Echo Doppler Veneux des membres inférieur','30000','Imagerie');
INSERT INTO `services_urgences` VALUES ('122','Echo Dopper Artériel des membres','35000','imagerie');
INSERT INTO `services_urgences` VALUES ('123','Echo Dopper Testiculaire','25000','Imagerie');
INSERT INTO `services_urgences` VALUES ('124','Echo Dopper des troncs supraortiques','30000','Imagerie');
INSERT INTO `services_urgences` VALUES ('125','Echographie Osteo Articulaire (genou, coude, épaule…)','17000','Imagerie');
INSERT INTO `services_urgences` VALUES ('126','RX Articulation antalo-axoidienne','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('127','RX Articulation Temporo-Mandibulaire','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('128','RX Blondeau/Hirtz/Worms/Shuller','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('129','RX Cavum (Profil)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('130','RX Crane (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('131','RX Défilé maxiliaire','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('132','RX Os propre du nez (OPN)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('133','RX Selle turcique','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('134','RX Sinus complet','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('135','RX Avant-bras (F/P)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('136','RX Bras (F/P)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('137','RX Coude (F/P)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('138','RX Epaule (F/P)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('139','RX Epaule 3 incidences','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('140','RX Main (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('141','RX Poignet (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('142','RX Doigt (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('143','RX Age osseux (main et poignet)','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('144','RX Bassin (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('145','RX Calcanéum (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('146','RX Cheville (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('147','RX Fémur (F/P)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('148','RX Genou (F/P)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('149','RX Genou (F/P + 30° . 60°)','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('150','RX Hanche (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('151','RX Jambe (F/P)','12000','Imagerie');
INSERT INTO `services_urgences` VALUES ('152','RX Orteil (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('153','RX Pied (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('154','RX Gril costal (F)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('155','RX Gril costal (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('156','RX Sternum, clavicule (F/P)','10000','Imagerie');
INSERT INTO `services_urgences` VALUES ('157','RX Thorax (F)','9000','Imagerie');
INSERT INTO `services_urgences` VALUES ('158','RX Thorax (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('159','RX Rachis cervical (F/P + %)','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('160','RX Rachis cervical (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('161','RX Rachis complet','45000','Imagerie');
INSERT INTO `services_urgences` VALUES ('162','RX Rachis dorsal (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('163','RX Rachis dorso-lombaire (F/P)','25000','Imagerie');
INSERT INTO `services_urgences` VALUES ('164','RX Rashis lombaire (F/P + %)','20000','Imagerie');
INSERT INTO `services_urgences` VALUES ('165','RX Rashis lombaire (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('166','RX Rashis lombo-sacré (F/P)','15000','Imagerie');
INSERT INTO `services_urgences` VALUES ('167','CA Consultation simple','900','Carnet');
INSERT INTO `services_urgences` VALUES ('168','MA Consultation prénatale','5500','Maternité');
INSERT INTO `services_urgences` VALUES ('169','CA Carnet de consultation','400','Carnet');
INSERT INTO `services_urgences` VALUES ('170','CA Carnet pédiatrie','1000','Carnet');
INSERT INTO `services_urgences` VALUES ('171','SP Consultation gynécologue','3000','Consultation spécialiste');
INSERT INTO `services_urgences` VALUES ('172','SP Consultation cardiologue','5000','Consultation spécialiste');
INSERT INTO `services_urgences` VALUES ('173','SP Consultation endocrinologue','7000','Consultation spécialiste');
INSERT INTO `services_urgences` VALUES ('174','SP Consultation pédiatre','3000','Consultation spécialiste');
INSERT INTO `services_urgences` VALUES ('175','SP Consultation kinésithépeute','5000','Consultation spécialiste');
INSERT INTO `services_urgences` VALUES ('176','SP Consultation chirurgien','5000','Consultation spécialiste');
INSERT INTO `services_urgences` VALUES ('177','SP Consultation psychologue','5000','Consultation spécialiste');
INSERT INTO `services_urgences` VALUES ('178','MED Soins infirmiers','1000','Medecine');
INSERT INTO `services_urgences` VALUES ('179','MED Pose cathether','1000','Medecine');
INSERT INTO `services_urgences` VALUES ('180','MED Injection','500','Medecine');
INSERT INTO `services_urgences` VALUES ('181','MED Ami','1500','Medecine');
INSERT INTO `services_urgences` VALUES ('182','MED Dossier médical','1000','Medecine');
INSERT INTO `services_urgences` VALUES ('183','MED Hospitalisation simple','1500','Medecine');
INSERT INTO `services_urgences` VALUES ('184','MED Hospitalisation payant','3000','Medecine');
INSERT INTO `services_urgences` VALUES ('185','MED Hospitalisation VIP','5000','Medecine');
INSERT INTO `services_urgences` VALUES ('186','MA Forfait maternité','7600','Maternité');
INSERT INTO `services_urgences` VALUES ('187','MA Surveillance syntho','5000','Maternité');
INSERT INTO `services_urgences` VALUES ('188','MA Induction','5000','Maternité');
INSERT INTO `services_urgences` VALUES ('189','MA Suture vaginale','7500','Maternité');
INSERT INTO `services_urgences` VALUES ('190','MA Suture col','10000','Maternité');
INSERT INTO `services_urgences` VALUES ('191','MA Suture périnée','5000','Maternité');
INSERT INTO `services_urgences` VALUES ('192','UPEC Crachats','1000','Upec');
INSERT INTO `services_urgences` VALUES ('193','LAB Cholestérol total','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('194','LAB Cholestérol HDL','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('195','LAB Cholestérol LDL','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('196','LAB Triglycérides','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('197','LAB Urée','2700','Laboratoire');
INSERT INTO `services_urgences` VALUES ('198','LAB Créatine','2700','Laboratoire');
INSERT INTO `services_urgences` VALUES ('199','LAB Ionogramme complet (Na, K, Cl, Ca2+, Mg2+','13500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('200','LAB Ionogramme simple (Na, K, Cl) ','9000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('201','LAB Calcium','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('202','LAB Chlore','2700','Laboratoire');
INSERT INTO `services_urgences` VALUES ('203','LAB Magnésium','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('204','LAB Fer serique','5400','Laboratoire');
INSERT INTO `services_urgences` VALUES ('205','LAB Hémoglobine glycossylée (HBA1C)','10800','Laboratoire');
INSERT INTO `services_urgences` VALUES ('206','LAB Lipides','6300','Laboratoire');
INSERT INTO `services_urgences` VALUES ('207','LAB Phosphore','2700','Laboratoire');
INSERT INTO `services_urgences` VALUES ('208','LAB Protide','1800','Laboratoire');
INSERT INTO `services_urgences` VALUES ('209','LAB Acide urique','2700','Laboratoire');
INSERT INTO `services_urgences` VALUES ('210','LAB Ferritine','18000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('211','LAB Lipasse','10800','Laboratoire');
INSERT INTO `services_urgences` VALUES ('212','LAB Transaminases (SGOT/SGPT)','8000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('213','LAB NFS','6300','Laboratoire');
INSERT INTO `services_urgences` VALUES ('214','LAB GE','1000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('215','LAB TDR','200','Laboratoire');
INSERT INTO `services_urgences` VALUES ('216','LAB VS','2000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('217','LAB Snip test','2000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('218','LAB Microfilaire','2000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('219','LAB Groupe sanguin (GS RH)','2000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('220','LAB Selle','500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('221','LAB Selle + ATB','14000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('222','LAB ECBU','2000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('223','LAB ECBU + ATB','12000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('224','LAB PU','2000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('225','LAB PU + ATB','14000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('226','LAB PCV','2000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('227','LAB PCV + ATB','14000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('228','LAB Mycoplasme','14000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('229','LAB Spermogramme','14000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('230','LAB Widal et Felix','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('231','LAB TPHA/VDRL','4500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('232','LAB Chlamydia','8000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('233','LAB Toxo','8000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('234','LAB Rubéole','8000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('235','LAB CRP','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('236','LAB ASLO','4000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('237','LAB Facteur Rhumatoide','4500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('238','LAB AgHbs','3600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('239','LAB ACHVC','4500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('240','LAB H.PYLORI','8000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('241','LAB Glycémie à jeun','1000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('242','LAB AgHbs','13500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('243','LAB AC anti Hbs','13500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('244','LAB AC anti Hbe','13500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('245','LAB AC anti Hbc','13500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('246','LAB Dosage AgHbs','12600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('247','LAB Dosage HCV','18000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('248','LAB Dosage Toxo','12600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('249','LAB Herpes 1 et 2','18000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('250','LAB IgE totales','16200','Laboratoire');
INSERT INTO `services_urgences` VALUES ('251','LAB Chlamydia PCR','35000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('252','LAB Béta HCG serique','6000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('253','LAB Béta HCG Dosage ','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('254','LAB Cortisolémie','36000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('255','LAB Testotérone','21600','Laboratoire');
INSERT INTO `services_urgences` VALUES ('256','LAB Oestradiol','18000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('257','LAB LH','18000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('258','LAB FSH','18000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('259','LAB Progestérone','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('260','LAB Prolactine','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('261','LAB T3','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('262','LAB T4','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('263','LAB TSH','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('264','LAB AFP','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('265','LAB ACE','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('266','LAB PSA libre','25000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('267','LAB PSA totale','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('268','LAB NT Pro BNP','27000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('269','LAB Troponine','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('270','LAB D.dimeres','20000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('271','LAB Procalcitomie','30000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('272','LAB Protéinurie de 24h','7800','Laboratoire');
INSERT INTO `services_urgences` VALUES ('273','LAB AMH','48000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('274','LAB Speculum','1000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('275','MA Test de grossesse','2000','Maternité');
INSERT INTO `services_urgences` VALUES ('276','LAB Electrophorese','10800','Laboratoire');
INSERT INTO `services_urgences` VALUES ('277','LAB Profil Lipidique','14400','Laboratoire');
INSERT INTO `services_urgences` VALUES ('278','LAB Hepatite C','4500','Laboratoire');
INSERT INTO `services_urgences` VALUES ('279','LAB VIH','0','Laboratoire');
INSERT INTO `services_urgences` VALUES ('280','LAB ALAT ASAT','8000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('281','LAB Hepatite B et C','8100','Laboratoire');
INSERT INTO `services_urgences` VALUES ('282','Echo Mammographie','30000','Imagerie');
INSERT INTO `services_urgences` VALUES ('283','MED Oxygene','5000','Medecine');
INSERT INTO `services_urgences` VALUES ('284','MED Pansement','500','Medecine');
INSERT INTO `services_urgences` VALUES ('285','LAB BU','1000','Laboratoire');
INSERT INTO `services_urgences` VALUES ('288','k20','20000','chirurgie');
INSERT INTO `services_urgences` VALUES ('290','ld','2','laboratoire');
INSERT INTO `services_urgences` VALUES ('291','Circoncision','2000','chirurgie');
INSERT INTO `services_urgences` VALUES ('292','K1','1000','chirurgie');


DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_user` varchar(255) NOT NULL,
  `mdpasse` text NOT NULL,
  `rol` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

INSERT INTO `utilisateurs` VALUES ('6','Dr Obam','$2y$10$kuNGmByWaOoVLjtMKYWYsOoCUsvpfAa.7ZMcWR60df6nIH1hLj9sy','admin');
INSERT INTO `utilisateurs` VALUES ('7','Kamdem','$2y$10$Z9GKQD2f9H1SA2mi0VspAu93zmhB5J44yjdo73m/79akfAd6Ir.UW','vendeur');
INSERT INTO `utilisateurs` VALUES ('10','ABC','$2y$10$80b9pMiEGt9IS0xO2wmVRep1alICbRh8rBhPDVUwL2.5dlK270we.','major');
INSERT INTO `utilisateurs` VALUES ('14','ob','$2y$10$71Pzs7FEDXDWSnuag8KeuOIvQMq/AZIVpHVcQKA4lev.ism2MqEEC','vendeur');
INSERT INTO `utilisateurs` VALUES ('15','red','$2y$10$EsT.WtoeMvvRrw7HUUQpNuYcS5jQGZsTM/FKYBoCkCaulXVZfpiFC','admin');


DROP TABLE IF EXISTS `utilisateurs_caisse`;
CREATE TABLE `utilisateurs_caisse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom_user` varchar(255) NOT NULL,
  `mdpasse` text NOT NULL,
  `rol` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;

INSERT INTO `utilisateurs_caisse` VALUES ('12','Kamdem','$2y$10$EXg1RM5DY1PF.H3uiD/yte5myNJZDafL9cKdNsSylUffBaxYXKmbS','caissier');
INSERT INTO `utilisateurs_caisse` VALUES ('13','Mr Nola','$2y$10$m1cYZy5QrQmzTyImU5J/lubvLU3l3pn6Sc94lNXW/uCOHZNwmPIqy','regisseur');
INSERT INTO `utilisateurs_caisse` VALUES ('19','Tatiana','$2y$10$jS460Q4r4W9WiM8GNIZSkOgdBPp5NlTwC.o63s7Vz9oYtr/1UfVI6','secretaire');
INSERT INTO `utilisateurs_caisse` VALUES ('20','abc','$2y$10$Z5JilQ/i9khxKkuRlC.JmOsU3iyRsq6.LzMZRd.I/Dsp9Xvx0UZ4G','caissier');
INSERT INTO `utilisateurs_caisse` VALUES ('21','er','$2y$10$lgX.jC63hDY2K5NZuJdgYusyZkA1USmiRSDS8rbOtk282lTEmowuC','caissier');
